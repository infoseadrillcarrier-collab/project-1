import fs from 'fs';
import path from 'path';
import { AccountData, Transaction, AuditLogEntry, BankNotification, Beneficiary } from '../src/types.js';
import {
  initialAccountData,
  generateInitialTransactions,
  initialAuditLogs,
  initialNotifications,
  initialBeneficiaries,
} from './defaultData.js';

export interface DatabaseSchema {
  account: AccountData;
  transactions: Transaction[];
  auditLogs: AuditLogEntry[];
  notifications: BankNotification[];
  beneficiaries: Beneficiary[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.resolve(DATA_DIR, 'bank-data.json');

class DatabaseStore {
  private data: DatabaseSchema;

  constructor() {
    this.ensureDirectoryExists();
    this.data = this.loadData();
  }

  private ensureDirectoryExists() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  }

  private loadData(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const fileContent = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(fileContent);
        if (parsed.account && Array.isArray(parsed.transactions)) {
          parsed.transactions.forEach((tx: any) => {
            if (tx.status === 'Demonstration Reconciled') {
              tx.status = 'Settled';
            }
          });
          return parsed;
        }
      }
    } catch (err) {
      console.error('Error reading bank-data.json, re-initializing default state:', err);
    }

    const defaultState: DatabaseSchema = {
      account: { ...initialAccountData },
      transactions: generateInitialTransactions(),
      auditLogs: [...initialAuditLogs],
      notifications: [...initialNotifications],
      beneficiaries: [...initialBeneficiaries],
    };

    this.saveDataDirect(defaultState);
    return defaultState;
  }

  private saveDataDirect(data: DatabaseSchema) {
    try {
      const tempPath = `${DB_FILE}.tmp.${Date.now()}`;
      fs.writeFileSync(tempPath, JSON.stringify(data, null, 2), 'utf-8');
      fs.renameSync(tempPath, DB_FILE);
    } catch (err) {
      console.error('Error writing to persistent bank database:', err);
    }
  }

  private save() {
    this.saveDataDirect(this.data);
  }

  // Account Getters & Setters
  public getAccount(): AccountData {
    return { ...this.data.account };
  }

  public updateAccountProfile(
    updates: Partial<AccountData>,
    adminEmail: string,
    justification: string = 'Administrative profile configuration adjustment'
  ): AccountData {
    const prev = { ...this.data.account };
    
    // Whitelist editable fields
    if (updates.accountHolderName !== undefined) this.data.account.accountHolderName = updates.accountHolderName;
    if (updates.accountType !== undefined) this.data.account.accountType = updates.accountType;
    if (updates.accountDescription !== undefined) this.data.account.accountDescription = updates.accountDescription;
    if (updates.accountNumber !== undefined) this.data.account.accountNumber = updates.accountNumber;
    if (updates.accountStatus !== undefined) this.data.account.accountStatus = updates.accountStatus;
    if (updates.currency !== undefined) this.data.account.currency = updates.currency;
    if (updates.currencySymbol !== undefined) this.data.account.currencySymbol = updates.currencySymbol;
    if (updates.announcements !== undefined) this.data.account.announcements = updates.announcements;
    if (updates.relationshipManager !== undefined) this.data.account.relationshipManager = updates.relationshipManager;
    if (updates.routingNumber !== undefined) this.data.account.routingNumber = updates.routingNumber;
    if (updates.swiftBic !== undefined) this.data.account.swiftBic = updates.swiftBic;
    if (updates.iban !== undefined) this.data.account.iban = updates.iban;

    this.data.account.lastUpdated = new Date().toISOString();

    // Log the audit event
    this.addAuditLog({
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString(),
      adminEmail: adminEmail || 'aurelianhouse777@gmail.com',
      action: 'Account Profile Details Modified',
      category: 'PROFILE_UPDATE',
      previousValue: `Holder: "${prev.accountHolderName}", Type: "${prev.accountType}"`,
      newValue: `Holder: "${this.data.account.accountHolderName}", Type: "${this.data.account.accountType}"`,
      justification: justification || 'Formal administrative demonstration profile update.',
    });

    this.save();
    return { ...this.data.account };
  }

  public updateBalance(
    currentBalance: number,
    availableBalance: number,
    adminEmail: string,
    justification: string
  ): AccountData {
    const prevBalance = this.data.account.currentBalance;
    const prevAvailable = this.data.account.availableBalance;

    this.data.account.currentBalance = currentBalance;
    this.data.account.availableBalance = availableBalance;
    this.data.account.lastUpdated = new Date().toISOString();

    this.addAuditLog({
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString(),
      adminEmail: adminEmail || 'aurelianhouse777@gmail.com',
      action: 'Demonstration Account Balance Adjustment',
      category: 'BALANCE_ADJUSTMENT',
      previousValue: `Current: $${prevBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}, Available: $${prevAvailable.toLocaleString('en-US', { minimumFractionDigits: 2 })}`,
      newValue: `Current: $${currentBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}, Available: $${availableBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}`,
      justification: justification || 'Executive discretionary ledger calibration.',
    });

    this.save();
    return { ...this.data.account };
  }

  // Transactions
  public getTransactions(filters?: {
    search?: string;
    type?: string;
    status?: string;
    startDate?: string;
    endDate?: string;
  }): Transaction[] {
    let result = [...this.data.transactions];

    if (filters?.search) {
      const q = filters.search.toLowerCase();
      result = result.filter(
        (t) =>
          t.description.toLowerCase().includes(q) ||
          t.reference.toLowerCase().includes(q) ||
          t.counterparty.toLowerCase().includes(q) ||
          t.category.toLowerCase().includes(q)
      );
    }

    if (filters?.type && filters.type !== 'all') {
      result = result.filter((t) => t.type.toLowerCase() === filters.type!.toLowerCase());
    }

    if (filters?.status && filters.status !== 'all') {
      result = result.filter((t) => t.status.toLowerCase() === filters.status!.toLowerCase());
    }

    if (filters?.startDate) {
      result = result.filter((t) => t.date >= filters.startDate!);
    }

    if (filters?.endDate) {
      result = result.filter((t) => t.date <= filters.endDate!);
    }

    return result;
  }

  public addTransaction(newTx: Omit<Transaction, 'id' | 'isDemonstration'>, adminEmail: string): Transaction {
    const tx: Transaction = {
      ...newTx,
      id: `tx-demo-${Date.now()}`,
      isDemonstration: true,
    };

    this.data.transactions.unshift(tx);

    this.addAuditLog({
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString(),
      adminEmail: adminEmail || 'aurelianhouse777@gmail.com',
      action: 'Demonstration Transaction Recorded',
      category: 'TRANSACTION_MANAGEMENT',
      previousValue: 'None',
      newValue: `Ref: ${tx.reference}, ${tx.type} of $${tx.amount.toLocaleString()} (${tx.description})`,
      justification: 'Manual addition of demonstration ledger entry.',
    });

    this.save();
    return tx;
  }

  public updateTransaction(
    id: string,
    updates: Partial<Transaction>,
    adminEmail: string
  ): Transaction | null {
    const index = this.data.transactions.findIndex((t) => t.id === id);
    if (index === -1) return null;

    const prev = { ...this.data.transactions[index] };
    this.data.transactions[index] = {
      ...this.data.transactions[index],
      ...updates,
      id: prev.id, // Immutable
      isDemonstration: true,
    };

    this.addAuditLog({
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString(),
      adminEmail: adminEmail || 'aurelianhouse777@gmail.com',
      action: 'Demonstration Transaction Status Adjusted',
      category: 'TRANSACTION_MANAGEMENT',
      previousValue: `Status: ${prev.status}`,
      newValue: `Status: ${this.data.transactions[index].status}`,
      justification: 'Administrative transaction record verification.',
    });

    this.save();
    return this.data.transactions[index];
  }

  // Audit Logs
  public getAuditLogs(): AuditLogEntry[] {
    return [...this.data.auditLogs].sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }

  public addAuditLog(entry: AuditLogEntry) {
    this.data.auditLogs.unshift(entry);
    // Keep max 500 audit logs
    if (this.data.auditLogs.length > 500) {
      this.data.auditLogs = this.data.auditLogs.slice(0, 500);
    }
  }

  // Notifications
  public getNotifications(): BankNotification[] {
    return [...this.data.notifications];
  }

  public addNotification(
    notif: Omit<BankNotification, 'id' | 'timestamp'>,
    adminEmail: string
  ): BankNotification {
    const item: BankNotification = {
      ...notif,
      id: `notif-${Date.now()}`,
      timestamp: new Date().toISOString(),
    };
    this.data.notifications.unshift(item);

    this.addAuditLog({
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString(),
      adminEmail: adminEmail || 'aurelianhouse777@gmail.com',
      action: 'Advisory Notification Broadcast',
      category: 'SETTINGS_UPDATE',
      previousValue: 'None',
      newValue: item.title,
      justification: 'Public fiduciary disclosure published to client dashboard.',
    });

    this.save();
    return item;
  }

  // Beneficiaries
  public getBeneficiaries(): Beneficiary[] {
    return [...this.data.beneficiaries];
  }

  // Reset to Factory Default
  public resetToDefaults(adminEmail: string) {
    this.data = {
      account: { ...initialAccountData, lastUpdated: new Date().toISOString() },
      transactions: generateInitialTransactions(),
      auditLogs: [...initialAuditLogs],
      notifications: [...initialNotifications],
      beneficiaries: [...initialBeneficiaries],
    };

    this.addAuditLog({
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString(),
      adminEmail: adminEmail || 'aurelianhouse777@gmail.com',
      action: 'System Database Reset to Factory Demonstration State',
      category: 'SETTINGS_UPDATE',
      previousValue: 'Previous State',
      newValue: 'Factory Initialized',
      justification: 'Administrative system refresh and re-seeding.',
    });

    this.save();
    return { success: true };
  }
}

export const db = new DatabaseStore();
