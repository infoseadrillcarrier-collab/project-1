import { AccountData, Transaction, AuditLogEntry, BankNotification, Beneficiary } from '../src/types.js';

export const initialAccountData: AccountData = {
  accountHolderName: 'Aurelian House Investment Holdings Ltd.',
  accountNumber: 'LHT-9928-8472-1084',
  accountType: 'Private Heritage Trust & Sovereign Fiduciary Reserve',
  accountDescription: 'Primary fiduciary depository account holding institutional treasury assets, ring-fenced sovereign liquidity, and discretionary trust reserves under Litchfield Heritage Trust stewardship.',
  accountStatus: 'Active & Verified',
  currency: 'USD',
  currencySymbol: '$',
  currentBalance: 148250420.50,
  availableBalance: 142100000.00,
  totalDeposits: 215450000.00,
  totalWithdrawals: 67199579.50,
  routingNumber: '021000089',
  swiftBic: 'LHTRUS33XXX',
  iban: 'US33LHTR021000089992884721',
  custodianBank: 'Litchfield Heritage Trust Fiduciary Depository',
  custodianJurisdiction: 'New York / London Fiduciary District',
  relationshipManager: 'Lord Alistair Sterling, Senior Managing Trustee',
  relationshipEmail: 'a.sterling@litchfieldheritagetrust.com',
  announcements: 'Fiduciary Notice: Q3 2026 Capital Reserve Audit completed with Tier-1 Capital Adequacy ratio exceeding 28.4%. Depository balances remain fully ring-fenced.',
  fiduciaryRegistrationNumber: 'LHT-FID-88204-NYC',
  lastUpdated: new Date().toISOString(),
  lastAuditedBy: 'PricewaterhouseCoopers International Trust Advisory',
};

// Generate 102 realistic demonstration transactions from Jan 2020 through Nov 2026
const sampleDescriptions = [
  { desc: 'US Treasury 10-Yr Bond Coupon Liquidity Allocation', cat: 'Fixed Income', type: 'Deposit', min: 1200000, max: 4800000, cp: 'Federal Reserve Bank of NY / Treasury Custody' },
  { desc: 'Discretionary Private Equity Dividend Distribution', cat: 'Capital Distribution', type: 'Deposit', min: 2500000, max: 8500000, cp: 'Blackstone Strategic Capital Depository' },
  { desc: 'Quarterly Fiduciary Custody & Trustee Management Retainer', cat: 'Fiduciary Fee', type: 'Withdrawal', min: 145000, max: 350000, cp: 'Litchfield Heritage Trust Administration' },
  { desc: 'Institutional Sovereign Liquidity Repositioning Sweep', cat: 'Treasury Sweep', type: 'Internal Transfer', min: 3000000, max: 12000000, cp: 'LHT Sovereign Vault #4' },
  { desc: 'Swiss Private Banking Vault Liquidity Inflow', cat: 'Offshore Transfer', type: 'Deposit', min: 4000000, max: 15000000, cp: 'Pictet & Cie Bankers Geneva' },
  { desc: 'European Infrastructure Debt Fund Quarterly Yield', cat: 'Bond Yield', type: 'Deposit', min: 850000, max: 3200000, cp: 'BNP Paribas Arbitrage Depository' },
  { desc: 'Heritage Estate Capital Inflow & Fiduciary Realignment', cat: 'Trust Settlement', type: 'Deposit', min: 5000000, max: 18000000, cp: 'Rothschild & Co Fiduciary Escrow' },
  { desc: 'Discretionary Real Estate Syndication Liquidity Drawdown', cat: 'Capital Outflow', type: 'Withdrawal', min: 1800000, max: 6200000, cp: 'Brookfield Asset Management Escrow' },
  { desc: 'Municipal Clean Energy Infrastructure Green Bond Dividend', cat: 'Green Bonds', type: 'Deposit', min: 650000, max: 1950000, cp: 'Bank of New York Mellon Custody' },
  { desc: 'Cross-Border Fiduciary Escrow Settlement', cat: 'Escrow', type: 'External Transfer', min: 2200000, max: 7400000, cp: 'Standard Chartered Singapore Trust' },
  { desc: 'Sovereign Gold Bullion Storage & Allocated Vault Fee', cat: 'Custody Fee', type: 'Withdrawal', min: 85000, max: 190000, cp: 'Brinks Global Fiduciary Vaults Zurich' },
  { desc: 'Institutional Commercial Paper Settlement Redemption', cat: 'Money Market', type: 'Deposit', min: 3500000, max: 9200000, cp: 'JPMorgan Chase Treasury Division' },
  { desc: 'Annual Philanthropic Heritage Foundation Endowment Grant', cat: 'Philanthropy', type: 'Payment', min: 500000, max: 2500000, cp: 'Litchfield Global Charitable Foundation' },
  { desc: 'Demonstration Fiduciary Ledger Rebalancing Adjustment', cat: 'Ledger Balancing', type: 'Adjustment', min: 100000, max: 1500000, cp: 'LHT Internal Rebalancing Desk' },
  { desc: 'High-Yield Money Market Liquidity Sweep', cat: 'Money Market', type: 'Deposit', min: 1100000, max: 4300000, cp: 'Vanguard Treasury Fund' },
  { desc: 'London Stock Exchange Discretionary Portfolio Realization', cat: 'Equities', type: 'Deposit', min: 2100000, max: 6800000, cp: 'Barclays Wealth Nominees UK' },
  { desc: 'Tokyo Financial Exchange Japanese JGB Coupon Payment', cat: 'Fixed Income', type: 'Deposit', min: 950000, max: 2800000, cp: 'Mitsubishi UFJ Trust & Banking' },
  { desc: 'Discretionary Venture Growth Fund Capital Call', cat: 'Private Equity', type: 'Withdrawal', min: 1500000, max: 4500000, cp: 'Sequoia Heritage Capital LP' },
];

export function generateInitialTransactions(): Transaction[] {
  const transactions: Transaction[] = [];
  
  // Date schedule covering Jan 2020 to Nov 2026 (~7 years, ~102 transactions)
  const startDate = new Date('2020-01-14T10:00:00Z').getTime();
  const endDate = new Date('2026-10-28T14:30:00Z').getTime();
  const totalCount = 102;
  const timeStep = (endDate - startDate) / totalCount;

  let runningBalance = 42500000;

  for (let i = 0; i < totalCount; i++) {
    const itemDate = new Date(startDate + i * timeStep + ((i * 1373) % 432000000));
    const template = sampleDescriptions[i % sampleDescriptions.length];
    
    // Deterministic pseudo-random amount
    const rawVal = template.min + ((i * 7919 + 31) % (template.max - template.min));
    const roundedAmount = Math.round(rawVal / 500) * 500;
    
    let isPositive = false;
    if (template.type === 'Deposit') {
      runningBalance += roundedAmount;
      isPositive = true;
    } else if (template.type === 'Withdrawal' || template.type === 'Payment') {
      runningBalance = Math.max(15000000, runningBalance - roundedAmount);
      isPositive = false;
    } else if (template.type === 'Adjustment') {
      const adjustmentDelta = (i % 2 === 0 ? 1 : -1) * (roundedAmount / 2);
      runningBalance += adjustmentDelta;
      isPositive = adjustmentDelta > 0;
    } else {
      // Internal or External transfer
      if (i % 3 === 0) {
        runningBalance += roundedAmount;
        isPositive = true;
      } else {
        runningBalance = Math.max(20000000, runningBalance - roundedAmount);
        isPositive = false;
      }
    }

    const year = itemDate.getUTCFullYear();
    const month = String(itemDate.getUTCMonth() + 1).padStart(2, '0');
    const day = String(itemDate.getUTCDate()).padStart(2, '0');
    const dateStr = `${year}-${month}-${day}`;

    const refNumber = 1000 + (i * 87) % 8999;
    const ref = `LHT-TX-${year}-${refNumber}`;

    const statuses: Array<Transaction['status']> = ['Completed', 'Settled', 'Audited', 'Processing', 'Pending'];
    const status = statuses[i % statuses.length];

    transactions.push({
      id: `tx-demo-${i + 1}`,
      reference: ref,
      date: dateStr,
      description: template.desc,
      category: template.cat,
      type: template.type as Transaction['type'],
      amount: roundedAmount,
      balanceAfter: Math.round(runningBalance * 100) / 100,
      counterparty: template.cp,
      counterpartyBank: template.cp.includes('Bank') || template.cp.includes('Trust') ? template.cp : 'Tier-1 International Clearing Bank',
      status: status,
      notes: `Fiduciary transaction record verified under Depository Clearing Protocol #${year}-C${(i % 12) + 1}.`,
      isDemonstration: false,
    });
  }

  // Sort descending by date (most recent first)
  transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return transactions;
}

export const initialAuditLogs: AuditLogEntry[] = [
  {
    id: 'audit-001',
    timestamp: '2026-10-28T09:14:22.000Z',
    adminEmail: 'aurelianhouse777@gmail.com',
    action: 'Executive Demonstration Balance Re-alignment',
    category: 'BALANCE_ADJUSTMENT',
    previousValue: '$145,000,000.00',
    newValue: '$148,250,420.50',
    justification: 'Quarterly portfolio valuation alignment with sovereign coupon inflows and fiduciary vault inventory.',
  },
  {
    id: 'audit-002',
    timestamp: '2026-10-25T14:32:10.000Z',
    adminEmail: 'aurelianhouse777@gmail.com',
    action: 'Fiduciary Depository Notice Publication',
    category: 'SETTINGS_UPDATE',
    previousValue: 'Previous bulletin archived',
    newValue: 'Published Q3 2026 Capital Reserve Audit notification',
    justification: 'Scheduled fiduciary compliance disclosure for accredited trust participants.',
  },
  {
    id: 'audit-003',
    timestamp: '2026-10-15T11:05:44.000Z',
    adminEmail: 'aurelianhouse777@gmail.com',
    action: 'Administrator Authentication Handshake',
    category: 'SECURITY_SESSION',
    previousValue: 'Session Terminated',
    newValue: 'Authenticated (Passcode 777000)',
    justification: 'Routine administrative credential verification via primary business email.',
  },
  {
    id: 'audit-004',
    timestamp: '2026-09-30T16:48:19.000Z',
    adminEmail: 'aurelianhouse777@gmail.com',
    action: 'Account Profile Fiduciary Details Re-verification',
    category: 'PROFILE_UPDATE',
    previousValue: 'Tier-2 Fiduciary Custody',
    newValue: 'Private Heritage Trust & Sovereign Fiduciary Reserve',
    justification: 'Trust charter upgraded following institutional compliance certification.',
  },
];

export const initialNotifications: BankNotification[] = [
  {
    id: 'notif-1',
    timestamp: '2026-10-28T10:00:00.000Z',
    date: '2026-10-28',
    title: 'Tier-1 Capital Adequacy Report Published',
    message: 'The Q3 2026 independent fiduciary audit has been confirmed. Capital reserves remain backed by physical custody allocations and high-grade sovereign paper.',
    priority: 'regulatory',
    isRead: false,
  },
  {
    id: 'notif-2',
    timestamp: '2026-10-20T08:15:00.000Z',
    date: '2026-10-20',
    title: 'Institutional Fiduciary Settlement Guidelines',
    message: 'Notice: Outbound institutional transfer requests are subject to dual-signatory clearance and live gateway trustee verification.',
    priority: 'advisory',
    isRead: false,
  },
  {
    id: 'notif-3',
    timestamp: '2026-10-05T14:22:00.000Z',
    date: '2026-10-05',
    title: 'Annual Security Key Ring Rotation',
    message: 'Administrative cryptographic access keys and authorized email channel verifications were successfully renewed.',
    priority: 'routine',
    isRead: true,
  },
];

export const initialBeneficiaries: Beneficiary[] = [
  {
    id: 'ben-1',
    name: 'Rothschild & Co Fiduciary Escrow',
    bank: 'Rothschild Fiduciary Bankers AG',
    accountNumber: 'CH93-0024-0000-8812-4019-2',
    swiftBic: 'ROTCCHZZ',
    country: 'Switzerland',
    currency: 'USD',
    category: 'Institutional Escrow',
    lastTransferDate: '2026-09-18',
  },
  {
    id: 'ben-2',
    name: 'Pictet Sovereign Liquidity Custody',
    bank: 'Banque Pictet & Cie SA',
    accountNumber: 'CH18-0078-4000-2910-1102-8',
    swiftBic: 'PICTCHGG',
    country: 'Switzerland',
    currency: 'EUR',
    category: 'Private Vault Custody',
    lastTransferDate: '2026-08-11',
  },
  {
    id: 'ben-3',
    name: 'Bank of New York Mellon Trust Escrow',
    bank: 'The Bank of New York Mellon',
    accountNumber: 'US89-BNYM-0210-0001-9482-10',
    swiftBic: 'IRVTUS3N',
    country: 'United States',
    currency: 'USD',
    category: 'Depository Clearing',
    lastTransferDate: '2026-10-02',
  },
  {
    id: 'ben-4',
    name: 'Barclays Private Wealth Nominees UK',
    bank: 'Barclays Bank PLC London',
    accountNumber: 'GB29-BARC-2000-0081-9921-34',
    swiftBic: 'BARCGB22',
    country: 'United Kingdom',
    currency: 'GBP',
    category: 'Equities Custodian',
    lastTransferDate: '2026-07-29',
  },
];
