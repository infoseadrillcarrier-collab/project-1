import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import crypto from 'crypto';
import dotenv from 'dotenv';
import { db } from './server/db.js';
import { UserRole } from './src/types.js';

dotenv.config();

const app = express();
const PORT = 3000;
const isProduction = process.env.NODE_ENV === 'production';

app.use(express.json());

// In-memory token session manager
interface SessionInfo {
  token: string;
  role: UserRole;
  email: string;
  name: string;
  createdAt: number;
  expiresAt: number;
}

const sessions = new Map<string, SessionInfo>();
const failedAttempts = new Map<string, { count: number; lastAttempt: number }>();

// Auth Helper Middleware
function getSessionFromHeader(req: Request): SessionInfo | null {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) return null;
  const token = auth.slice(7).trim();
  const session = sessions.get(token);
  if (!session) return null;
  if (Date.now() > session.expiresAt) {
    sessions.delete(token);
    return null;
  }
  return session;
}

function requireAuth(req: Request, res: Response, next: NextFunction) {
  const session = getSessionFromHeader(req);
  if (!session) {
    return res.status(401).json({ error: 'Unauthorized: Session has expired or is invalid.' });
  }
  (req as any).session = session;
  next();
}

function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const session = getSessionFromHeader(req);
  if (!session || session.role !== 'admin') {
    return res.status(403).json({ error: 'Access Denied: Administrative privileges required.' });
  }
  (req as any).session = session;
  next();
}

// ----------------- API ROUTES -----------------

// 1. Validate Business Email (Stage One)
app.post('/api/auth/validate-email', (req: Request, res: Response) => {
  const { email } = req.body;
  if (!email || typeof email !== 'string') {
    return res.status(400).json({ error: 'Please enter a valid business email address.' });
  }

  const cleanEmail = email.trim().toLowerCase();
  const AUTHORIZED_EMAIL = 'aurelianhouse777@gmail.com';

  if (cleanEmail === AUTHORIZED_EMAIL) {
    return res.json({
      valid: true,
      message: 'Email successfully verified against authorized institutional register.',
      registeredEmail: AUTHORIZED_EMAIL,
    });
  } else {
    return res.status(403).json({
      valid: false,
      error: 'The provided email is not registered as an authorized business account for Litchfield Heritage Trust. Please contact your Fiduciary Representative.',
    });
  }
});

// 2. Verify Access Code (Stage Three)
app.post('/api/auth/verify-code', (req: Request, res: Response) => {
  const { email, code } = req.body;
  const clientIp = req.ip || 'remote';

  // Rate-limiting check
  const now = Date.now();
  const attemptInfo = failedAttempts.get(clientIp) || { count: 0, lastAttempt: 0 };
  
  if (attemptInfo.count >= 6 && now - attemptInfo.lastAttempt < 60000) {
    const secondsRemaining = Math.ceil((60000 - (now - attemptInfo.lastAttempt)) / 1000);
    return res.status(429).json({
      error: `Too many failed attempts. For fiduciary security, please wait ${secondsRemaining} seconds before trying again.`,
    });
  }

  const cleanEmail = (email || '').trim().toLowerCase();
  const cleanCode = (code || '').trim();

  const AUTHORIZED_EMAIL = 'aurelianhouse777@gmail.com';
  const ADMIN_CODE = '777000';
  const VISITOR_CODE = 'EBSN98765';

  if (cleanEmail !== AUTHORIZED_EMAIL) {
    return res.status(401).json({
      error: 'Invalid access code. Please verify your access credentials and try again.',
    });
  }

  let role: UserRole | null = null;
  let userName = '';

  if (cleanCode === ADMIN_CODE) {
    role = 'admin';
    userName = 'Executive Trustee & System Administrator';
  } else if (cleanCode === VISITOR_CODE) {
    role = 'visitor';
    userName = 'Authorized Account Delegate';
  }

  if (!role) {
    // Record failure
    failedAttempts.set(clientIp, {
      count: attemptInfo.count + 1,
      lastAttempt: now,
    });

    return res.status(401).json({
      error: 'Invalid access code. Please verify your access credentials and try again.',
    });
  }

  // Clear failed attempts upon success
  failedAttempts.delete(clientIp);

  // Generate cryptographic session token
  const token = crypto.randomBytes(32).toString('hex');
  const session: SessionInfo = {
    token,
    role,
    email: cleanEmail,
    name: userName,
    createdAt: now,
    expiresAt: now + 24 * 60 * 60 * 1000, // 24 hours
  };
  sessions.set(token, session);

  // Log administrative login to audit log
  if (role === 'admin') {
    db.addAuditLog({
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString(),
      adminEmail: cleanEmail,
      action: 'Administrator Authentication Handshake',
      category: 'SECURITY_SESSION',
      previousValue: 'Session Inactive',
      newValue: 'Authenticated (Passcode 777000)',
      justification: 'Executive trustee login via primary business email and administrator passcode.',
    });
  }

  return res.json({
    success: true,
    token,
    role,
    user: {
      email: cleanEmail,
      name: userName,
      role,
    },
  });
});

// 3. Current Session
app.get('/api/auth/session', (req: Request, res: Response) => {
  const session = getSessionFromHeader(req);
  if (!session) {
    return res.json({ authenticated: false });
  }
  return res.json({
    authenticated: true,
    role: session.role,
    user: {
      email: session.email,
      name: session.name,
      role: session.role,
    },
  });
});

// 4. Logout
app.post('/api/auth/logout', (req: Request, res: Response) => {
  const session = getSessionFromHeader(req);
  if (session) {
    if (session.role === 'admin') {
      db.addAuditLog({
        id: `audit-${Date.now()}`,
        timestamp: new Date().toISOString(),
        adminEmail: session.email,
        action: 'Administrator Session Terminated',
        category: 'SECURITY_SESSION',
        previousValue: 'Active Administrative Session',
        newValue: 'Logged Out',
        justification: 'Explicit user sign-out from executive administrative dashboard.',
      });
    }
    sessions.delete(session.token);
  }
  return res.json({ success: true, message: 'Session securely terminated.' });
});

// 5. Account Data (Accessible to both Visitor and Admin)
app.get('/api/account', (req: Request, res: Response) => {
  const account = db.getAccount();
  return res.json({ account });
});

// 6. Update Account Profile (Admin Only)
app.put('/api/account/profile', requireAdmin, (req: Request, res: Response) => {
  const session = (req as any).session as SessionInfo;
  const updates = req.body.updates;
  const justification = req.body.justification || 'Administrative profile configuration adjustment';

  if (!updates || typeof updates !== 'object') {
    return res.status(400).json({ error: 'Invalid updates payload provided.' });
  }

  const updatedAccount = db.updateAccountProfile(updates, session.email, justification);
  return res.json({ success: true, account: updatedAccount });
});

// 7. Update Balance (Admin Only - Requires Justification)
app.post('/api/account/balance', requireAdmin, (req: Request, res: Response) => {
  const session = (req as any).session as SessionInfo;
  const { currentBalance, availableBalance, justification } = req.body;

  if (currentBalance === undefined || isNaN(Number(currentBalance))) {
    return res.status(400).json({ error: 'A valid numeric current balance is required.' });
  }

  if (availableBalance === undefined || isNaN(Number(availableBalance))) {
    return res.status(400).json({ error: 'A valid numeric available balance is required.' });
  }

  if (!justification || typeof justification !== 'string' || justification.trim().length < 5) {
    return res.status(400).json({
      error: 'A mandatory administrative justification (minimum 5 characters) is required to record a balance adjustment in the audit ledger.',
    });
  }

  const updatedAccount = db.updateBalance(
    Number(currentBalance),
    Number(availableBalance),
    session.email,
    justification.trim()
  );

  return res.json({
    success: true,
    message: 'Demonstration balance successfully calibrated and recorded in the audit trail.',
    account: updatedAccount,
  });
});

// 8. Transactions List
app.get('/api/transactions', (req: Request, res: Response) => {
  const { search, type, status, startDate, endDate } = req.query;
  const transactions = db.getTransactions({
    search: search as string,
    type: type as string,
    status: status as string,
    startDate: startDate as string,
    endDate: endDate as string,
  });
  return res.json({ transactions, total: transactions.length });
});

// 9. Add Demonstration Transaction (Admin Only)
app.post('/api/transactions', requireAdmin, (req: Request, res: Response) => {
  const session = (req as any).session as SessionInfo;
  const { description, category, type, amount, counterparty, counterpartyBank, status, notes } = req.body;

  if (!description || !type || amount === undefined || isNaN(Number(amount))) {
    return res.status(400).json({ error: 'Description, type, and valid numeric amount are required.' });
  }

  const year = new Date().getFullYear();
  const ref = `LHT-TX-${year}-${Math.floor(1000 + Math.random() * 9000)}`;

  const tx = db.addTransaction(
    {
      reference: ref,
      date: new Date().toISOString().split('T')[0],
      description,
      category: category || 'General Treasury',
      type,
      amount: Number(amount),
      counterparty: counterparty || 'Authorized Institutional Counterparty',
      counterpartyBank: counterpartyBank || 'LHT Clearing Depository',
      status: status || 'Completed',
      notes: notes || 'Demonstration transaction entered via Administrative Dashboard.',
    },
    session.email
  );

  return res.json({ success: true, transaction: tx });
});

// 10. Update Transaction Status (Admin Only)
app.put('/api/transactions/:id', requireAdmin, (req: Request, res: Response) => {
  const session = (req as any).session as SessionInfo;
  const id = req.params.id;
  const updates = req.body;

  const updated = db.updateTransaction(id, updates, session.email);
  if (!updated) {
    return res.status(404).json({ error: 'Transaction not found.' });
  }

  return res.json({ success: true, transaction: updated });
});

// 11. Audit Logs (Admin Only)
app.get('/api/audit-logs', requireAdmin, (_req: Request, res: Response) => {
  const logs = db.getAuditLogs();
  return res.json({ auditLogs: logs });
});

// 12. Beneficiaries
app.get('/api/beneficiaries', (_req: Request, res: Response) => {
  const beneficiaries = db.getBeneficiaries();
  return res.json({ beneficiaries });
});

// 13. Notifications
app.get('/api/notifications', (_req: Request, res: Response) => {
  const notifications = db.getNotifications();
  return res.json({ notifications });
});

app.post('/api/notifications', requireAdmin, (req: Request, res: Response) => {
  const session = (req as any).session as SessionInfo;
  const { title, message, priority } = req.body;

  if (!title || !message) {
    return res.status(400).json({ error: 'Title and message are required.' });
  }

  const notif = db.addNotification(
    {
      title,
      message,
      priority: priority || 'routine',
      date: new Date().toISOString().split('T')[0],
    },
    session.email
  );

  return res.json({ success: true, notification: notif });
});

// 14. Domestic Transfer Submission
app.post('/api/transfers/domestic', requireAuth, (req: Request, res: Response) => {
  const { recipientName, recipientAccount, receivingInstitution, amount, currency, description, reference } = req.body;

  const demoRef = reference || `LHT-DM-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;
  const now = new Date();

  return res.json({
    status: 'failed',
    errorTitle: 'Transaction Unsuccessful',
    errorMessage:
      'The automated domestic clearing rail could not settle this transfer with the receiving depository. No funds have been transferred or deducted from your account balance.',
    transferDetails: {
      reference: demoRef,
      recipientName,
      recipientAccount: recipientAccount ? `•••• ${recipientAccount.slice(-4)}` : '•••• 9942',
      receivingInstitution: receivingInstitution || 'Commercial Clearing Bank',
      amount: Number(amount || 0),
      currency: currency || 'USD',
      description: description || 'Domestic Transfer',
      failureReason: 'Clearing Gateway Response: Real-time ACH settlement route requires pre-certified correspondent mandate.',
      timestamp: now.toISOString(),
      formattedTime: now.toLocaleString('en-US', {
        dateStyle: 'medium',
        timeStyle: 'medium',
      }),
      nextSteps: [
        'Verify recipient depository routing and account number.',
        'Confirm that the receiving financial institution supports direct institutional ledger settlement.',
        'Contact your Senior Managing Trustee to request manual correspondent wire clearance.',
      ],
    },
  });
});

// 15. International Wire Transfer Submission
app.post('/api/transfers/wire', requireAuth, (req: Request, res: Response) => {
  const {
    beneficiaryName,
    beneficiaryBank,
    bankAddress,
    accountOrIban,
    swiftBic,
    destinationCountry,
    transferCurrency,
    transferAmount,
    paymentPurpose,
    remarks,
  } = req.body;

  const demoRef = `LHT-WR-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;
  const now = new Date();

  return res.json({
    status: 'failed',
    errorTitle: 'Transaction Unsuccessful',
    errorMessage:
      'The international correspondent clearing network was unable to settle this transfer corridor. No funds have been deducted or transferred from your account.',
    transferDetails: {
      reference: demoRef,
      beneficiaryName,
      beneficiaryBank: beneficiaryBank || 'International Correspondent Bank',
      bankAddress,
      accountOrIban: accountOrIban ? `•••• ${accountOrIban.slice(-4)}` : '•••• 8821',
      swiftBic,
      destinationCountry,
      transferCurrency: transferCurrency || 'USD',
      transferAmount: Number(transferAmount || 0),
      paymentPurpose,
      remarks,
      failureReason:
        'Correspondent Gateway: SWIFT/ISO-20022 real-time settlement gateway requires institutional verification for this cross-border corridor.',
      timestamp: now.toISOString(),
      formattedTime: now.toLocaleString('en-US', {
        dateStyle: 'medium',
        timeStyle: 'medium',
      }),
      nextSteps: [
        'Verify the beneficiary SWIFT/BIC and IBAN formatting.',
        'Confirm cross-border liquidity limits with your relationship manager.',
        'Contact your Senior Managing Trustee to initiate direct escrow clearance.',
      ],
    },
  });
});

// 16. Reset System State (Admin Only)
app.post('/api/admin/reset', requireAdmin, (req: Request, res: Response) => {
  const session = (req as any).session as SessionInfo;
  db.resetToDefaults(session.email);
  return res.json({ success: true, message: 'Database reset to default seed demonstration data.' });
});

// ----------------- VITE / STATIC HANDLING -----------------

async function startServer() {
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Litchfield Heritage Trust Platform server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
