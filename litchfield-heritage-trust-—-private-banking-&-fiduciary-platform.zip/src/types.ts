export type UserRole = 'admin' | 'visitor';

export interface AccountData {
  accountHolderName: string;
  accountNumber: string;
  accountType: string;
  accountDescription: string;
  accountStatus: 'Active & Verified' | 'Audited & In Good Standing' | 'Restricted' | 'Under Periodic Review';
  currency: string;
  currencySymbol: string;
  currentBalance: number;
  availableBalance: number;
  totalDeposits: number;
  totalWithdrawals: number;
  routingNumber: string;
  swiftBic: string;
  iban: string;
  custodianBank: string;
  custodianJurisdiction: string;
  relationshipManager: string;
  relationshipEmail: string;
  announcements: string;
  fiduciaryRegistrationNumber: string;
  lastUpdated: string;
  lastAuditedBy: string;
}

export type TransactionType =
  | 'Deposit'
  | 'Withdrawal'
  | 'Internal Transfer'
  | 'External Transfer'
  | 'Adjustment'
  | 'Payment';

export type TransactionStatus =
  | 'Pending'
  | 'Processing'
  | 'Completed'
  | 'Settled'
  | 'Audited'
  | 'Failed'
  | 'Reversed';

export interface Transaction {
  id: string;
  reference: string;
  date: string; // ISO YYYY-MM-DD
  description: string;
  category: string;
  type: TransactionType;
  amount: number;
  balanceAfter?: number;
  counterparty: string;
  counterpartyBank?: string;
  status: TransactionStatus;
  notes?: string;
  isDemonstration: boolean;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  adminEmail: string;
  action: string;
  category: 'BALANCE_ADJUSTMENT' | 'PROFILE_UPDATE' | 'TRANSACTION_MANAGEMENT' | 'SECURITY_SESSION' | 'SETTINGS_UPDATE';
  previousValue?: string;
  newValue?: string;
  justification: string;
}

export interface BankNotification {
  id: string;
  timestamp: string;
  title: string;
  message: string;
  priority: 'routine' | 'advisory' | 'regulatory';
  date: string;
  isRead?: boolean;
}

export interface Beneficiary {
  id: string;
  name: string;
  bank: string;
  accountNumber: string;
  swiftBic: string;
  country: string;
  currency: string;
  category: string;
  lastTransferDate: string;
}

export interface AuthSession {
  token: string;
  role: UserRole;
  email: string;
  name: string;
  expiresAt: number;
}
