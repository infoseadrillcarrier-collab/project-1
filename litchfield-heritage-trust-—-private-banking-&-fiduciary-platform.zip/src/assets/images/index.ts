// Curated institutional photography collection for Litchfield Heritage Trust
export const brandImages = {
  heroBankingHeadquarters: '/src/assets/images/hero_banking_headquarters_1793636837664.jpg',
  aboutHeritageBuilding: '/src/assets/images/about_heritage_building_1793636839577.jpg',
  servicePersonalBanking: '/src/assets/images/service_personal_banking_1793636841541.jpg',
  serviceBusinessBanking: '/src/assets/images/service_business_banking_1793636841370.jpg',
  serviceWealthManagement: '/src/assets/images/service_wealth_management_1793636843227.jpg',
  serviceInvestmentPlanning: '/src/assets/images/service_investment_planning_1793636843750.jpg',
  serviceFinancialPlanning: '/src/assets/images/service_financial_planning_1793636846000.jpg',
  whyChooseHeritage: '/src/assets/images/why_choose_heritage_1793636846982.jpg',
  educationResourceWorkspace: '/src/assets/images/education_resource_workspace_1793636848081.jpg',
  contactReceptionInterior: '/src/assets/images/contact_reception_interior_1793636849679.jpg',
  footerNavyArchitectural: '/src/assets/images/footer_navy_architectural_1793636848337.jpg',
};
