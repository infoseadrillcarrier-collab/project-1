import React, { useEffect, useState } from 'react';
import { BrandLogo } from './BrandLogo';
import { EightDotSpinner } from './EightDotSpinner';
import { ShieldCheck, Lock } from 'lucide-react';

interface AuthLoadingScreenProps {
  type: 'login' | 'logout';
  targetRole?: 'admin' | 'visitor';
  onComplete: () => void;
}

export const AuthLoadingScreen: React.FC<AuthLoadingScreenProps> = ({
  type,
  onComplete,
}) => {
  const durationSeconds = type === 'login' ? 45 : 2.5;
  const [secondsRemaining, setSecondsRemaining] = useState(durationSeconds);
  const [statusMessage, setStatusMessage] = useState(
    type === 'login'
      ? 'Establishing Encrypted Trust Protocol & TLS Handshake...'
      : 'Terminating Cryptographic Session & Flushing Fiduciary Cache...'
  );

  useEffect(() => {
    const startTime = Date.now();
    const totalMs = durationSeconds * 1000;

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(1, elapsed / totalMs);
      const remaining = Math.max(0, Math.ceil((totalMs - elapsed) / 1000));
      setSecondsRemaining(remaining);

      if (type === 'login') {
        if (progress < 0.2) {
          setStatusMessage('Establishing Encrypted Trust Protocol & TLS Handshake...');
        } else if (progress < 0.4) {
          setStatusMessage('Verifying Institutional Business Email & Authorization Certificate...');
        } else if (progress < 0.65) {
          setStatusMessage('Mounting Tier-1 Fiduciary Depository & Sovereign Ledgers...');
        } else if (progress < 0.85) {
          setStatusMessage('Synchronizing Discretionary Reserve & Real-Time Balances...');
        } else if (progress < 0.98) {
          setStatusMessage('Finalizing Cryptographic Session & Portal Routing...');
        } else {
          setStatusMessage('Verification Complete. Entering Banking Environment...');
        }
      } else {
        if (progress < 0.5) {
          setStatusMessage('Flushing Local Cryptographic Keys...');
        } else {
          setStatusMessage('Returning to Institutional Login...');
        }
      }

      if (elapsed >= totalMs) {
        clearInterval(interval);
        onComplete();
      }
    }, 150);

    return () => clearInterval(interval);
  }, [durationSeconds, onComplete, type]);

  const progressFraction = Math.min(1, (durationSeconds - secondsRemaining) / durationSeconds);
  const progressPercent = Math.round(progressFraction * 100);

  return (
    <div className="fixed inset-0 z-50 bg-[#071933] text-white flex flex-col items-center justify-center p-6 select-none overflow-hidden font-sans-body">
      {/* Background radial glow */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#0B2548]/80 via-[#071933] to-[#040e1d] -z-10 pointer-events-none" />
      
      {/* Subtle geometric grid accent */}
      <div 
        className="absolute inset-0 opacity-[0.03] -z-10 pointer-events-none"
        style={{
          backgroundImage: 'linear-gradient(#C5921E 1px, transparent 1px), linear-gradient(to right, #C5921E 1px, transparent 1px)',
          backgroundSize: '40px 40px'
        }}
      />

      <div className="w-full max-w-md mx-auto flex flex-col items-center text-center">
        {/* Brand logo container */}
        <div className="bg-white/95 rounded-2xl p-4 shadow-2xl shadow-black/40 border border-[#C5921E]/30 mb-8 backdrop-blur-md">
          <BrandLogo size="lg" />
        </div>

        {/* Eight-Dot Circular Moving Animation */}
        <div className="mb-6">
          <EightDotSpinner
            size={144}
            percentage={type === 'login' ? progressPercent : undefined}
            timeLabel={type === 'login' ? `${secondsRemaining}s` : undefined}
          />
        </div>

        {/* Welcome & Status Headlines */}
        <h2 className="font-serif-display text-2xl font-semibold text-white tracking-wide mb-2">
          {type === 'login' ? 'Authenticating Secure Session' : 'Closing Banking Session'}
        </h2>

        <p className="font-sans-body text-xs sm:text-sm text-slate-300 min-h-[44px] flex items-center justify-center px-4 leading-relaxed max-w-sm">
          {statusMessage}
        </p>

        {/* Security badge */}
        <div className="mt-6 flex items-center gap-2 text-xs text-slate-400 bg-white/5 py-1.5 px-3.5 rounded-full border border-white/10">
          <ShieldCheck className="w-3.5 h-3.5 text-[#C5921E]" />
          <span className="tracking-wide">256-Bit Fiduciary Encryption Active</span>
        </div>
      </div>
    </div>
  );
};
