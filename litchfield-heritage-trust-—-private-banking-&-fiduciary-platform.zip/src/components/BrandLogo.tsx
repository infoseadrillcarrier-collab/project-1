import React, { useState } from 'react';

interface BrandLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
  lightMode?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  className = '',
  size = 'md',
  showSubtitle = true,
}) => {
  const [imageError, setImageError] = useState(false);

  const sizeClasses = {
    sm: 'h-8',
    md: 'h-12',
    lg: 'h-16',
    xl: 'h-24',
  };

  const imageSrc = '/assets/aistudio/Litchfield_Heritage_Trust_Logo_850b2143.png';

  if (imageError) {
    return (
      <div className={`flex items-center gap-3 ${className}`}>
        <div className="w-10 h-10 rounded-lg bg-[#0B2548] text-[#C5921E] flex items-center justify-center font-serif-display font-bold text-xl border border-[#C5921E]/30 shadow-sm">
          LHT
        </div>
        <div>
          <div className="font-serif-display font-bold text-lg tracking-tight text-[#0B2548] leading-none">
            Litchfield Heritage Trust
          </div>
          {showSubtitle && (
            <div className="text-[10px] tracking-[0.2em] uppercase font-semibold text-[#C5921E] mt-0.5">
              Your Trust. Our Heritage.
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className={`inline-flex items-center ${className}`}>
      <img
        src={imageSrc}
        alt="Litchfield Heritage Trust Logo"
        className={`${sizeClasses[size]} w-auto object-contain transition-transform`}
        onError={() => setImageError(true)}
      />
    </div>
  );
};
