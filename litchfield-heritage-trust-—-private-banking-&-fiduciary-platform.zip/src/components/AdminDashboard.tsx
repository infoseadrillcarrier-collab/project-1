import React, { useState } from 'react';
import { AccountData, Transaction, AuditLogEntry, BankNotification } from '../types';
import { BrandLogo } from './BrandLogo';
import { api } from '../api';
import {
  LayoutDashboard,
  UserCheck,
  DollarSign,
  Receipt,
  FileClock,
  Bell,
  Settings,
  LogOut,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  TrendingDown,
  Building,
  Key,
  RefreshCw,
  Search,
  PlusCircle,
  Eye,
  Check,
  Database,
  Lock,
} from 'lucide-react';

interface AdminDashboardProps {
  account: AccountData;
  transactions: Transaction[];
  auditLogs: AuditLogEntry[];
  notifications: BankNotification[];
  adminEmail: string;
  onRefreshData: () => Promise<void>;
  onLogout: () => void;
}

type AdminTab =
  | 'dashboard'
  | 'profile'
  | 'balance'
  | 'transactions'
  | 'audit'
  | 'notifications'
  | 'settings';

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  account,
  transactions,
  auditLogs,
  notifications,
  adminEmail,
  onRefreshData,
  onLogout,
}) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successBanner, setSuccessBanner] = useState<string | null>(null);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);

  // Profile Edit State
  const [profileForm, setProfileForm] = useState({
    accountHolderName: account.accountHolderName,
    accountType: account.accountType,
    accountNumber: account.accountNumber,
    accountDescription: account.accountDescription,
    accountStatus: account.accountStatus,
    currency: account.currency,
    currencySymbol: account.currencySymbol,
    announcements: account.announcements,
    relationshipManager: account.relationshipManager,
    routingNumber: account.routingNumber,
    swiftBic: account.swiftBic,
    iban: account.iban,
    justification: '',
  });

  // Balance Edit State
  const [balanceForm, setBalanceForm] = useState({
    currentBalance: account.currentBalance.toString(),
    availableBalance: account.availableBalance.toString(),
    justification: '',
  });

  // Transaction Search & Filter State
  const [txSearch, setTxSearch] = useState('');
  const [txTypeFilter, setTxTypeFilter] = useState('all');
  const [showAddTxModal, setShowAddTxModal] = useState(false);
  const [newTxForm, setNewTxForm] = useState({
    description: '',
    category: 'Fixed Income',
    type: 'Deposit' as Transaction['type'],
    amount: '',
    counterparty: '',
    counterpartyBank: '',
    notes: '',
  });

  // New Notification State
  const [notifForm, setNotifForm] = useState({
    title: '',
    message: '',
    priority: 'routine' as BankNotification['priority'],
  });

  const clearBanners = () => {
    setSuccessBanner(null);
    setErrorBanner(null);
  };

  // Submit Profile Changes
  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearBanners();
    if (!profileForm.justification.trim()) {
      setErrorBanner('A mandatory administrative justification is required to record profile changes in the audit ledger.');
      return;
    }

    setIsSubmitting(true);
    try {
      const updates: Partial<AccountData> = {
        accountHolderName: profileForm.accountHolderName.trim(),
        accountType: profileForm.accountType.trim(),
        accountNumber: profileForm.accountNumber.trim(),
        accountDescription: profileForm.accountDescription.trim(),
        accountStatus: profileForm.accountStatus as any,
        currency: profileForm.currency.trim(),
        currencySymbol: profileForm.currencySymbol.trim(),
        announcements: profileForm.announcements.trim(),
        relationshipManager: profileForm.relationshipManager.trim(),
        routingNumber: profileForm.routingNumber.trim(),
        swiftBic: profileForm.swiftBic.trim(),
        iban: profileForm.iban.trim(),
      };

      await api.updateAccountProfile(updates, profileForm.justification.trim());
      await onRefreshData();
      setSuccessBanner('Account profile updated successfully. Synchronized to all visitor banking sessions.');
      setProfileForm((prev) => ({ ...prev, justification: '' }));
    } catch (err: any) {
      setErrorBanner(err.message || 'Failed to update account profile.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Submit Balance Changes
  const handleBalanceSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearBanners();
    const curr = parseFloat(balanceForm.currentBalance);
    const avail = parseFloat(balanceForm.availableBalance);

    if (isNaN(curr) || isNaN(avail) || curr < 0 || avail < 0) {
      setErrorBanner('Please enter valid non-negative numbers for displayed and available balances.');
      return;
    }

    if (!balanceForm.justification.trim() || balanceForm.justification.trim().length < 5) {
      setErrorBanner('A mandatory justification (minimum 5 characters) is required for fiduciary audit logging.');
      return;
    }

    setIsSubmitting(true);
    try {
      await api.updateBalance(curr, avail, balanceForm.justification.trim());
      await onRefreshData();
      setSuccessBanner('Demonstration balances successfully updated and synchronized to Visitor Dashboard.');
      setBalanceForm((prev) => ({ ...prev, justification: '' }));
    } catch (err: any) {
      setErrorBanner(err.message || 'Failed to update demonstration balance.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Submit New Transaction
  const handleAddTxSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearBanners();
    const amt = parseFloat(newTxForm.amount);
    if (!newTxForm.description.trim() || isNaN(amt) || amt <= 0) {
      setErrorBanner('Please provide a valid description and positive amount.');
      return;
    }

    setIsSubmitting(true);
    try {
      await api.addTransaction({
        description: newTxForm.description.trim(),
        category: newTxForm.category,
        type: newTxForm.type,
        amount: amt,
        counterparty: newTxForm.counterparty.trim() || 'Authorized Institutional Entity',
        counterpartyBank: newTxForm.counterpartyBank.trim() || 'LHT International Depository',
        notes: newTxForm.notes.trim() || 'Manual demonstration transaction entered by Administrator.',
        status: 'Completed',
      });
      await onRefreshData();
      setShowAddTxModal(false);
      setNewTxForm({
        description: '',
        category: 'Fixed Income',
        type: 'Deposit',
        amount: '',
        counterparty: '',
        counterpartyBank: '',
        notes: '',
      });
      setSuccessBanner('Demonstration transaction added to ledger successfully.');
    } catch (err: any) {
      setErrorBanner(err.message || 'Failed to add demonstration transaction.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Submit Notification
  const handleNotifSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearBanners();
    if (!notifForm.title.trim() || !notifForm.message.trim()) {
      setErrorBanner('Please enter both a title and message for the announcement.');
      return;
    }

    setIsSubmitting(true);
    try {
      await api.addNotification(notifForm.title.trim(), notifForm.message.trim(), notifForm.priority);
      await onRefreshData();
      setNotifForm({ title: '', message: '', priority: 'routine' });
      setSuccessBanner('Announcement successfully broadcast to visitor dashboard.');
    } catch (err: any) {
      setErrorBanner(err.message || 'Failed to broadcast announcement.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // System Reset
  const handleResetSystem = async () => {
    if (confirm('Are you sure you want to reset the demonstration database to initial factory values? All customized balances and audit logs will be reset.')) {
      setIsSubmitting(true);
      try {
        await api.resetDatabase();
        await onRefreshData();
        setSuccessBanner('Demonstration database reset to factory defaults.');
      } catch (err: any) {
        setErrorBanner(err.message || 'Reset failed.');
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  const filteredTx = transactions.filter((t) => {
    const matchesSearch =
      t.description.toLowerCase().includes(txSearch.toLowerCase()) ||
      t.reference.toLowerCase().includes(txSearch.toLowerCase()) ||
      t.counterparty.toLowerCase().includes(txSearch.toLowerCase());
    const matchesType = txTypeFilter === 'all' || t.type.toLowerCase() === txTypeFilter.toLowerCase();
    return matchesSearch && matchesType;
  });

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans-body text-slate-800">
      
      {/* Top Administrative Header */}
      <header className="bg-[#0B2548] text-white border-b-2 border-[#C5921E] sticky top-0 z-30 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="bg-white rounded-lg p-2 shadow-xs">
              <BrandLogo size="md" />
            </div>
            <div className="hidden sm:block">
              <div className="flex items-center gap-2">
                <span className="font-serif-display font-bold text-lg text-white">
                  Executive Administrative Portal
                </span>
                <span className="bg-[#C5921E] text-[#071933] text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded">
                  Admin Mode (777000)
                </span>
              </div>
              <div className="text-xs text-slate-300 flex items-center gap-2">
                <span>Authorized Trustee: <strong className="text-white">{adminEmail}</strong></span>
                <span>·</span>
                <span className="inline-flex items-center gap-1 text-emerald-400">
                  <Database className="w-3 h-3" /> Live Persistent Database
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onRefreshData()}
              className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-slate-200 transition-colors"
              title="Refresh Shared Database"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              onClick={onLogout}
              className="flex items-center gap-2 py-2 px-3.5 rounded-lg text-xs font-semibold bg-rose-900/80 hover:bg-rose-800 text-rose-100 transition-colors border border-rose-700/50"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Logout</span>
            </button>
          </div>
        </div>

        {/* Admin Navigation Bar */}
        <div className="bg-[#071933] border-t border-slate-700 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto flex items-center gap-1 sm:gap-2 overflow-x-auto py-2 no-scrollbar">
            {[
              { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
              { id: 'profile', label: 'Account Profile', icon: UserCheck },
              { id: 'balance', label: 'Balance Management', icon: DollarSign },
              { id: 'transactions', label: 'Transaction Manager', icon: Receipt },
              { id: 'audit', label: 'Audit Log', icon: FileClock },
              { id: 'notifications', label: 'Announcements', icon: Bell },
              { id: 'settings', label: 'Settings', icon: Settings },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    clearBanners();
                    setActiveTab(tab.id as AdminTab);
                  }}
                  className={`flex items-center gap-2 py-2 px-3 sm:px-4 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                    isActive
                      ? 'bg-[#C5921E] text-[#071933] font-bold shadow-xs'
                      : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        
        {/* Success Alert */}
        {successBanner && (
          <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-emerald-800 text-xs sm:text-sm animate-in fade-in">
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>{successBanner}</span>
            </div>
            <button onClick={clearBanners} className="text-emerald-600 hover:text-emerald-900 text-xs font-bold">
              Dismiss
            </button>
          </div>
        )}

        {/* Error Alert */}
        {errorBanner && (
          <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl flex items-center justify-between text-rose-800 text-xs sm:text-sm animate-in fade-in">
            <div className="flex items-center gap-2.5">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
              <span>{errorBanner}</span>
            </div>
            <button onClick={clearBanners} className="text-rose-600 hover:text-rose-900 text-xs font-bold">
              Dismiss
            </button>
          </div>
        )}

        {/* ================= TAB 1: DASHBOARD ================= */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            
            {/* Executive KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <span className="text-xs uppercase tracking-wider text-slate-500 font-semibold block mb-1">
                  Current Displayed Balance
                </span>
                <div className="font-serif-display text-2xl lg:text-3xl font-bold text-[#0B2548] tabular-nums">
                  {account.currencySymbol}{account.currentBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                </div>
                <div className="text-[11px] text-slate-500 mt-2 flex items-center justify-between">
                  <span>Currency: {account.currency}</span>
                  <button
                    onClick={() => setActiveTab('balance')}
                    className="text-[#C5921E] hover:underline font-semibold"
                  >
                    Adjust →
                  </button>
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <span className="text-xs uppercase tracking-wider text-slate-500 font-semibold block mb-1">
                  Available Displayed Balance
                </span>
                <div className="font-serif-display text-2xl lg:text-3xl font-bold text-emerald-700 tabular-nums">
                  {account.currencySymbol}{account.availableBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                </div>
                <div className="text-[11px] text-slate-500 mt-2">
                  Immediate liquidity allocation
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <span className="text-xs uppercase tracking-wider text-slate-500 font-semibold block mb-1">
                  Cumulative Inflows (Deposits)
                </span>
                <div className="font-serif-display text-2xl lg:text-3xl font-bold text-slate-900 tabular-nums">
                  {account.currencySymbol}{account.totalDeposits.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                </div>
                <div className="text-[11px] text-slate-500 mt-2 flex items-center gap-1 text-emerald-600">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>Sovereign & Discretionary Yields</span>
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <span className="text-xs uppercase tracking-wider text-slate-500 font-semibold block mb-1">
                  Ledger Transactions
                </span>
                <div className="font-serif-display text-2xl lg:text-3xl font-bold text-slate-900 tabular-nums">
                  {transactions.length} Records
                </div>
                <div className="text-[11px] text-slate-500 mt-2 flex items-center justify-between">
                  <span>2020 – 2026 Archive</span>
                  <button
                    onClick={() => setActiveTab('transactions')}
                    className="text-[#0B2548] hover:underline font-semibold"
                  >
                    View All →
                  </button>
                </div>
              </div>
            </div>

            {/* Quick Synchronized State Review */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-[#C5921E]" />
                  <h3 className="font-serif-display font-bold text-lg text-[#0B2548]">
                    Shared Persistent Fiduciary Repository
                  </h3>
                </div>
                <span className="text-xs text-slate-400">
                  Last Synced: {new Date(account.lastUpdated).toLocaleTimeString()}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
                <div>
                  <span className="text-slate-500 font-semibold uppercase text-[10px] block">Active Account Holder</span>
                  <div className="font-serif-display font-bold text-base text-slate-900 mt-0.5">
                    {account.accountHolderName}
                  </div>
                  <p className="text-slate-500 text-[11px] mt-1">{account.accountNumber}</p>
                </div>

                <div>
                  <span className="text-slate-500 font-semibold uppercase text-[10px] block">Account Classification</span>
                  <div className="font-medium text-slate-800 text-sm mt-0.5">
                    {account.accountType}
                  </div>
                  <div className="mt-1 flex items-center gap-1.5 text-emerald-700 font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{account.accountStatus}</span>
                  </div>
                </div>

                <div>
                  <span className="text-slate-500 font-semibold uppercase text-[10px] block">Senior Relationship Trustee</span>
                  <div className="font-medium text-slate-800 text-sm mt-0.5">
                    {account.relationshipManager}
                  </div>
                  <p className="text-slate-500 text-[11px] mt-1">SWIFT: {account.swiftBic}</p>
                </div>
              </div>

              {/* Active Bulletin Preview */}
              {account.announcements && (
                <div className="mt-5 p-3.5 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900">
                  <span className="font-bold block text-amber-950 mb-0.5">Current Dashboard Bulletin to Visitors:</span>
                  <p>{account.announcements}</p>
                </div>
              )}
            </div>

            {/* Recent Audit Trail Preview */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-serif-display font-bold text-lg text-[#0B2548]">
                  Recent Fiduciary Audit Events
                </h3>
                <button
                  onClick={() => setActiveTab('audit')}
                  className="text-xs text-[#0B2548] font-semibold hover:underline"
                >
                  Full Audit Log ({auditLogs.length}) →
                </button>
              </div>

              <div className="divide-y divide-slate-100">
                {auditLogs.slice(0, 5).map((log) => (
                  <div key={log.id} className="py-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs">
                    <div>
                      <span className="font-semibold text-slate-900">{log.action}</span>
                      <span className="text-slate-500 text-[11px] ml-2 font-mono">[{log.category}]</span>
                      <p className="text-slate-600 text-[11px] mt-0.5 italic">
                        "{log.justification}"
                      </p>
                    </div>
                    <div className="text-right sm:text-right text-slate-400 text-[11px] whitespace-nowrap">
                      <div>{new Date(log.timestamp).toLocaleDateString()} {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                      <span className="text-slate-500">{log.adminEmail}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* ================= TAB 2: ACCOUNT PROFILE MANAGEMENT ================= */}
        {activeTab === 'profile' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs">
            <div className="mb-6 pb-4 border-b border-slate-100">
              <h2 className="font-serif-display font-bold text-2xl text-[#0B2548]">
                Account Profile & Presentation Management
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Configure demonstration account presentation details. Changes persist directly to the database and are instantly rendered on the Visitor Dashboard.
              </p>
            </div>

            <form onSubmit={handleProfileSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                    Account Holder Display Name
                  </label>
                  <input
                    type="text"
                    required
                    value={profileForm.accountHolderName}
                    onChange={(e) => setProfileForm({ ...profileForm, accountHolderName: e.target.value })}
                    className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0B2548]"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    Primary entity displayed on client portal and demonstration statements.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                    Account Classification / Type
                  </label>
                  <input
                    type="text"
                    required
                    value={profileForm.accountType}
                    onChange={(e) => setProfileForm({ ...profileForm, accountType: e.target.value })}
                    className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0B2548]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                    Account Number
                  </label>
                  <input
                    type="text"
                    required
                    value={profileForm.accountNumber}
                    onChange={(e) => setProfileForm({ ...profileForm, accountNumber: e.target.value })}
                    className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl font-mono focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0B2548]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                    Account Status
                  </label>
                  <select
                    value={profileForm.accountStatus}
                    onChange={(e) => setProfileForm({ ...profileForm, accountStatus: e.target.value as any })}
                    className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0B2548]"
                  >
                    <option value="Active & Verified">Active & Verified</option>
                    <option value="Audited & In Good Standing">Audited & In Good Standing</option>
                    <option value="Under Periodic Review">Under Periodic Review</option>
                    <option value="Restricted">Restricted</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                    Account Currency
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      required
                      value={profileForm.currency}
                      onChange={(e) => setProfileForm({ ...profileForm, currency: e.target.value })}
                      placeholder="USD"
                      className="p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl font-mono"
                    />
                    <input
                      type="text"
                      required
                      value={profileForm.currencySymbol}
                      onChange={(e) => setProfileForm({ ...profileForm, currencySymbol: e.target.value })}
                      placeholder="$"
                      className="p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl font-mono text-center"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                    Senior Relationship Trustee
                  </label>
                  <input
                    type="text"
                    value={profileForm.relationshipManager}
                    onChange={(e) => setProfileForm({ ...profileForm, relationshipManager: e.target.value })}
                    className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                    Routing Number
                  </label>
                  <input
                    type="text"
                    value={profileForm.routingNumber}
                    onChange={(e) => setProfileForm({ ...profileForm, routingNumber: e.target.value })}
                    className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                    SWIFT / BIC Code
                  </label>
                  <input
                    type="text"
                    value={profileForm.swiftBic}
                    onChange={(e) => setProfileForm({ ...profileForm, swiftBic: e.target.value })}
                    className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                    Account Description & Stewardship Mandate
                  </label>
                  <textarea
                    rows={2}
                    value={profileForm.accountDescription}
                    onChange={(e) => setProfileForm({ ...profileForm, accountDescription: e.target.value })}
                    className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                    Dashboard Announcement / Fiduciary Bulletin
                  </label>
                  <textarea
                    rows={2}
                    value={profileForm.announcements}
                    onChange={(e) => setProfileForm({ ...profileForm, announcements: e.target.value })}
                    placeholder="Broadcast an official notice to visitor banking dashboard..."
                    className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>
              </div>

              {/* Mandatory Justification */}
              <div className="p-4 bg-amber-50/70 border border-[#C5921E]/40 rounded-xl space-y-2">
                <label className="block text-xs font-bold text-amber-950 uppercase tracking-wider">
                  Mandatory Audit Justification *
                </label>
                <textarea
                  required
                  rows={2}
                  value={profileForm.justification}
                  onChange={(e) => setProfileForm({ ...profileForm, justification: e.target.value })}
                  placeholder="State the regulatory or administrative reason for this configuration update (e.g. 'Fiduciary charter name alignment')..."
                  className="w-full p-3 text-sm bg-white border border-amber-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0B2548]"
                />
                <span className="text-[11px] text-amber-800 block">
                  Every change is permanently recorded in the administrative audit ledger with timestamp and administrator email.
                </span>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="py-3 px-6 rounded-xl text-white font-semibold text-sm bg-[#0B2548] hover:bg-[#071933] transition-all shadow-md shadow-[#0B2548]/20 disabled:opacity-50 cursor-pointer"
                >
                  {isSubmitting ? 'Saving to Database...' : 'Save Profile Changes'}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* ================= TAB 3: BALANCE MANAGEMENT ================= */}
        {activeTab === 'balance' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs max-w-3xl mx-auto">
            <div className="mb-6 pb-4 border-b border-slate-100">
              <h2 className="font-serif-display font-bold text-2xl text-[#0B2548]">
                Depository Balance Management
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Configure the displayed depository balances for this private banking account. Changes are reflected across all connected visitor sessions.
              </p>
            </div>

            {/* Current Values Display */}
            <div className="grid grid-cols-2 gap-4 p-5 bg-slate-50 rounded-2xl border border-slate-200 mb-6">
              <div>
                <span className="text-[11px] uppercase tracking-wider text-slate-500 font-semibold block">
                  Current Displayed Balance
                </span>
                <span className="font-serif-display text-2xl sm:text-3xl font-bold text-[#0B2548] tabular-nums">
                  {account.currencySymbol}{account.currentBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                </span>
              </div>

              <div>
                <span className="text-[11px] uppercase tracking-wider text-slate-500 font-semibold block">
                  Current Available Balance
                </span>
                <span className="font-serif-display text-2xl sm:text-3xl font-bold text-emerald-700 tabular-nums">
                  {account.currencySymbol}{account.availableBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                </span>
              </div>
            </div>

            {/* Balance Edit Form */}
            <form onSubmit={handleBalanceSubmit} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                    New Displayed Balance ({account.currency})
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={balanceForm.currentBalance}
                    onChange={(e) => setBalanceForm({ ...balanceForm, currentBalance: e.target.value })}
                    className="w-full p-3 text-base font-semibold bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0B2548] tabular-nums"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                    New Available Balance ({account.currency})
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={balanceForm.availableBalance}
                    onChange={(e) => setBalanceForm({ ...balanceForm, availableBalance: e.target.value })}
                    className="w-full p-3 text-base font-semibold bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0B2548] tabular-nums"
                  />
                </div>
              </div>

              {/* Mandatory Justification */}
              <div className="p-4 bg-amber-50/80 border border-[#C5921E]/40 rounded-xl space-y-2">
                <label className="block text-xs font-bold text-amber-950 uppercase tracking-wider">
                  Mandatory Audit Justification Field *
                </label>
                <textarea
                  required
                  rows={3}
                  value={balanceForm.justification}
                  onChange={(e) => setBalanceForm({ ...balanceForm, justification: e.target.value })}
                  placeholder="Provide an explanation for this balance adjustment (e.g. 'Calibration with Swiss private vault sweep and sovereign bond yield inflow')..."
                  className="w-full p-3 text-sm bg-white border border-amber-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0B2548]"
                />
                <p className="text-[11px] text-amber-900 leading-relaxed">
                  Notice: These adjustments only affect demonstration data and are not represented as actual financial ledger entries or customer deposits.
                </p>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="py-3 px-8 rounded-xl text-white font-semibold text-sm bg-[#0B2548] hover:bg-[#071933] transition-all shadow-md shadow-[#0B2548]/20 disabled:opacity-50 cursor-pointer"
                >
                  {isSubmitting ? 'Recording Adjustment...' : 'Save Balance Changes'}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* ================= TAB 4: TRANSACTION MANAGER ================= */}
        {activeTab === 'transactions' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <h2 className="font-serif-display font-bold text-2xl text-[#0B2548]">
                  Depository Transaction Manager
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  Manage depository ledger activity covering January 2020 through November 2026.
                </p>
              </div>

              <button
                onClick={() => setShowAddTxModal(true)}
                className="inline-flex items-center gap-1.5 py-2.5 px-4 rounded-xl text-xs font-semibold bg-[#0B2548] text-white hover:bg-[#071933] transition-colors shadow-xs"
              >
                <PlusCircle className="w-4 h-4 text-[#C5921E]" />
                <span>Record Depository Transaction</span>
              </button>
            </div>

            {/* Filter and Search Bar */}
            <div className="flex flex-col sm:flex-row items-center gap-3">
              <div className="relative flex-1 w-full">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={txSearch}
                  onChange={(e) => setTxSearch(e.target.value)}
                  placeholder="Search by description, reference, counterparty..."
                  className="w-full pl-9 pr-4 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#0B2548]"
                />
              </div>

              <select
                value={txTypeFilter}
                onChange={(e) => setTxTypeFilter(e.target.value)}
                className="py-2.5 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none"
              >
                <option value="all">All Transaction Types</option>
                <option value="deposit">Deposits</option>
                <option value="withdrawal">Withdrawals</option>
                <option value="internal transfer">Internal Transfers</option>
                <option value="external transfer">External Transfers</option>
                <option value="adjustment">Adjustments</option>
                <option value="payment">Payments</option>
              </select>

              <div className="text-xs text-slate-500 whitespace-nowrap">
                Showing <strong>{filteredTx.length}</strong> of {transactions.length}
              </div>
            </div>

            {/* Transactions Table */}
            <div className="overflow-x-auto border border-slate-200 rounded-xl">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-3.5">Date</th>
                    <th className="py-3 px-3.5">Reference</th>
                    <th className="py-3 px-3.5">Description</th>
                    <th className="py-3 px-3.5">Type</th>
                    <th className="py-3 px-3.5 text-right">Amount</th>
                    <th className="py-3 px-3.5 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredTx.slice(0, 30).map((tx) => (
                    <tr key={tx.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-2.5 px-3.5 font-mono text-slate-600 whitespace-nowrap">{tx.date}</td>
                      <td className="py-2.5 px-3.5 font-mono text-[#0B2548] font-semibold whitespace-nowrap">{tx.reference}</td>
                      <td className="py-2.5 px-3.5 text-slate-900 font-medium">
                        {tx.description}
                        <span className="block text-[11px] text-slate-500">{tx.counterparty}</span>
                      </td>
                      <td className="py-2.5 px-3.5 whitespace-nowrap text-slate-700">{tx.type}</td>
                      <td className={`py-2.5 px-3.5 text-right font-semibold tabular-nums whitespace-nowrap ${
                        tx.type === 'Deposit' ? 'text-emerald-700' : 'text-slate-900'
                      }`}>
                        {tx.type === 'Deposit' ? '+' : '-'}{account.currencySymbol}{tx.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-2.5 px-3.5 text-right whitespace-nowrap">
                        <span className="text-[11px] text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                          {tx.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {filteredTx.length > 30 && (
              <p className="text-xs text-center text-slate-500 italic pt-2">
                Showing top 30 filtered records of {filteredTx.length} total ledger records.
              </p>
            )}
          </div>
        )}

        {/* ================= TAB 5: AUDIT LOG ================= */}
        {activeTab === 'audit' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
            <div className="pb-4 border-b border-slate-100">
              <h2 className="font-serif-display font-bold text-2xl text-[#0B2548]">
                Administrative Fiduciary Audit Log
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Tamper-evident record of all administrative logins, balance adjustments, profile modifications, and settings events.
              </p>
            </div>

            <div className="overflow-x-auto border border-slate-200 rounded-xl">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#0B2548] text-white">
                  <tr>
                    <th className="py-3 px-3.5 font-semibold">Timestamp</th>
                    <th className="py-3 px-3.5 font-semibold">Administrator</th>
                    <th className="py-3 px-3.5 font-semibold">Action Performed</th>
                    <th className="py-3 px-3.5 font-semibold">Category</th>
                    <th className="py-3 px-3.5 font-semibold">Previous Value</th>
                    <th className="py-3 px-3.5 font-semibold">New Value</th>
                    <th className="py-3 px-3.5 font-semibold">Justification / Reason</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {auditLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3.5 font-mono text-slate-600 whitespace-nowrap">
                        {new Date(log.timestamp).toLocaleString('en-US', { dateStyle: 'short', timeStyle: 'medium' })}
                      </td>
                      <td className="py-2.5 px-3.5 font-medium text-slate-900 whitespace-nowrap">{log.adminEmail}</td>
                      <td className="py-2.5 px-3.5 font-semibold text-[#0B2548] whitespace-nowrap">{log.action}</td>
                      <td className="py-2.5 px-3.5 whitespace-nowrap">
                        <span className="text-[10px] font-mono uppercase bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded">
                          {log.category}
                        </span>
                      </td>
                      <td className="py-2.5 px-3.5 text-slate-600 text-[11px] max-w-[150px] truncate">{log.previousValue || '—'}</td>
                      <td className="py-2.5 px-3.5 text-slate-900 font-medium text-[11px] max-w-[150px] truncate">{log.newValue || '—'}</td>
                      <td className="py-2.5 px-3.5 text-slate-700 text-[11px] max-w-[220px]">{log.justification}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ================= TAB 6: NOTIFICATIONS / ANNOUNCEMENTS ================= */}
        {activeTab === 'notifications' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
            <div className="pb-4 border-b border-slate-100">
              <h2 className="font-serif-display font-bold text-2xl text-[#0B2548]">
                Broadcast Announcements & Bulletins
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Post official fiduciary advisories and notifications that appear in the Visitor Banking Portal.
              </p>
            </div>

            {/* Broadcast Form */}
            <form onSubmit={handleNotifSubmit} className="p-5 bg-slate-50 rounded-xl border border-slate-200 space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                New Fiduciary Announcement
              </h3>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Title</label>
                <input
                  type="text"
                  required
                  value={notifForm.title}
                  onChange={(e) => setNotifForm({ ...notifForm, title: e.target.value })}
                  placeholder="e.g. Q4 Sovereign Reserve Liquidity Notice"
                  className="w-full p-2.5 text-xs bg-white border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Message Body</label>
                <textarea
                  required
                  rows={3}
                  value={notifForm.message}
                  onChange={(e) => setNotifForm({ ...notifForm, message: e.target.value })}
                  placeholder="Detailed explanation or instruction..."
                  className="w-full p-2.5 text-xs bg-white border border-slate-300 rounded-lg"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Priority</label>
                  <select
                    value={notifForm.priority}
                    onChange={(e) => setNotifForm({ ...notifForm, priority: e.target.value as any })}
                    className="p-2 text-xs bg-white border border-slate-300 rounded-lg"
                  >
                    <option value="routine">Routine</option>
                    <option value="advisory">Advisory</option>
                    <option value="regulatory">Regulatory</option>
                  </select>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="py-2.5 px-5 rounded-lg text-white font-semibold text-xs bg-[#0B2548] hover:bg-[#071933] transition-colors"
                >
                  Broadcast Bulletin
                </button>
              </div>
            </form>

            {/* Active Bulletins List */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Existing Published Bulletins ({notifications.length})
              </h3>
              <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
                {notifications.map((notif) => (
                  <div key={notif.id} className="p-4 bg-white hover:bg-slate-50 transition-colors text-xs">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="font-semibold text-slate-900 text-sm">{notif.title}</span>
                      <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-600">
                        {notif.priority}
                      </span>
                    </div>
                    <p className="text-slate-600 leading-relaxed">{notif.message}</p>
                    <span className="text-[10px] text-slate-400 mt-2 block">Published: {notif.date}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 7: SETTINGS ================= */}
        {activeTab === 'settings' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs max-w-2xl mx-auto space-y-6">
            <div className="pb-4 border-b border-slate-100">
              <h2 className="font-serif-display font-bold text-2xl text-[#0B2548]">
                Administrative Settings & Database Control
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Persistent system parameters, credentials architecture, and demonstration database maintenance.
              </p>
            </div>

            {/* Security Architecture Details */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs text-slate-700">
              <div className="font-bold text-slate-900 flex items-center gap-1.5">
                <Lock className="w-4 h-4 text-[#C5921E]" />
                <span>Authentication & Access Credentials Architecture</span>
              </div>
              <p>
                • Primary Authorized Email: <code className="font-bold">aurelianhouse777@gmail.com</code>
              </p>
              <p>
                • Administrator Mode Access Code: <code className="font-bold">777000</code>
              </p>
              <p>
                • Visitor Mode Access Code: <code className="font-bold">EBSN98765</code>
              </p>
              <p className="text-slate-500 text-[11px] pt-1 border-t border-slate-200">
                All passcodes and role verifications are managed on the server. No credentials or secret keys are exposed in the client bundles or browser storage.
              </p>
            </div>

            {/* Factory Reset Tool */}
            <div className="p-4 bg-rose-50 rounded-xl border border-rose-200 space-y-3 text-xs text-rose-900">
              <div className="font-bold flex items-center gap-1.5 text-rose-950">
                <AlertCircle className="w-4 h-4 text-rose-600" />
                <span>System Demonstration Reset</span>
              </div>
              <p>
                Reset the persistent file database to initial factory seed data (restoring original $148,250,420.50 balance and default transactions).
              </p>
              <button
                onClick={handleResetSystem}
                disabled={isSubmitting}
                className="py-2 px-4 rounded-lg bg-rose-700 hover:bg-rose-800 text-white font-semibold text-xs transition-colors"
              >
                Reset System to Initial Demonstration Seed
              </button>
            </div>
          </div>
        )}

      </main>

      {/* Add Transaction Modal */}
      {showAddTxModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <h3 className="font-serif-display font-bold text-xl text-[#0B2548]">
              Record Depository Transaction
            </h3>
            <form onSubmit={handleAddTxSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Description</label>
                <input
                  type="text"
                  required
                  value={newTxForm.description}
                  onChange={(e) => setNewTxForm({ ...newTxForm, description: e.target.value })}
                  placeholder="e.g. Sovereign Bond Coupon Allocation"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Transaction Type</label>
                  <select
                    value={newTxForm.type}
                    onChange={(e) => setNewTxForm({ ...newTxForm, type: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                  >
                    <option value="Deposit">Deposit</option>
                    <option value="Withdrawal">Withdrawal</option>
                    <option value="Internal Transfer">Internal Transfer</option>
                    <option value="External Transfer">External Transfer</option>
                    <option value="Adjustment">Adjustment</option>
                    <option value="Payment">Payment</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Amount ({account.currency})</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={newTxForm.amount}
                    onChange={(e) => setNewTxForm({ ...newTxForm, amount: e.target.value })}
                    placeholder="1500000"
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg tabular-nums"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Counterparty Entity</label>
                <input
                  type="text"
                  value={newTxForm.counterparty}
                  onChange={(e) => setNewTxForm({ ...newTxForm, counterparty: e.target.value })}
                  placeholder="e.g. Rothschild & Co Fiduciary Escrow"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Notes</label>
                <input
                  type="text"
                  value={newTxForm.notes}
                  onChange={(e) => setNewTxForm({ ...newTxForm, notes: e.target.value })}
                  placeholder="Demonstration notes..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddTxModal(false)}
                  className="py-2 px-4 rounded-lg text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="py-2 px-5 rounded-lg bg-[#0B2548] text-white font-semibold"
                >
                  Add Transaction
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
