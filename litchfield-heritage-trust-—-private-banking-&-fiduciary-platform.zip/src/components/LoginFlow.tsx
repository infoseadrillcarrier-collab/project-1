import React, { useState } from 'react';
import { BrandLogo } from './BrandLogo';
import { api } from '../api';
import { UserRole } from '../types';
import { ArrowLeft, ArrowRight, ShieldCheck, Mail, Lock, HelpCircle, AlertCircle, Info } from 'lucide-react';

interface LoginFlowProps {
  onAuthSuccess: (role: UserRole) => void;
  onViewWebsite?: () => void;
}

type Stage = 'EMAIL_ENTRY' | 'EMAIL_CONFIRMATION' | 'CODE_ENTRY';

export const LoginFlow: React.FC<LoginFlowProps> = ({ onAuthSuccess, onViewWebsite }) => {
  const [stage, setStage] = useState<Stage>('EMAIL_ENTRY');
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [showForgotModal, setShowForgotModal] = useState(false);

  // Stage 1: Validate Email
  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (!email.trim()) {
      setErrorMessage('Please enter your registered business email address.');
      return;
    }

    setIsLoading(true);
    try {
      await api.validateEmail(email.trim());
      setStage('EMAIL_CONFIRMATION');
    } catch (err: any) {
      setErrorMessage(err.message || 'The email address is not recognized by Litchfield Heritage Trust.');
    } finally {
      setIsLoading(false);
    }
  };

  // Stage 3: Submit Access Code
  const handleCodeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (!code.trim()) {
      setErrorMessage('Please enter your access code.');
      return;
    }

    setIsLoading(true);
    try {
      const res = await api.verifyCode(email.trim(), code.trim());
      if (res.success && res.role) {
        onAuthSuccess(res.role);
      } else {
        setErrorMessage('Invalid access code. Please verify your access credentials and try again.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Invalid access code. Please verify your access credentials and try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#071933] flex flex-col justify-between py-8 px-4 sm:px-6 lg:px-8 relative selection:bg-[#C5921E]/30 selection:text-white">
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-[#0B2548] via-[#071933] to-[#040e1d] -z-10" />
      <div 
        className="absolute inset-0 opacity-[0.025] -z-10 pointer-events-none"
        style={{
          backgroundImage: 'linear-gradient(#C5921E 1px, transparent 1px), linear-gradient(to right, #C5921E 1px, transparent 1px)',
          backgroundSize: '48px 48px'
        }}
      />

      {/* Top Header */}
      <div className="w-full max-w-md mx-auto flex items-center justify-between">
        {onViewWebsite ? (
          <button
            onClick={onViewWebsite}
            className="text-[11px] font-sans-body uppercase tracking-[0.15em] text-[#C5921E] hover:text-[#F4E8CE] font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Institutional Website</span>
          </button>
        ) : (
          <div className="text-[11px] font-sans-body uppercase tracking-[0.2em] text-[#C5921E] font-medium">
            Private Banking & Trust Portal
          </div>
        )}
        <div className="flex items-center gap-1.5 text-xs text-slate-400">
          <ShieldCheck className="w-3.5 h-3.5 text-[#C5921E]" />
          <span>Fiduciary Tier-1 Encrypted</span>
        </div>
      </div>

      {/* Main Login Card */}
      <div className="w-full max-w-md mx-auto my-auto">
        <div className="bg-white rounded-2xl p-7 sm:p-9 shadow-2xl shadow-black/50 border border-[#C5921E]/25 transition-all">
          
          {/* Logo Section */}
          <div className="flex justify-center mb-6">
            <BrandLogo size="lg" />
          </div>

          <div className="h-px w-full bg-gradient-to-r from-transparent via-slate-200 to-transparent mb-6" />

          {/* Error Banner */}
          {errorMessage && (
            <div className="mb-5 p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-3 text-rose-800 text-xs sm:text-sm animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="leading-relaxed font-sans-body">{errorMessage}</div>
            </div>
          )}

          {/* ================= STAGE 1: BUSINESS EMAIL ENTRY ================= */}
          {stage === 'EMAIL_ENTRY' && (
            <form onSubmit={handleEmailSubmit} className="space-y-5">
              <div className="text-center space-y-1 mb-6">
                <h1 className="font-serif-display text-2xl font-bold text-[#0B2548] tracking-tight">
                  Welcome to Litchfield Heritage Trust
                </h1>
                <p className="font-sans-body text-xs sm:text-sm text-slate-500">
                  Please enter your authorized institutional business email to access your accounts.
                </p>
              </div>

              <div>
                <label htmlFor="business-email" className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5 font-sans-body">
                  Business Email Address
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    id="business-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@institution.com"
                    className="block w-full pl-10 pr-3.5 py-3 text-sm text-slate-900 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0B2548] focus:border-transparent transition-all font-sans-body"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-2 py-3.5 px-4 rounded-xl text-white font-medium text-sm bg-[#0B2548] hover:bg-[#071933] active:scale-[0.99] transition-all shadow-md shadow-[#0B2548]/20 disabled:opacity-60 cursor-pointer font-sans-body"
              >
                {isLoading ? (
                  <span>Verifying Authorized Account...</span>
                ) : (
                  <>
                    <span>Continue</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              <div className="pt-2 text-center">
                <button
                  type="button"
                  onClick={() => setShowForgotModal(true)}
                  className="text-xs text-[#0B2548] hover:text-[#C5921E] font-medium transition-colors inline-flex items-center gap-1.5 font-sans-body"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>Forgot business email or need assistance?</span>
                </button>
              </div>
            </form>
          )}

          {/* ================= STAGE 2: EMAIL CONFIRMATION MESSAGE ================= */}
          {stage === 'EMAIL_CONFIRMATION' && (
            <div className="space-y-6 text-center animate-in fade-in">
              <div className="w-12 h-12 rounded-full bg-[#C5921E]/15 text-[#C5921E] flex items-center justify-center mx-auto border border-[#C5921E]/30">
                <Mail className="w-6 h-6 text-[#A67610]" />
              </div>

              <div className="space-y-2">
                <h2 className="font-serif-display text-2xl font-bold text-[#0B2548]">
                  Check your email for the access code.
                </h2>
                <p className="font-sans-body text-xs sm:text-sm text-slate-600 leading-relaxed px-2">
                  We have sent an access verification message to your registered business email address (<span className="font-semibold text-slate-800">{email}</span>). Please check your inbox and proceed to enter your access code.
                </p>
              </div>

              <div className="space-y-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setErrorMessage('');
                    setStage('CODE_ENTRY');
                  }}
                  className="w-full flex items-center justify-center gap-2 py-3.5 px-4 rounded-xl text-white font-medium text-sm bg-[#0B2548] hover:bg-[#071933] active:scale-[0.99] transition-all shadow-md shadow-[#0B2548]/20 cursor-pointer font-sans-body"
                >
                  <span>Continue</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setErrorMessage('');
                    setStage('EMAIL_ENTRY');
                  }}
                  className="w-full py-2.5 px-4 rounded-xl text-slate-600 hover:text-slate-900 text-xs font-medium transition-colors font-sans-body"
                >
                  Back to email entry
                </button>
              </div>
            </div>
          )}

          {/* ================= STAGE 3: ACCESS CODE ENTRY ================= */}
          {stage === 'CODE_ENTRY' && (
            <form onSubmit={handleCodeSubmit} className="space-y-5 animate-in fade-in">
              <div className="text-center space-y-1 mb-5">
                <h2 className="font-serif-display text-2xl font-bold text-[#0B2548]">
                  Verify Your Access
                </h2>
                <p className="font-sans-body text-xs sm:text-sm text-slate-500">
                  Please enter your access code to continue.
                </p>
              </div>

              <div>
                <label htmlFor="access-code" className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5 font-sans-body">
                  Access Code
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    id="access-code"
                    type="password"
                    autoFocus
                    required
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="Enter access code"
                    className="block w-full pl-10 pr-3.5 py-3 text-sm text-slate-900 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0B2548] focus:border-transparent transition-all font-mono tracking-widest"
                  />
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2 font-sans-body">
                  <span>Authorized verification channel</span>
                  <span className="text-slate-400">Case-sensitive</span>
                </div>
              </div>

              <div className="space-y-2.5 pt-2">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-2 py-3.5 px-4 rounded-xl text-white font-medium text-sm bg-[#0B2548] hover:bg-[#071933] active:scale-[0.99] transition-all shadow-md shadow-[#0B2548]/20 disabled:opacity-60 cursor-pointer font-sans-body"
                >
                  {isLoading ? (
                    <span>Authenticating Credentials...</span>
                  ) : (
                    <>
                      <span>Continue</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setErrorMessage('');
                    setStage('EMAIL_CONFIRMATION');
                  }}
                  className="w-full flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-xl text-slate-600 hover:text-slate-900 text-xs font-medium transition-colors font-sans-body"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>

      {/* Footer Legal & Disclaimers */}
      <div className="w-full max-w-2xl mx-auto text-center space-y-1.5 text-[11px] text-slate-400 font-sans-body">
        <p className="tracking-wide">
          © {new Date().getFullYear()} Litchfield Heritage Trust. All rights reserved. Registered Private Banking & Sovereign Fiduciary Services.
        </p>
        <p className="text-[10px] text-slate-400/90">
          Authorized Institutional Depository. All customer accounts and fiduciary allocations are ring-fenced under institutional governance.
        </p>
      </div>

      {/* Forgot Email Help Modal */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-[#0B2548]/10 text-[#0B2548] flex items-center justify-center">
                <HelpCircle className="w-5 h-5 text-[#0B2548]" />
              </div>
              <div>
                <h3 className="font-serif-display font-bold text-lg text-[#0B2548]">Institutional Access Assistance</h3>
                <p className="text-xs text-slate-500">Litchfield Heritage Trust Fiduciary Support</p>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-600 leading-relaxed font-sans-body">
              <p>
                Access to Litchfield Heritage Trust private accounts is restricted strictly to accredited institutions, designated trustees, and authorized delegates.
              </p>
              <p>
                Please verify that you are entering the designated corporate business email registered with your depository charter.
              </p>
              <p>
                If you require credential re-issuance or fiduciary identity re-certification, please contact your Senior Managing Trustee or Relationship Manager directly through your official institutional channel.
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 flex justify-end">
              <button
                type="button"
                onClick={() => setShowForgotModal(false)}
                className="py-2 px-4 rounded-xl text-xs font-semibold bg-[#0B2548] text-white hover:bg-[#071933] transition-colors cursor-pointer"
              >
                Close Assistance
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
