import React from 'react';

interface EightDotSpinnerProps {
  percentage?: number;
  timeLabel?: string;
  size?: number; // default 140px
  className?: string;
  variant?: 'dark' | 'light';
}

export const EightDotSpinner: React.FC<EightDotSpinnerProps> = ({
  percentage,
  timeLabel,
  size = 140,
  className = '',
  variant = 'dark',
}) => {
  // 8 dots arranged in a circle
  const radius = 50;
  const center = 64;
  const dotRadius = 4.5;
  const period = 1.2; // 1.2s for one full revolution

  const dots = Array.from({ length: 8 }).map((_, i) => {
    const angle = (i * 45 - 90) * (Math.PI / 180);
    const cx = center + radius * Math.cos(angle);
    const cy = center + radius * Math.sin(angle);
    const delay = ((i * period) / 8).toFixed(3);

    return { cx, cy, delay };
  });

  const isLight = variant === 'light';

  return (
    <div
      className={`relative flex items-center justify-center select-none ${className}`}
      style={{ width: size, height: size }}
    >
      <style>{`
        @keyframes eightDotPulseDark {
          0% {
            opacity: 1;
            transform: scale(1.25);
            fill: #F4E8CE;
          }
          50% {
            opacity: 0.2;
            transform: scale(0.8);
            fill: #C5921E;
          }
          100% {
            opacity: 0.2;
            transform: scale(0.8);
            fill: #C5921E;
          }
        }
        @keyframes eightDotPulseLight {
          0% {
            opacity: 1;
            transform: scale(1.25);
            fill: #0B2548;
          }
          50% {
            opacity: 0.25;
            transform: scale(0.8);
            fill: #C5921E;
          }
          100% {
            opacity: 0.25;
            transform: scale(0.8);
            fill: #C5921E;
          }
        }
      `}</style>

      <svg
        className="w-full h-full"
        viewBox="0 0 128 128"
        aria-hidden="true"
      >
        {dots.map((dot, index) => (
          <circle
            key={index}
            cx={dot.cx}
            cy={dot.cy}
            r={dotRadius}
            fill={isLight ? '#0B2548' : '#C5921E'}
            style={{
              animation: `${isLight ? 'eightDotPulseLight' : 'eightDotPulseDark'} ${period}s infinite ease-in-out`,
              animationDelay: `${dot.delay}s`,
              transformOrigin: `${dot.cx}px ${dot.cy}px`,
            }}
          />
        ))}
      </svg>

      {/* Centered Numerical Indicators */}
      {(percentage !== undefined || timeLabel) && (
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          {percentage !== undefined && (
            <span className={`font-serif-display text-2xl font-bold tracking-tight tabular-nums leading-none ${
              isLight ? 'text-[#0B2548]' : 'text-white'
            }`}>
              {percentage}%
            </span>
          )}
          {timeLabel && (
            <span className={`text-[11px] font-sans-body uppercase tracking-wider font-semibold mt-1 ${
              isLight ? 'text-[#C5921E]' : 'text-[#C5921E]'
            }`}>
              {timeLabel}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
