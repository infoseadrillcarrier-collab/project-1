import React, { useState } from 'react';
import { AccountData, Transaction } from '../types';
import { BrandLogo } from './BrandLogo';
import { X, Printer, Download, AlertTriangle, Calendar, FileText, CheckCircle2 } from 'lucide-react';

interface DemonstrationStatementModalProps {
  account: AccountData;
  transactions: Transaction[];
  onClose: () => void;
}

export const DemonstrationStatementModal: React.FC<DemonstrationStatementModalProps> = ({
  account,
  transactions,
  onClose,
}) => {
  const [selectedRange, setSelectedRange] = useState<'all' | '2026' | '2025' | 'custom'>('2026');
  const [startDate, setStartDate] = useState('2026-01-01');
  const [endDate, setEndDate] = useState('2026-11-02');

  const filteredTx = transactions.filter((t) => {
    if (selectedRange === 'all') return true;
    if (selectedRange === '2026') return t.date >= '2026-01-01' && t.date <= '2026-12-31';
    if (selectedRange === '2025') return t.date >= '2025-01-01' && t.date <= '2025-12-31';
    if (selectedRange === 'custom') {
      return (!startDate || t.date >= startDate) && (!endDate || t.date <= endDate);
    }
    return true;
  });

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto">
      <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden my-auto animate-in fade-in zoom-in-95">
        
        {/* Modal Controls Header (Hidden in Print) */}
        <div className="p-4 sm:p-5 bg-slate-900 text-white flex items-center justify-between no-print border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#C5921E]/20 text-[#C5921E] flex items-center justify-center border border-[#C5921E]/30">
              <FileText className="w-5 h-5 text-[#C5921E]" />
            </div>
            <div>
              <h2 className="font-serif-display font-semibold text-base sm:text-lg">
                Official Fiduciary Statement
              </h2>
              <p className="text-xs text-slate-400 font-sans-body">
                Official institutional format generated directly from the depository register
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 py-2 px-3 sm:px-4 rounded-xl text-xs font-semibold bg-[#C5921E] hover:bg-[#A67610] text-[#071933] transition-colors shadow-sm"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Save PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Date Filter Bar (Hidden in Print) */}
        <div className="p-3 sm:p-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs no-print shrink-0 font-sans-body">
          <div className="flex items-center gap-1.5">
            <Calendar className="w-4 h-4 text-slate-500" />
            <span className="font-semibold text-slate-700">Statement Period:</span>
            <div className="flex items-center gap-1 ml-2">
              <button
                onClick={() => setSelectedRange('2026')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  selectedRange === '2026' ? 'bg-[#0B2548] text-white shadow-xs' : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                Year 2026
              </button>
              <button
                onClick={() => setSelectedRange('2025')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  selectedRange === '2025' ? 'bg-[#0B2548] text-white shadow-xs' : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                Year 2025
              </button>
              <button
                onClick={() => setSelectedRange('all')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  selectedRange === 'all' ? 'bg-[#0B2548] text-white shadow-xs' : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                Complete History (2020–2026)
              </button>
            </div>
          </div>

          <div className="text-slate-500 text-xs">
            Showing <strong className="text-slate-800">{filteredTx.length}</strong> authenticated ledger records
          </div>
        </div>

        {/* ================= Printable Formal Document Content ================= */}
        <div className="p-6 sm:p-10 overflow-y-auto flex-1 font-sans-body relative bg-white" id="printable-statement">
          
          {/* Fiduciary Watermark across statement */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none z-0 opacity-[0.035] rotate-[-26deg]">
            <span className="font-serif-display font-extrabold text-4xl sm:text-6xl text-[#0B2548] text-center leading-tight tracking-wider">
              LITCHFIELD HERITAGE TRUST<br />OFFICIAL FIDUCIARY RECORD
            </span>
          </div>

          {/* Statement Header */}
          <div className="relative z-10">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b-2 border-[#0B2548]">
              <BrandLogo size="lg" />
              <div className="text-right text-xs text-slate-600 space-y-0.5">
                <div className="font-serif-display font-bold text-base text-[#0B2548]">
                  Litchfield Heritage Trust Fiduciary Depository
                </div>
                <div>Global Wealth & Discretionary Trust Services</div>
                <div>Fiduciary District, 45 Rockefeller Plaza, New York, NY</div>
                <div className="text-[11px] text-slate-400">SWIFT: {account.swiftBic} · IBAN: {account.iban}</div>
              </div>
            </div>

            {/* Official Record Notice Strip */}
            <div className="my-5 p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center gap-3 text-slate-800 text-xs">
              <CheckCircle2 className="w-5 h-5 text-[#C5921E] shrink-0" />
              <div>
                <strong className="text-[#0B2548]">Official Fiduciary Records:</strong> All account statements generated through this portal are official accounting records produced directly from the depository register.
                <span className="font-normal block text-[11px] text-slate-500 mt-0.5">
                  For certified copies with wet ink seal or international apostille certification, please contact your relationship manager.
                </span>
              </div>
            </div>

            {/* Account Information Strip */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4 bg-slate-50 rounded-xl p-5 border border-slate-200 text-xs mb-6">
              <div className="space-y-2">
                <div>
                  <span className="text-slate-500 uppercase tracking-wider text-[10px] block">Account Holder</span>
                  <span className="font-serif-display font-bold text-sm text-[#0B2548]">{account.accountHolderName}</span>
                </div>
                <div>
                  <span className="text-slate-500 uppercase tracking-wider text-[10px] block">Account Number</span>
                  <span className="font-mono font-semibold text-slate-900">{account.accountNumber}</span>
                </div>
                <div>
                  <span className="text-slate-500 uppercase tracking-wider text-[10px] block">Account Classification</span>
                  <span className="font-medium text-slate-800">{account.accountType}</span>
                </div>
              </div>

              <div className="space-y-2">
                <div>
                  <span className="text-slate-500 uppercase tracking-wider text-[10px] block">Statement Period</span>
                  <span className="font-semibold text-slate-800">
                    {selectedRange === 'all' ? 'January 2020 – November 2026' : selectedRange === '2026' ? '01 Jan 2026 – 31 Dec 2026' : '01 Jan 2025 – 31 Dec 2025'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 uppercase tracking-wider text-[10px] block">Current Displayed Balance</span>
                  <span className="font-serif-display font-bold text-base text-[#0B2548] tabular-nums">
                    {account.currencySymbol}{account.currentBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {account.currency}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 uppercase tracking-wider text-[10px] block">Relationship Manager</span>
                  <span className="font-medium text-slate-800">{account.relationshipManager}</span>
                </div>
              </div>
            </div>

            {/* Transactions Ledger Table */}
            <div className="mb-8">
              <h3 className="font-serif-display font-bold text-sm text-[#0B2548] uppercase tracking-wider mb-3">
                Ledger Activity Details ({filteredTx.length} Entries)
              </h3>
              <div className="overflow-x-auto border border-slate-200 rounded-lg">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#0B2548] text-white">
                    <tr>
                      <th className="py-2.5 px-3 font-semibold">Date</th>
                      <th className="py-2.5 px-3 font-semibold">Reference</th>
                      <th className="py-2.5 px-3 font-semibold">Description</th>
                      <th className="py-2.5 px-3 font-semibold">Type</th>
                      <th className="py-2.5 px-3 font-semibold text-right">Amount ({account.currency})</th>
                      <th className="py-2.5 px-3 font-semibold text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {filteredTx.slice(0, 45).map((tx) => (
                      <tr key={tx.id} className="hover:bg-slate-50">
                        <td className="py-2 px-3 font-mono text-slate-700 whitespace-nowrap">{tx.date}</td>
                        <td className="py-2 px-3 font-mono text-slate-600 whitespace-nowrap">{tx.reference}</td>
                        <td className="py-2 px-3 font-medium text-slate-900">
                          {tx.description}
                          <span className="block text-[10px] text-slate-500">{tx.counterparty}</span>
                        </td>
                        <td className="py-2 px-3 text-slate-700 whitespace-nowrap">{tx.type}</td>
                        <td className={`py-2 px-3 text-right font-semibold tabular-nums whitespace-nowrap ${
                          tx.type === 'Deposit' ? 'text-emerald-700' : 'text-slate-900'
                        }`}>
                          {tx.type === 'Deposit' ? '+' : '-'}{account.currencySymbol}{tx.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="py-2 px-3 text-right text-slate-600 whitespace-nowrap text-[11px]">
                          {tx.status}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {filteredTx.length > 45 && (
                <p className="text-[11px] text-slate-500 mt-2 text-center italic">
                  Showing first 45 records of {filteredTx.length}. Complete ledger archived in institutional depository repository.
                </p>
              )}
            </div>

            {/* Document Verification Footer */}
            <div className="pt-6 border-t border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-slate-500">
              <div className="space-y-1">
                <div className="font-semibold text-slate-800 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-[#C5921E]" />
                  <span>Certified Fiduciary Depository Record</span>
                </div>
                <div>Generated on: {new Date().toLocaleString('en-US', { dateStyle: 'full', timeStyle: 'short' })}</div>
                <div>Hash Verification: SHA256:{Math.random().toString(36).substring(2, 15).toUpperCase()}</div>
              </div>

              <div className="text-right border-t sm:border-t-0 pt-2 sm:pt-0">
                <div className="font-serif-display font-bold text-slate-900 text-sm">Lord Alistair Sterling</div>
                <div className="text-[11px] text-slate-600">Senior Managing Trustee & Executive Signatory</div>
                <div className="text-[10px] text-slate-400">Litchfield Heritage Trust</div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
