import React, { useState } from 'react';
import { AccountData, Transaction, BankNotification, Beneficiary } from '../types';
import { BrandLogo } from './BrandLogo';
import { brandImages } from '../assets/images';
import { api } from '../api';
import { DemonstrationStatementModal } from './DemonstrationStatementModal';
import { TransactionDetailModal } from './TransactionDetailModal';
import { EightDotSpinner } from './EightDotSpinner';
import {
  LayoutDashboard,
  Wallet,
  History,
  Send,
  Globe,
  Users,
  FileText,
  CreditCard,
  Bell,
  Settings,
  LogOut,
  Eye,
  EyeOff,
  ArrowDownLeft,
  ArrowUpRight,
  TrendingUp,
  ShieldCheck,
  Building2,
  Calendar,
  AlertTriangle,
  Search,
  ChevronRight,
  Copy,
  Check,
  RefreshCw,
  Info,
  Clock,
  ArrowRight,
  ShieldAlert,
  HelpCircle,
  PhoneCall,
} from 'lucide-react';

interface VisitorDashboardProps {
  account: AccountData;
  transactions: Transaction[];
  notifications: BankNotification[];
  beneficiaries: Beneficiary[];
  onRefreshData: () => Promise<void>;
  onLogout: () => void;
}

type VisitorNav =
  | 'dashboard'
  | 'accounts'
  | 'transactions'
  | 'domestic'
  | 'wire'
  | 'beneficiaries'
  | 'statements'
  | 'details'
  | 'notifications'
  | 'settings';

export const VisitorDashboard: React.FC<VisitorDashboardProps> = ({
  account,
  transactions,
  notifications,
  beneficiaries,
  onRefreshData,
  onLogout,
}) => {
  const [activeNav, setActiveNav] = useState<VisitorNav>('dashboard');
  const [showBalance, setShowBalance] = useState(true);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // Selected Transaction for Detail Modal
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);

  // Statement Modal State
  const [showStatementModal, setShowStatementModal] = useState(false);

  // Transfer Processing Animation State
  const [transferProcessingStage, setTransferProcessingStage] = useState('');
  const [transferProgress, setTransferProgress] = useState(0);
  const [transferTimeRemaining, setTransferTimeRemaining] = useState('4s');

  // Domestic Transfer State
  const [domesticStep, setDomesticStep] = useState<'form' | 'review' | 'processing' | 'result'>('form');
  const [domesticForm, setDomesticForm] = useState({
    recipientName: '',
    recipientAccount: '',
    receivingInstitution: '',
    amount: '',
    currency: account.currency,
    description: '',
    reference: '',
  });
  const [domesticResult, setDomesticResult] = useState<any>(null);

  // Wire Transfer State
  const [wireStep, setWireStep] = useState<'form' | 'review' | 'processing' | 'result'>('form');
  const [wireForm, setWireForm] = useState({
    beneficiaryName: '',
    beneficiaryBank: '',
    bankAddress: '',
    accountOrIban: '',
    swiftBic: '',
    destinationCountry: 'Switzerland',
    transferCurrency: account.currency,
    transferAmount: '',
    paymentPurpose: '',
    remarks: '',
  });
  const [wireResult, setWireResult] = useState<any>(null);

  // Transaction History State
  const [txSearch, setTxSearch] = useState('');
  const [txTypeFilter, setTxTypeFilter] = useState('all');
  const [txStatusFilter, setTxStatusFilter] = useState('all');
  const [txStartDate, setTxStartDate] = useState('');
  const [txEndDate, setTxEndDate] = useState('');
  const [txSortOrder, setTxSortOrder] = useState<'desc' | 'asc'>('desc');
  const [txPage, setTxPage] = useState(1);
  const itemsPerPage = 15;

  const handleCopy = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  // Domestic Transfer Handlers
  const handleDomesticReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!domesticForm.recipientName || !domesticForm.recipientAccount || !domesticForm.amount) return;
    setDomesticStep('review');
  };

  const handleDomesticSubmit = async () => {
    setDomesticStep('processing');
    setTransferProgress(8);
    setTransferProcessingStage('Initializing transfer protocol & secure envelope...');
    setTransferTimeRemaining('4s');

    const totalDuration = 3800; // 3.8s realistic banking clearance simulation
    const startTime = Date.now();

    const apiPromise = api.submitDomesticTransfer({
      ...domesticForm,
      amount: parseFloat(domesticForm.amount),
    });

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min(99, Math.round((elapsed / totalDuration) * 100));
      setTransferProgress(pct);

      const remainingSec = Math.max(0, Math.ceil((totalDuration - elapsed) / 1000));
      setTransferTimeRemaining(`${remainingSec}s`);

      if (pct < 28) {
        setTransferProcessingStage('Initializing transfer protocol & secure envelope...');
      } else if (pct < 55) {
        setTransferProcessingStage('Verifying account authorization and balances...');
      } else if (pct < 82) {
        setTransferProcessingStage('Generating cryptographic transaction signature...');
      } else {
        setTransferProcessingStage('Transmitting through clearing gateway...');
      }

      if (elapsed >= totalDuration) {
        clearInterval(interval);
      }
    }, 100);

    try {
      const res = await apiPromise;
      const remainingWait = Math.max(0, totalDuration - (Date.now() - startTime));
      setTimeout(() => {
        clearInterval(interval);
        setTransferProgress(100);
        setDomesticResult(res);
        setDomesticStep('result');
      }, remainingWait);
    } catch (err: any) {
      clearInterval(interval);
      alert(err.message || 'Transfer failed');
      setDomesticStep('form');
    }
  };

  const resetDomesticTransfer = () => {
    setDomesticForm({
      recipientName: '',
      recipientAccount: '',
      receivingInstitution: '',
      amount: '',
      currency: account.currency,
      description: '',
      reference: '',
    });
    setDomesticResult(null);
    setDomesticStep('form');
  };

  // Wire Transfer Handlers
  const handleWireReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!wireForm.beneficiaryName || !wireForm.accountOrIban || !wireForm.transferAmount) return;
    setWireStep('review');
  };

  const handleWireSubmit = async () => {
    setWireStep('processing');
    setTransferProgress(8);
    setTransferProcessingStage('Initializing cross-border SWIFT/ISO-20022 wire protocol...');
    setTransferTimeRemaining('4s');

    const totalDuration = 3800;
    const startTime = Date.now();

    const apiPromise = api.submitWireTransfer({
      ...wireForm,
      transferAmount: parseFloat(wireForm.transferAmount),
    });

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min(99, Math.round((elapsed / totalDuration) * 100));
      setTransferProgress(pct);

      const remainingSec = Math.max(0, Math.ceil((totalDuration - elapsed) / 1000));
      setTransferTimeRemaining(`${remainingSec}s`);

      if (pct < 28) {
        setTransferProcessingStage('Initializing cross-border SWIFT wire protocol...');
      } else if (pct < 55) {
        setTransferProcessingStage('Verifying account authorization and liquidity vaults...');
      } else if (pct < 82) {
        setTransferProcessingStage('Generating cryptographic transaction signature...');
      } else {
        setTransferProcessingStage('Transmitting through international clearing gateway...');
      }

      if (elapsed >= totalDuration) {
        clearInterval(interval);
      }
    }, 100);

    try {
      const res = await apiPromise;
      const remainingWait = Math.max(0, totalDuration - (Date.now() - startTime));
      setTimeout(() => {
        clearInterval(interval);
        setTransferProgress(100);
        setWireResult(res);
        setWireStep('result');
      }, remainingWait);
    } catch (err: any) {
      clearInterval(interval);
      alert(err.message || 'Wire transfer failed');
      setWireStep('form');
    }
  };

  const resetWireTransfer = () => {
    setWireForm({
      beneficiaryName: '',
      beneficiaryBank: '',
      bankAddress: '',
      accountOrIban: '',
      swiftBic: '',
      destinationCountry: 'Switzerland',
      transferCurrency: account.currency,
      transferAmount: '',
      paymentPurpose: '',
      remarks: '',
    });
    setWireResult(null);
    setWireStep('form');
  };

  // Filtered Transactions
  const filteredTransactions = transactions.filter((t) => {
    const q = txSearch.toLowerCase();
    const matchesSearch =
      !q ||
      t.description.toLowerCase().includes(q) ||
      t.reference.toLowerCase().includes(q) ||
      t.counterparty.toLowerCase().includes(q) ||
      t.category.toLowerCase().includes(q);

    const matchesType = txTypeFilter === 'all' || t.type.toLowerCase() === txTypeFilter.toLowerCase();
    const matchesStatus = txStatusFilter === 'all' || t.status.toLowerCase() === txStatusFilter.toLowerCase();
    const matchesStart = !txStartDate || t.date >= txStartDate;
    const matchesEnd = !txEndDate || t.date <= txEndDate;

    return matchesSearch && matchesType && matchesStatus && matchesStart && matchesEnd;
  }).sort((a, b) => {
    const timeA = new Date(a.date).getTime();
    const timeB = new Date(b.date).getTime();
    return txSortOrder === 'desc' ? timeB - timeA : timeA - timeB;
  });

  const totalTxPages = Math.ceil(filteredTransactions.length / itemsPerPage) || 1;
  const paginatedTransactions = filteredTransactions.slice((txPage - 1) * itemsPerPage, txPage * itemsPerPage);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'accounts', label: 'My Accounts', icon: Wallet },
    { id: 'transactions', label: 'Transaction History', icon: History },
    { id: 'domestic', label: 'Domestic Transfers', icon: Send },
    { id: 'wire', label: 'International Wire Transfers', icon: Globe },
    { id: 'beneficiaries', label: 'Beneficiaries', icon: Users },
    { id: 'statements', label: 'Statements', icon: FileText },
    { id: 'details', label: 'Account Details', icon: CreditCard },
    { id: 'notifications', label: 'Notifications', icon: Bell, count: notifications.length },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col font-sans-body text-slate-800">
      
      {/* ================= TOP NAVIGATION BAR ================= */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
          
          {/* Brand Zone */}
          <div className="flex items-center gap-4">
            <BrandLogo size="md" />
            <div className="hidden lg:block h-8 w-px bg-slate-200" />
            <div className="hidden lg:block text-xs">
              <span className="font-serif-display font-semibold text-slate-900 block leading-tight">
                {account.accountHolderName}
              </span>
              <span className="font-mono text-[11px] text-slate-500">
                {account.accountNumber} · {account.accountStatus}
              </span>
            </div>
          </div>

          {/* Quick Actions & Profile Zone */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => onRefreshData()}
              className="p-2 rounded-xl text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors"
              title="Refresh Shared Depository Data"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            <button
              onClick={() => setActiveNav('notifications')}
              className="relative p-2 rounded-xl text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors"
              title="View Bulletins & Advisories"
            >
              <Bell className="w-4 h-4" />
              {notifications.length > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#C5921E]" />
              )}
            </button>

            <div className="h-6 w-px bg-slate-200" />

            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-[#0B2548] text-[#C5921E] flex items-center justify-center font-serif-display font-bold text-xs shadow-xs">
                AH
              </div>
              <button
                onClick={onLogout}
                className="inline-flex items-center gap-1.5 py-1.5 px-3 rounded-lg text-xs font-semibold text-slate-600 hover:text-rose-700 hover:bg-rose-50 transition-colors"
                title="Logout from Private Banking Portal"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          </div>
        </div>

        {/* Secondary Navigation Ribbon */}
        <div className="bg-[#0B2548] px-4 sm:px-6 lg:px-8 border-t border-[#C5921E]/30">
          <div className="max-w-7xl mx-auto flex items-center gap-1 overflow-x-auto py-1.5 no-scrollbar">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeNav === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveNav(item.id as VisitorNav);
                    if (item.id === 'domestic') setDomesticStep('form');
                    if (item.id === 'wire') setWireStep('form');
                  }}
                  className={`flex items-center gap-2 py-2 px-3 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                    isActive
                      ? 'bg-[#C5921E] text-[#071933] font-bold shadow-xs'
                      : 'text-slate-200 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5 shrink-0" />
                  <span>{item.label}</span>
                  {item.count !== undefined && item.count > 0 && (
                    <span className="bg-[#071933] text-[#C5921E] text-[10px] px-1.5 py-0.2 rounded-full font-bold ml-0.5">
                      {item.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* ================= MAIN PORTAL VIEWPORT ================= */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        
        {/* Fiduciary Bulletin Banner from Administrator */}
        {account.announcements && (
          <div className="p-4 bg-gradient-to-r from-amber-50 to-orange-50 border-l-4 border-[#C5921E] rounded-xl shadow-xs text-xs text-amber-950 flex items-start gap-3">
            <Info className="w-4 h-4 text-[#C5921E] shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <strong className="font-semibold block text-[#0B2548]">Official Institutional Announcement</strong>
              {account.announcements}
            </div>
          </div>
        )}

        {/* ================= TAB 1: DASHBOARD ================= */}
        {activeNav === 'dashboard' && (
          <div className="space-y-6 animate-in fade-in">
            
            {/* Primary Hero Balance Card */}
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0B2548] via-[#091E3A] to-[#061529] text-white p-7 sm:p-9 shadow-xl border border-[#C5921E]/30">
              
              {/* Background Geometric Accent */}
              <div 
                className="absolute inset-0 opacity-[0.035] pointer-events-none"
                style={{
                  backgroundImage: 'radial-gradient(#C5921E 1px, transparent 1px)',
                  backgroundSize: '24px 24px'
                }}
              />

              <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-white/10">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-sans-body uppercase tracking-[0.2em] text-[#C5921E] font-semibold">
                      Fiduciary Depository Reserve
                    </span>
                    <span className="bg-white/10 text-slate-300 text-[10px] px-2 py-0.5 rounded-full font-mono">
                      {account.accountStatus}
                    </span>
                  </div>
                  <h1 className="font-serif-display font-bold text-2xl sm:text-3xl text-white">
                    {account.accountHolderName}
                  </h1>
                  <p className="text-xs text-slate-300 flex items-center gap-2 font-mono">
                    <span>{account.accountNumber}</span>
                    <button
                      onClick={() => handleCopy(account.accountNumber, 'acc')}
                      className="text-[#C5921E] hover:text-white transition-colors"
                      title="Copy account number"
                    >
                      {copiedField === 'acc' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                    <span>·</span>
                    <span>{account.accountType}</span>
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowBalance(!showBalance)}
                    className="inline-flex items-center gap-1.5 py-2 px-3.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-slate-200 transition-colors"
                  >
                    {showBalance ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    <span>{showBalance ? 'Hide Balance' : 'Reveal Balance'}</span>
                  </button>
                  <button
                    onClick={() => setShowStatementModal(true)}
                    className="inline-flex items-center gap-1.5 py-2 px-3.5 rounded-xl bg-[#C5921E] hover:bg-[#A67610] text-[#071933] text-xs font-bold transition-colors shadow-sm"
                  >
                    <FileText className="w-4 h-4" />
                    <span>Statement</span>
                  </button>
                </div>
              </div>

              {/* Balances Display Strip */}
              <div className="relative z-10 pt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <div>
                  <span className="text-xs uppercase tracking-wider text-slate-400 block mb-1 font-medium">
                    Current Displayed Balance
                  </span>
                  <div className="font-serif-display text-3xl sm:text-4xl font-bold text-white tracking-tight tabular-nums">
                    {showBalance ? (
                      `${account.currencySymbol}${account.currentBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                    ) : (
                      '••••••••••••'
                    )}
                  </div>
                  <span className="text-[11px] text-[#C5921E] font-medium block mt-1">
                    Settled Tier-1 Custody ({account.currency})
                  </span>
                </div>

                <div>
                  <span className="text-xs uppercase tracking-wider text-slate-400 block mb-1 font-medium">
                    Available Discretionary Liquidity
                  </span>
                  <div className="font-serif-display text-3xl sm:text-4xl font-bold text-emerald-400 tracking-tight tabular-nums">
                    {showBalance ? (
                      `${account.currencySymbol}${account.availableBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                    ) : (
                      '••••••••••••'
                    )}
                  </div>
                  <span className="text-[11px] text-slate-400 block mt-1">
                    Immediate available clearing liquidity
                  </span>
                </div>

                <div>
                  <span className="text-xs uppercase tracking-wider text-slate-400 block mb-1 font-medium">
                    Cumulative Inflows (Deposits)
                  </span>
                  <div className="font-serif-display text-2xl sm:text-3xl font-semibold text-slate-200 tabular-nums">
                    {showBalance ? (
                      `${account.currencySymbol}${account.totalDeposits.toLocaleString('en-US', { minimumFractionDigits: 2 })}`
                    ) : (
                      '••••••••••••'
                    )}
                  </div>
                  <span className="text-[11px] text-emerald-400 flex items-center gap-1 mt-1">
                    <TrendingUp className="w-3.5 h-3.5" />
                    <span>Fixed income & coupon sweep</span>
                  </span>
                </div>

                <div>
                  <span className="text-xs uppercase tracking-wider text-slate-400 block mb-1 font-medium">
                    Cumulative Outflows (Disbursements)
                  </span>
                  <div className="font-serif-display text-2xl sm:text-3xl font-semibold text-slate-200 tabular-nums">
                    {showBalance ? (
                      `${account.currencySymbol}${account.totalWithdrawals.toLocaleString('en-US', { minimumFractionDigits: 2 })}`
                    ) : (
                      '••••••••••••'
                    )}
                  </div>
                  <span className="text-[11px] text-slate-400 block mt-1">
                    Syndications & trust expenses
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Actions Strip */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <button
                onClick={() => setActiveNav('domestic')}
                className="bg-white p-5 rounded-2xl border border-slate-200 hover:border-[#0B2548] transition-all text-left group shadow-xs cursor-pointer"
              >
                <div className="w-10 h-10 rounded-xl bg-[#0B2548]/10 text-[#0B2548] flex items-center justify-center mb-3 group-hover:bg-[#0B2548] group-hover:text-white transition-colors">
                  <Send className="w-5 h-5" />
                </div>
                <h3 className="font-serif-display font-bold text-base text-[#0B2548]">
                  Domestic Transfer
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Execute commercial bank payments within Federal Clearing Networks.
                </p>
              </button>

              <button
                onClick={() => setActiveNav('wire')}
                className="bg-white p-5 rounded-2xl border border-slate-200 hover:border-[#0B2548] transition-all text-left group shadow-xs cursor-pointer"
              >
                <div className="w-10 h-10 rounded-xl bg-[#C5921E]/15 text-[#C5921E] flex items-center justify-center mb-3 group-hover:bg-[#C5921E] group-hover:text-[#071933] transition-colors">
                  <Globe className="w-5 h-5" />
                </div>
                <h3 className="font-serif-display font-bold text-base text-[#0B2548]">
                  International Wire
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Cross-border SWIFT/IBAN transfer protocol with multi-signatory validation.
                </p>
              </button>

              <button
                onClick={() => setShowStatementModal(true)}
                className="bg-white p-5 rounded-2xl border border-slate-200 hover:border-[#0B2548] transition-all text-left group shadow-xs cursor-pointer"
              >
                <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center mb-3 group-hover:bg-[#0B2548] group-hover:text-white transition-colors">
                  <FileText className="w-5 h-5" />
                </div>
                <h3 className="font-serif-display font-bold text-base text-[#0B2548]">
                  Fiduciary Statement
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Generate authenticated ledger reports and official fiduciary records.
                </p>
              </button>
            </div>

            {/* Recent Transactions & Fiduciary Profile */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Recent Transactions (2 Columns) */}
              <div className="lg:col-span-2 bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <History className="w-5 h-5 text-[#0B2548]" />
                    <h2 className="font-serif-display font-bold text-lg text-[#0B2548]">
                      Recent Ledger Activity
                    </h2>
                  </div>
                  <button
                    onClick={() => setActiveNav('transactions')}
                    className="text-xs text-[#C5921E] font-semibold hover:underline inline-flex items-center gap-1"
                  >
                    <span>View All {transactions.length} Records</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="divide-y divide-slate-100">
                  {transactions.slice(0, 7).map((tx) => {
                    const isDeposit = tx.type === 'Deposit';
                    return (
                      <div
                        key={tx.id}
                        onClick={() => setSelectedTx(tx)}
                        className="py-3.5 flex items-center justify-between gap-4 hover:bg-slate-50 px-2 rounded-xl transition-colors cursor-pointer"
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                            isDeposit ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-700'
                          }`}>
                            {isDeposit ? <ArrowDownLeft className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                          </div>
                          <div>
                            <span className="font-semibold text-slate-900 text-xs sm:text-sm block">
                              {tx.description}
                            </span>
                            <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                              <span className="font-mono">{tx.date}</span>
                              <span>·</span>
                              <span>{tx.counterparty}</span>
                            </div>
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <div className={`font-serif-display font-bold text-sm sm:text-base tabular-nums ${
                            isDeposit ? 'text-emerald-700' : 'text-slate-900'
                          }`}>
                            {showBalance ? (
                              `${isDeposit ? '+' : '-'}${account.currencySymbol}${tx.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}`
                            ) : (
                              '••••••'
                            )}
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono">{tx.status}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Fiduciary Profile Snapshot (1 Column) */}
              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
                <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
                  <ShieldCheck className="w-5 h-5 text-[#C5921E]" />
                  <h3 className="font-serif-display font-bold text-lg text-[#0B2548]">
                    Depository Governance
                  </h3>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <span className="text-slate-500 uppercase tracking-wider text-[10px] block">Custodian Depository</span>
                    <p className="font-semibold text-slate-800">{account.custodianBank}</p>
                    <p className="text-[11px] text-slate-500">{account.custodianJurisdiction}</p>
                  </div>

                  <div className="pt-2 border-t border-slate-100">
                    <span className="text-slate-500 uppercase tracking-wider text-[10px] block">Senior Managing Trustee</span>
                    <p className="font-semibold text-slate-800">{account.relationshipManager}</p>
                    <p className="text-[11px] text-slate-500">{account.relationshipEmail}</p>
                  </div>

                  <div className="pt-2 border-t border-slate-100">
                    <span className="text-slate-500 uppercase tracking-wider text-[10px] block">Clearing Identifiers</span>
                    <div className="grid grid-cols-2 gap-2 mt-1 font-mono text-[11px]">
                      <div>
                        <span className="text-slate-400 block text-[10px]">SWIFT / BIC</span>
                        <strong className="text-slate-800">{account.swiftBic}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Routing</span>
                        <strong className="text-slate-800">{account.routingNumber}</strong>
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100">
                    <span className="text-slate-500 uppercase tracking-wider text-[10px] block">Registration & Audit</span>
                    <p className="text-[11px] text-slate-700 font-mono mt-0.5">{account.fiduciaryRegistrationNumber}</p>
                    <p className="text-[10px] text-slate-500 mt-0.5">Auditor: {account.lastAuditedBy}</p>
                  </div>
                </div>
              </div>

            </div>

          </div>
        )}

        {/* ================= TAB 2: MY ACCOUNTS ================= */}
        {activeNav === 'accounts' && (
          <div className="space-y-6 animate-in fade-in">
            <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs">
              <div className="pb-4 border-b border-slate-100 mb-6">
                <h2 className="font-serif-display font-bold text-2xl text-[#0B2548]">
                  Fiduciary Depository Accounts & Ring-Fenced Vaults
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  Consolidated overview of institutional sub-portfolios and liquidity vaults.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {/* Vault 1 */}
                <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-50 to-white border border-slate-200 hover:border-[#0B2548] transition-all shadow-xs">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] font-bold uppercase tracking-wider bg-[#0B2548] text-white px-2 py-0.5 rounded">
                      Primary Vault
                    </span>
                    <span className="text-xs text-emerald-600 font-semibold">Active</span>
                  </div>
                  <h3 className="font-serif-display font-bold text-lg text-slate-900 mb-1">
                    Fiduciary Operating Reserve
                  </h3>
                  <p className="font-mono text-xs text-slate-500 mb-4">{account.accountNumber}</p>
                  
                  <div className="pt-3 border-t border-slate-100">
                    <span className="text-[11px] uppercase tracking-wider text-slate-400 block">Allocated Balance</span>
                    <div className="font-serif-display text-2xl font-bold text-[#0B2548] tabular-nums mt-0.5">
                      {account.currencySymbol}{account.currentBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </div>
                  </div>
                </div>

                {/* Vault 2 */}
                <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-50 to-white border border-slate-200 hover:border-[#0B2548] transition-all shadow-xs">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] font-bold uppercase tracking-wider bg-[#C5921E] text-[#071933] px-2 py-0.5 rounded">
                      Sovereign Bonds
                    </span>
                    <span className="text-xs text-emerald-600 font-semibold">Audited</span>
                  </div>
                  <h3 className="font-serif-display font-bold text-lg text-slate-900 mb-1">
                    US Treasury & Gilt Custody
                  </h3>
                  <p className="font-mono text-xs text-slate-500 mb-4">LHT-SOV-4491-002</p>
                  
                  <div className="pt-3 border-t border-slate-100">
                    <span className="text-[11px] uppercase tracking-wider text-slate-400 block">Bond Nominal Value</span>
                    <div className="font-serif-display text-2xl font-bold text-slate-900 tabular-nums mt-0.5">
                      {account.currencySymbol}85,400,000.00
                    </div>
                  </div>
                </div>

                {/* Vault 3 */}
                <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-50 to-white border border-slate-200 hover:border-[#0B2548] transition-all shadow-xs">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] font-bold uppercase tracking-wider bg-slate-800 text-white px-2 py-0.5 rounded">
                      Swiss Vault
                    </span>
                    <span className="text-xs text-emerald-600 font-semibold">Allocated</span>
                  </div>
                  <h3 className="font-serif-display font-bold text-lg text-slate-900 mb-1">
                    Geneva Discretionary Vault
                  </h3>
                  <p className="font-mono text-xs text-slate-500 mb-4">LHT-GVA-8819-CH</p>
                  
                  <div className="pt-3 border-t border-slate-100">
                    <span className="text-[11px] uppercase tracking-wider text-slate-400 block">Gold & Liquidity Reserve</span>
                    <div className="font-serif-display text-2xl font-bold text-slate-900 tabular-nums mt-0.5">
                      {account.currencySymbol}56,700,420.50
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 3: TRANSACTION HISTORY (~100 RECORDS) ================= */}
        {activeNav === 'transactions' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6 animate-in fade-in">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <h2 className="font-serif-display font-bold text-2xl text-[#0B2548]">
                  Transaction History
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  View and manage your institutional account transaction records.
                </p>
              </div>

              <button
                onClick={() => setShowStatementModal(true)}
                className="inline-flex items-center gap-2 py-2 px-4 rounded-xl bg-[#0B2548] text-white text-xs font-semibold hover:bg-[#071933] transition-colors"
              >
                <FileText className="w-4 h-4 text-[#C5921E]" />
                <span>Export Statement</span>
              </button>
            </div>

            {/* Filter Suite */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
              <div className="lg:col-span-2 relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={txSearch}
                  onChange={(e) => {
                    setTxSearch(e.target.value);
                    setTxPage(1);
                  }}
                  placeholder="Search description, reference, counterparty..."
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#0B2548]"
                />
              </div>

              <div>
                <select
                  value={txTypeFilter}
                  onChange={(e) => {
                    setTxTypeFilter(e.target.value);
                    setTxPage(1);
                  }}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white"
                >
                  <option value="all">All Types</option>
                  <option value="deposit">Deposit</option>
                  <option value="withdrawal">Withdrawal</option>
                  <option value="internal transfer">Internal Transfer</option>
                  <option value="external transfer">External Transfer</option>
                  <option value="adjustment">Adjustment</option>
                  <option value="payment">Payment</option>
                </select>
              </div>

              <div>
                <select
                  value={txStatusFilter}
                  onChange={(e) => {
                    setTxStatusFilter(e.target.value);
                    setTxPage(1);
                  }}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white"
                >
                  <option value="all">All Statuses</option>
                  <option value="pending">Pending</option>
                  <option value="processing">Processing</option>
                  <option value="completed">Completed</option>
                  <option value="settled">Settled</option>
                  <option value="audited">Audited</option>
                  <option value="failed">Failed</option>
                  <option value="reversed">Reversed</option>
                </select>
              </div>

              <div>
                <select
                  value={txSortOrder}
                  onChange={(e) => setTxSortOrder(e.target.value as any)}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white"
                >
                  <option value="desc">Date: Newest First</option>
                  <option value="asc">Date: Oldest First</option>
                </select>
              </div>
            </div>

            {/* Results count & reset */}
            <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
              <span>
                Found <strong>{filteredTransactions.length}</strong> transactions matching criteria
              </span>
              {(txSearch || txTypeFilter !== 'all' || txStatusFilter !== 'all') && (
                <button
                  onClick={() => {
                    setTxSearch('');
                    setTxTypeFilter('all');
                    setTxStatusFilter('all');
                    setTxPage(1);
                  }}
                  className="text-[#C5921E] hover:underline font-semibold"
                >
                  Reset Filters
                </button>
              )}
            </div>

            {/* Transactions Table */}
            <div className="overflow-x-auto border border-slate-200 rounded-xl">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#0B2548] text-white">
                  <tr>
                    <th className="py-3 px-3.5 font-semibold">Date</th>
                    <th className="py-3 px-3.5 font-semibold">Reference</th>
                    <th className="py-3 px-3.5 font-semibold">Description</th>
                    <th className="py-3 px-3.5 font-semibold">Category</th>
                    <th className="py-3 px-3.5 font-semibold">Type</th>
                    <th className="py-3 px-3.5 font-semibold text-right">Amount ({account.currency})</th>
                    <th className="py-3 px-3.5 font-semibold text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {paginatedTransactions.map((tx) => {
                    const isDeposit = tx.type === 'Deposit';
                    return (
                      <tr
                        key={tx.id}
                        onClick={() => setSelectedTx(tx)}
                        className="hover:bg-slate-50 cursor-pointer transition-colors"
                      >
                        <td className="py-3 px-3.5 font-mono text-slate-600 whitespace-nowrap">{tx.date}</td>
                        <td className="py-3 px-3.5 font-mono font-semibold text-[#0B2548] whitespace-nowrap">{tx.reference}</td>
                        <td className="py-3 px-3.5 text-slate-900 font-medium">
                          {tx.description}
                          <span className="block text-[11px] text-slate-500 font-normal">{tx.counterparty}</span>
                        </td>
                        <td className="py-3 px-3.5 text-slate-600 whitespace-nowrap">{tx.category}</td>
                        <td className="py-3 px-3.5 whitespace-nowrap text-slate-700">{tx.type}</td>
                        <td className={`py-3 px-3.5 text-right font-semibold tabular-nums whitespace-nowrap ${
                          isDeposit ? 'text-emerald-700' : 'text-slate-900'
                        }`}>
                          {isDeposit ? '+' : '-'}{account.currencySymbol}{tx.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="py-3 px-3.5 text-right whitespace-nowrap">
                          <span className="text-[11px] text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                            {tx.status}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Pagination Controls */}
            {totalTxPages > 1 && (
              <div className="flex items-center justify-between text-xs pt-2">
                <span className="text-slate-500">
                  Page <strong>{txPage}</strong> of <strong>{totalTxPages}</strong>
                </span>
                <div className="flex items-center gap-2">
                  <button
                    disabled={txPage <= 1}
                    onClick={() => setTxPage((p) => Math.max(1, p - 1))}
                    className="py-1.5 px-3 rounded-lg border border-slate-300 disabled:opacity-40 hover:bg-slate-50 transition-colors"
                  >
                    Previous
                  </button>
                  <button
                    disabled={txPage >= totalTxPages}
                    onClick={() => setTxPage((p) => Math.min(totalTxPages, p + 1))}
                    className="py-1.5 px-3 rounded-lg border border-slate-300 disabled:opacity-40 hover:bg-slate-50 transition-colors"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= TAB 4: DOMESTIC TRANSFERS ================= */}
        {activeNav === 'domestic' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs max-w-2xl mx-auto space-y-6 animate-in fade-in">
            <div className="pb-4 border-b border-slate-100">
              <h2 className="font-serif-display font-bold text-2xl text-[#0B2548]">
                Domestic Institutional Transfer
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Initiate an institutional funds transfer to a domestic counterparty bank within the Federal Clearing Network.
              </p>
            </div>

            {/* Step 1: Input Form */}
            {domesticStep === 'form' && (
              <form onSubmit={handleDomesticReview} className="space-y-4 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Recipient Full Name / Entity *
                  </label>
                  <input
                    type="text"
                    required
                    value={domesticForm.recipientName}
                    onChange={(e) => setDomesticForm({ ...domesticForm, recipientName: e.target.value })}
                    placeholder="e.g. Wellington Asset Custody LLC"
                    className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0B2548]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Recipient Account Number *
                    </label>
                    <input
                      type="text"
                      required
                      value={domesticForm.recipientAccount}
                      onChange={(e) => setDomesticForm({ ...domesticForm, recipientAccount: e.target.value })}
                      placeholder="e.g. 021008472910"
                      className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl font-mono focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Receiving Financial Institution *
                    </label>
                    <input
                      type="text"
                      required
                      value={domesticForm.receivingInstitution}
                      onChange={(e) => setDomesticForm({ ...domesticForm, receivingInstitution: e.target.value })}
                      placeholder="e.g. JPMorgan Chase Bank NA"
                      className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="sm:col-span-2">
                    <label className="block font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Transfer Amount *
                    </label>
                    <div className="relative">
                      <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-semibold text-slate-500">
                        {account.currencySymbol}
                      </span>
                      <input
                        type="number"
                        step="0.01"
                        required
                        value={domesticForm.amount}
                        onChange={(e) => setDomesticForm({ ...domesticForm, amount: e.target.value })}
                        placeholder="250000"
                        className="w-full pl-8 pr-3 py-3 text-sm font-semibold bg-slate-50 border border-slate-300 rounded-xl tabular-nums focus:bg-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Currency
                    </label>
                    <input
                      type="text"
                      disabled
                      value={domesticForm.currency}
                      className="w-full p-3 text-sm font-mono bg-slate-100 border border-slate-200 rounded-xl text-slate-600"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Payment Description
                  </label>
                  <input
                    type="text"
                    value={domesticForm.description}
                    onChange={(e) => setDomesticForm({ ...domesticForm, description: e.target.value })}
                    placeholder="e.g. Sovereign Bond Coupon Settlement"
                    className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Reference / Remarks (Optional)
                  </label>
                  <input
                    type="text"
                    value={domesticForm.reference}
                    onChange={(e) => setDomesticForm({ ...domesticForm, reference: e.target.value })}
                    placeholder="e.g. INV-2026-9921"
                    className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl font-mono focus:bg-white"
                  />
                </div>

                <div className="pt-3">
                  <button
                    type="submit"
                    className="w-full py-3.5 px-4 rounded-xl text-white font-semibold text-sm bg-[#0B2548] hover:bg-[#071933] transition-all shadow-md shadow-[#0B2548]/20 cursor-pointer"
                  >
                    Review Transfer Details →
                  </button>
                </div>
              </form>
            )}

            {/* Step 2: Review Screen */}
            {domesticStep === 'review' && (
              <div className="space-y-5 animate-in fade-in">
                <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3 text-xs">
                  <h3 className="font-serif-display font-bold text-base text-[#0B2548] pb-2 border-b border-slate-200">
                    Verify Transfer Instructions
                  </h3>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-slate-500 uppercase text-[10px] block">Recipient</span>
                      <strong className="text-slate-900 text-sm">{domesticForm.recipientName}</strong>
                    </div>
                    <div>
                      <span className="text-slate-500 uppercase text-[10px] block">Receiving Institution</span>
                      <strong className="text-slate-900 text-sm">{domesticForm.receivingInstitution}</strong>
                    </div>
                    <div>
                      <span className="text-slate-500 uppercase text-[10px] block">Account Number</span>
                      <span className="font-mono text-slate-800">{domesticForm.recipientAccount}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 uppercase text-[10px] block">Transfer Amount</span>
                      <span className="font-serif-display font-bold text-base text-[#0B2548] tabular-nums">
                        {account.currencySymbol}{parseFloat(domesticForm.amount).toLocaleString('en-US', { minimumFractionDigits: 2 })} {domesticForm.currency}
                      </span>
                    </div>
                    {domesticForm.description && (
                      <div className="col-span-2">
                        <span className="text-slate-500 uppercase text-[10px] block">Description</span>
                        <span className="text-slate-800">{domesticForm.description}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-700">
                  <p>
                    <strong className="text-[#0B2548]">Institutional Notice:</strong> Transfers initiated from this account are subject to cryptographic validation and multi-signatory trustee clearance.
                  </p>
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setDomesticStep('form')}
                    className="flex-1 py-3 px-4 rounded-xl border border-slate-300 text-slate-700 font-semibold text-xs hover:bg-slate-50 transition-colors"
                  >
                    Edit Details
                  </button>
                  <button
                    type="button"
                    onClick={handleDomesticSubmit}
                    className="flex-1 py-3 px-4 rounded-xl bg-[#0B2548] text-white font-semibold text-xs hover:bg-[#071933] transition-colors shadow-md"
                  >
                    Confirm & Submit Transfer
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Transaction Processing Screen with EightDotSpinner */}
            {domesticStep === 'processing' && (
              <div className="bg-[#071933] text-white rounded-2xl p-6 sm:p-8 space-y-6 text-center border border-[#C5921E]/30 shadow-xl animate-in fade-in">
                <div className="space-y-1">
                  <span className="text-[11px] font-mono uppercase tracking-widest text-[#C5921E] font-semibold">
                    Clearing Protocol Active
                  </span>
                  <h3 className="font-serif-display font-bold text-xl sm:text-2xl text-white">
                    Processing Institutional Transfer
                  </h3>
                  <p className="text-xs text-slate-400">
                    Routing instruction through Federal Reserve Automated Clearing House (ACH/Fedwire)
                  </p>
                </div>

                {/* Eight-Dot Circular Animation with Centered Percentage and Timer */}
                <div className="py-4 flex justify-center">
                  <EightDotSpinner
                    percentage={transferProgress}
                    timeLabel={transferTimeRemaining}
                    size={160}
                    variant="dark"
                  />
                </div>

                {/* Current Stage Indicator */}
                <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 max-w-md mx-auto">
                  <div className="flex items-center justify-center gap-2 text-xs font-medium text-slate-200">
                    <span className="w-2 h-2 rounded-full bg-[#C5921E] animate-ping" />
                    <span>{transferProcessingStage}</span>
                  </div>
                </div>

                {/* 4 Clearing Checklist Stages */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] text-left pt-2 border-t border-slate-800">
                  <div className={`p-2.5 rounded-lg border ${transferProgress >= 25 ? 'border-[#C5921E]/50 bg-[#C5921E]/10 text-white' : 'border-slate-800 bg-slate-900/40 text-slate-500'}`}>
                    <span className="block font-semibold">1. Protocol</span>
                    <span className="text-[10px] text-slate-400">Handshake</span>
                  </div>
                  <div className={`p-2.5 rounded-lg border ${transferProgress >= 50 ? 'border-[#C5921E]/50 bg-[#C5921E]/10 text-white' : 'border-slate-800 bg-slate-900/40 text-slate-500'}`}>
                    <span className="block font-semibold">2. Balance</span>
                    <span className="text-[10px] text-slate-400">Verification</span>
                  </div>
                  <div className={`p-2.5 rounded-lg border ${transferProgress >= 75 ? 'border-[#C5921E]/50 bg-[#C5921E]/10 text-white' : 'border-slate-800 bg-slate-900/40 text-slate-500'}`}>
                    <span className="block font-semibold">3. Signature</span>
                    <span className="text-[10px] text-slate-400">Cryptographic</span>
                  </div>
                  <div className={`p-2.5 rounded-lg border ${transferProgress >= 95 ? 'border-[#C5921E]/50 bg-[#C5921E]/10 text-white' : 'border-slate-800 bg-slate-900/40 text-slate-500'}`}>
                    <span className="block font-semibold">4. Gateway</span>
                    <span className="text-[10px] text-slate-400">Transmission</span>
                  </div>
                </div>
              </div>
            )}

            {/* Step 4: Transaction Outcome Screen */}
            {domesticStep === 'result' && domesticResult && (
              <div className="space-y-6 animate-in fade-in">
                {/* Header Zone */}
                <div className="text-center space-y-2">
                  <div className="w-14 h-14 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center mx-auto border-2 border-rose-200">
                    <AlertTriangle className="w-7 h-7 text-rose-600" />
                  </div>
                  <h3 className="font-serif-display font-bold text-2xl text-slate-900">
                    Transaction Unsuccessful
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-lg mx-auto">
                    Live financial clearing is currently restricted. Institutional settlement gateway requires direct authorization from the Senior Managing Trustee.
                  </p>
                </div>

                {/* Transfer Details Card */}
                <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3 text-xs">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                    <span className="text-slate-500 font-medium">Transaction Reference</span>
                    <span className="font-mono font-bold text-slate-900">{domesticResult.transferDetails?.reference}</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div>
                      <span className="text-slate-500 uppercase text-[10px] block">Recipient</span>
                      <strong className="text-slate-900">{domesticForm.recipientName}</strong>
                    </div>
                    <div>
                      <span className="text-slate-500 uppercase text-[10px] block">Receiving Institution</span>
                      <strong className="text-slate-900">{domesticForm.receivingInstitution}</strong>
                    </div>
                    <div>
                      <span className="text-slate-500 uppercase text-[10px] block">Transfer Amount</span>
                      <strong className="text-slate-900 font-serif-display text-sm">
                        {account.currencySymbol}{parseFloat(domesticForm.amount || '0').toLocaleString('en-US', { minimumFractionDigits: 2 })} {domesticForm.currency}
                      </strong>
                    </div>
                    <div>
                      <span className="text-slate-500 uppercase text-[10px] block">Timestamp</span>
                      <span className="text-slate-700 font-mono">{domesticResult.transferDetails?.formattedTime}</span>
                    </div>
                    <div className="sm:col-span-2 pt-1 border-t border-slate-200/60">
                      <span className="text-slate-500 uppercase text-[10px] block">Gateway Response</span>
                      <span className="text-rose-700 font-medium">{domesticResult.transferDetails?.failureReason}</span>
                    </div>
                  </div>
                </div>

                {/* Clear Next Steps for User */}
                <div className="p-4 bg-amber-50/70 rounded-xl border border-amber-200 text-xs text-amber-950 space-y-2">
                  <div className="font-semibold flex items-center gap-1.5 text-amber-900">
                    <HelpCircle className="w-4 h-4 text-[#C5921E]" />
                    <span>Recommended Next Steps:</span>
                  </div>
                  <ul className="list-disc pl-5 space-y-1 text-slate-700 text-[11px]">
                    <li>Contact your Senior Managing Trustee (<strong>{account.relationshipEmail}</strong>) to request live signatory clearance and gateway release.</li>
                    <li>Verify recipient account coordinates against your pre-approved institutional counterparty schedule.</li>
                    <li>Return to the main dashboard to view settled balance reserves and historical depository records.</li>
                  </ul>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                  <button
                    onClick={resetDomesticTransfer}
                    className="w-full sm:flex-1 py-3 px-4 rounded-xl border border-slate-300 text-slate-700 font-semibold text-xs hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    Try Another Transfer
                  </button>
                  <button
                    onClick={() => {
                      resetDomesticTransfer();
                      setActiveNav('dashboard');
                    }}
                    className="w-full sm:flex-1 py-3 px-4 rounded-xl bg-[#0B2548] text-white font-semibold text-xs hover:bg-[#071933] transition-colors shadow-sm cursor-pointer"
                  >
                    Return to Dashboard
                  </button>
                </div>
              </div>
            )}

          </div>
        )}

        {/* ================= TAB 5: INTERNATIONAL WIRE TRANSFERS ================= */}
        {activeNav === 'wire' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs max-w-2xl mx-auto space-y-6 animate-in fade-in">
            <div className="pb-4 border-b border-slate-100">
              <h2 className="font-serif-display font-bold text-2xl text-[#0B2548]">
                International Wire Transfer
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Execute cross-border SWIFT/ISO-20022 wire settlements with foreign custodian banks.
              </p>
            </div>

            {/* Wire Step 1: Form */}
            {wireStep === 'form' && (
              <form onSubmit={handleWireReview} className="space-y-4 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Beneficiary Full Legal Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={wireForm.beneficiaryName}
                    onChange={(e) => setWireForm({ ...wireForm, beneficiaryName: e.target.value })}
                    placeholder="e.g. Banque Pictet & Cie SA Geneva"
                    className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Beneficiary Bank Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={wireForm.beneficiaryBank}
                      onChange={(e) => setWireForm({ ...wireForm, beneficiaryBank: e.target.value })}
                      placeholder="e.g. UBS Switzerland AG"
                      className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Bank Address / City *
                    </label>
                    <input
                      type="text"
                      required
                      value={wireForm.bankAddress}
                      onChange={(e) => setWireForm({ ...wireForm, bankAddress: e.target.value })}
                      placeholder="e.g. Bahnhofstrasse 45, Zurich"
                      className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      IBAN or Account Number *
                    </label>
                    <input
                      type="text"
                      required
                      value={wireForm.accountOrIban}
                      onChange={(e) => setWireForm({ ...wireForm, accountOrIban: e.target.value })}
                      placeholder="CH93 0024 0000 8812 4019"
                      className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl font-mono focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      SWIFT / BIC Code *
                    </label>
                    <input
                      type="text"
                      required
                      value={wireForm.swiftBic}
                      onChange={(e) => setWireForm({ ...wireForm, swiftBic: e.target.value })}
                      placeholder="UBSWCHZH80A"
                      className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl font-mono uppercase focus:bg-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Destination Country *
                    </label>
                    <select
                      value={wireForm.destinationCountry}
                      onChange={(e) => setWireForm({ ...wireForm, destinationCountry: e.target.value })}
                      className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl"
                    >
                      <option value="Switzerland">Switzerland (CH)</option>
                      <option value="United Kingdom">United Kingdom (GB)</option>
                      <option value="Luxembourg">Luxembourg (LU)</option>
                      <option value="Singapore">Singapore (SG)</option>
                      <option value="Germany">Germany (DE)</option>
                      <option value="United States">United States (US)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Transfer Currency
                    </label>
                    <select
                      value={wireForm.transferCurrency}
                      onChange={(e) => setWireForm({ ...wireForm, transferCurrency: e.target.value })}
                      className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl font-mono"
                    >
                      <option value="USD">USD ($)</option>
                      <option value="EUR">EUR (€)</option>
                      <option value="GBP">GBP (£)</option>
                      <option value="CHF">CHF (Fr)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Amount *
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      required
                      value={wireForm.transferAmount}
                      onChange={(e) => setWireForm({ ...wireForm, transferAmount: e.target.value })}
                      placeholder="1000000"
                      className="w-full p-3 text-sm font-semibold bg-slate-50 border border-slate-300 rounded-xl tabular-nums"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Payment Purpose & Economic Rationale
                  </label>
                  <input
                    type="text"
                    value={wireForm.paymentPurpose}
                    onChange={(e) => setWireForm({ ...wireForm, paymentPurpose: e.target.value })}
                    placeholder="e.g. Fiduciary Custody Realignment & Gold Vault Sweep"
                    className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>

                <div className="pt-3">
                  <button
                    type="submit"
                    className="w-full py-3.5 px-4 rounded-xl text-white font-semibold text-sm bg-[#0B2548] hover:bg-[#071933] transition-all shadow-md shadow-[#0B2548]/20 cursor-pointer"
                  >
                    Review International Wire →
                  </button>
                </div>
              </form>
            )}

            {/* Wire Step 2: Review Screen */}
            {wireStep === 'review' && (
              <div className="space-y-5 animate-in fade-in">
                <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3 text-xs">
                  <h3 className="font-serif-display font-bold text-base text-[#0B2548] pb-2 border-b border-slate-200">
                    Verify International Wire Instructions
                  </h3>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-slate-500 uppercase text-[10px] block">Beneficiary</span>
                      <strong className="text-slate-900 text-sm">{wireForm.beneficiaryName}</strong>
                    </div>
                    <div>
                      <span className="text-slate-500 uppercase text-[10px] block">Bank & Country</span>
                      <strong className="text-slate-900 text-sm">{wireForm.beneficiaryBank} ({wireForm.destinationCountry})</strong>
                    </div>
                    <div>
                      <span className="text-slate-500 uppercase text-[10px] block">IBAN / Account</span>
                      <span className="font-mono text-slate-800">{wireForm.accountOrIban}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 uppercase text-[10px] block">SWIFT / BIC</span>
                      <span className="font-mono text-slate-800">{wireForm.swiftBic}</span>
                    </div>
                    <div className="col-span-2">
                      <span className="text-slate-500 uppercase text-[10px] block">Wire Settlement Amount</span>
                      <span className="font-serif-display font-bold text-lg text-[#0B2548] tabular-nums">
                        {wireForm.transferCurrency} {parseFloat(wireForm.transferAmount).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-700">
                  <p>
                    <strong className="text-[#0B2548]">Institutional Notice:</strong> Cross-border SWIFT/ISO-20022 wire instructions require dual-key trustee authentication and correspondent network settlement.
                  </p>
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setWireStep('form')}
                    className="flex-1 py-3 px-4 rounded-xl border border-slate-300 text-slate-700 font-semibold text-xs hover:bg-slate-50 transition-colors"
                  >
                    Back to Edit
                  </button>
                  <button
                    type="button"
                    onClick={handleWireSubmit}
                    className="flex-1 py-3 px-4 rounded-xl bg-[#0B2548] text-white font-semibold text-xs hover:bg-[#071933] transition-colors shadow-md"
                  >
                    Transmit International Wire
                  </button>
                </div>
              </div>
            )}

            {/* Wire Step 3: Transaction Processing Screen with EightDotSpinner */}
            {wireStep === 'processing' && (
              <div className="bg-[#071933] text-white rounded-2xl p-6 sm:p-8 space-y-6 text-center border border-[#C5921E]/30 shadow-xl animate-in fade-in">
                <div className="space-y-1">
                  <span className="text-[11px] font-mono uppercase tracking-widest text-[#C5921E] font-semibold">
                    Cross-Border Clearing Active
                  </span>
                  <h3 className="font-serif-display font-bold text-xl sm:text-2xl text-white">
                    Processing International Wire
                  </h3>
                  <p className="text-xs text-slate-400">
                    Broadcasting ISO-20022 fiduciary settlement instruction to correspondent depository
                  </p>
                </div>

                {/* Eight-Dot Circular Animation with Centered Percentage and Timer */}
                <div className="py-4 flex justify-center">
                  <EightDotSpinner
                    percentage={transferProgress}
                    timeLabel={transferTimeRemaining}
                    size={160}
                    variant="dark"
                  />
                </div>

                {/* Current Stage Indicator */}
                <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 max-w-md mx-auto">
                  <div className="flex items-center justify-center gap-2 text-xs font-medium text-slate-200">
                    <span className="w-2 h-2 rounded-full bg-[#C5921E] animate-ping" />
                    <span>{transferProcessingStage}</span>
                  </div>
                </div>

                {/* 4 Clearing Checklist Stages */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] text-left pt-2 border-t border-slate-800">
                  <div className={`p-2.5 rounded-lg border ${transferProgress >= 25 ? 'border-[#C5921E]/50 bg-[#C5921E]/10 text-white' : 'border-slate-800 bg-slate-900/40 text-slate-500'}`}>
                    <span className="block font-semibold">1. Protocol</span>
                    <span className="text-[10px] text-slate-400">SWIFT BIC Check</span>
                  </div>
                  <div className={`p-2.5 rounded-lg border ${transferProgress >= 50 ? 'border-[#C5921E]/50 bg-[#C5921E]/10 text-white' : 'border-slate-800 bg-slate-900/40 text-slate-500'}`}>
                    <span className="block font-semibold">2. Balance</span>
                    <span className="text-[10px] text-slate-400">Vault Verification</span>
                  </div>
                  <div className={`p-2.5 rounded-lg border ${transferProgress >= 75 ? 'border-[#C5921E]/50 bg-[#C5921E]/10 text-white' : 'border-slate-800 bg-slate-900/40 text-slate-500'}`}>
                    <span className="block font-semibold">3. Signature</span>
                    <span className="text-[10px] text-slate-400">Trustee Cryptographic</span>
                  </div>
                  <div className={`p-2.5 rounded-lg border ${transferProgress >= 95 ? 'border-[#C5921E]/50 bg-[#C5921E]/10 text-white' : 'border-slate-800 bg-slate-900/40 text-slate-500'}`}>
                    <span className="block font-semibold">4. Gateway</span>
                    <span className="text-[10px] text-slate-400">Settlement Hub</span>
                  </div>
                </div>
              </div>
            )}

            {/* Wire Step 4: Transaction Outcome Screen */}
            {wireStep === 'result' && wireResult && (
              <div className="space-y-6 animate-in fade-in">
                {/* Header Zone */}
                <div className="text-center space-y-2">
                  <div className="w-14 h-14 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center mx-auto border-2 border-rose-200">
                    <AlertTriangle className="w-7 h-7 text-rose-600" />
                  </div>
                  <h3 className="font-serif-display font-bold text-2xl text-slate-900">
                    Transaction Unsuccessful
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-lg mx-auto">
                    Live financial clearing is currently restricted. Institutional settlement gateway requires direct authorization from the Senior Managing Trustee.
                  </p>
                </div>

                {/* Transfer Details Card */}
                <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3 text-xs">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                    <span className="text-slate-500 font-medium">Transaction Reference</span>
                    <span className="font-mono font-bold text-slate-900">{wireResult.transferDetails?.reference}</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div>
                      <span className="text-slate-500 uppercase text-[10px] block">Beneficiary</span>
                      <strong className="text-slate-900">{wireForm.beneficiaryName}</strong>
                    </div>
                    <div>
                      <span className="text-slate-500 uppercase text-[10px] block">Bank & Destination</span>
                      <strong className="text-slate-900">{wireForm.beneficiaryBank} ({wireForm.destinationCountry})</strong>
                    </div>
                    <div>
                      <span className="text-slate-500 uppercase text-[10px] block">IBAN / SWIFT</span>
                      <span className="text-slate-800 font-mono">{wireForm.accountOrIban} · {wireForm.swiftBic}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 uppercase text-[10px] block">Transfer Amount</span>
                      <strong className="text-slate-900 font-serif-display text-sm">
                        {wireForm.transferCurrency} {parseFloat(wireForm.transferAmount || '0').toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </strong>
                    </div>
                    <div>
                      <span className="text-slate-500 uppercase text-[10px] block">Timestamp</span>
                      <span className="text-slate-700 font-mono">{wireResult.transferDetails?.formattedTime}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 uppercase text-[10px] block">Status</span>
                      <span className="text-rose-700 font-semibold font-mono">Gateway Clearance Restricted</span>
                    </div>
                    <div className="sm:col-span-2 pt-1 border-t border-slate-200/60">
                      <span className="text-slate-500 uppercase text-[10px] block">Gateway Response</span>
                      <span className="text-rose-700 font-medium">{wireResult.transferDetails?.failureReason}</span>
                    </div>
                  </div>
                </div>

                {/* Clear Next Steps for User */}
                <div className="p-4 bg-amber-50/70 rounded-xl border border-amber-200 text-xs text-amber-950 space-y-2">
                  <div className="font-semibold flex items-center gap-1.5 text-amber-900">
                    <HelpCircle className="w-4 h-4 text-[#C5921E]" />
                    <span>Recommended Next Steps:</span>
                  </div>
                  <ul className="list-disc pl-5 space-y-1 text-slate-700 text-[11px]">
                    <li>Contact your Senior Managing Trustee (<strong>{account.relationshipEmail}</strong>) to request live signatory clearance and cross-border gateway release.</li>
                    <li>Verify correspondent banking BIC and IBAN formats with your international recipient.</li>
                    <li>Return to the main dashboard to view settled balance reserves and historical depository records.</li>
                  </ul>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                  <button
                    onClick={resetWireTransfer}
                    className="w-full sm:flex-1 py-3 px-4 rounded-xl border border-slate-300 text-slate-700 font-semibold text-xs hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    Try Another Transfer
                  </button>
                  <button
                    onClick={() => {
                      resetWireTransfer();
                      setActiveNav('dashboard');
                    }}
                    className="w-full sm:flex-1 py-3 px-4 rounded-xl bg-[#0B2548] text-white font-semibold text-xs hover:bg-[#071933] transition-colors shadow-sm cursor-pointer"
                  >
                    Return to Dashboard
                  </button>
                </div>
              </div>
            )}

          </div>
        )}

        {/* ================= TAB 6: BENEFICIARIES ================= */}
        {activeNav === 'beneficiaries' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6 animate-in fade-in">
            <div className="pb-4 border-b border-slate-100">
              <h2 className="font-serif-display font-bold text-2xl text-[#0B2548]">
                Pre-Approved Institutional Beneficiaries
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Designated institutional payees vetted for fiduciary settlement.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {beneficiaries.map((ben) => (
                <div key={ben.id} className="p-5 bg-slate-50 rounded-2xl border border-slate-200 hover:border-[#C5921E] transition-all space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#C5921E] bg-[#C5921E]/10 px-2 py-0.5 rounded">
                      {ben.category}
                    </span>
                    <span className="text-xs text-slate-400">{ben.country}</span>
                  </div>

                  <div>
                    <h3 className="font-serif-display font-bold text-base text-slate-900">{ben.name}</h3>
                    <p className="text-xs text-slate-600 mt-0.5">{ben.bank}</p>
                  </div>

                  <div className="p-2.5 bg-white rounded-xl border border-slate-100 text-[11px] font-mono space-y-1">
                    <div className="text-slate-600">IBAN: {ben.accountNumber}</div>
                    <div className="text-slate-600">SWIFT: {ben.swiftBic}</div>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[10px] text-slate-400">Last activity: {ben.lastTransferDate}</span>
                    <button
                      onClick={() => {
                        setWireForm({
                          ...wireForm,
                          beneficiaryName: ben.name,
                          beneficiaryBank: ben.bank,
                          accountOrIban: ben.accountNumber,
                          swiftBic: ben.swiftBic,
                          destinationCountry: ben.country,
                        });
                        setActiveNav('wire');
                      }}
                      className="text-xs text-[#0B2548] font-bold hover:underline"
                    >
                      Initiate Wire →
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================= TAB 7: STATEMENTS ================= */}
        {activeNav === 'statements' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs max-w-3xl mx-auto space-y-6 animate-in fade-in">
            <div className="pb-4 border-b border-slate-100">
              <h2 className="font-serif-display font-bold text-2xl text-[#0B2548]">
                Fiduciary Statements & Official Records
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Generate authenticated fiduciary statements formatted for institutional trust verification.
              </p>
            </div>

            <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-[#0B2548] text-[#C5921E] flex items-center justify-center shrink-0">
                  <FileText className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-serif-display font-bold text-base text-[#0B2548]">
                    Consolidated Annual Statement (2020–2026)
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Includes all {transactions.length} historical transactions and current closing balance.
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowStatementModal(true)}
                className="py-2.5 px-5 rounded-xl bg-[#0B2548] text-white font-semibold text-xs hover:bg-[#071933] transition-colors shrink-0 shadow-sm"
              >
                View & Print Statement
              </button>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-700 leading-relaxed">
              <strong className="block text-[#0B2548] font-bold mb-0.5">Official Fiduciary Records:</strong>
              All account statements generated through this portal are official accounting records produced directly from the depository register. For certified copies with wet ink or apostille certification, please contact your relationship manager.
            </div>
          </div>
        )}

        {/* ================= TAB 8: ACCOUNT DETAILS ================= */}
        {activeNav === 'details' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs max-w-3xl mx-auto space-y-6 animate-in fade-in">
            <div className="pb-4 border-b border-slate-100">
              <h2 className="font-serif-display font-bold text-2xl text-[#0B2548]">
                Fiduciary Account Details & Clearing Instructions
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Official wiring coordinates and relationship management credentials for this account.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-500 uppercase text-[10px] block">Account Holder</span>
                <span className="font-serif-display font-bold text-sm text-slate-900 mt-1 block">
                  {account.accountHolderName}
                </span>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-500 uppercase text-[10px] block">Account Number</span>
                <div className="flex items-center justify-between mt-1">
                  <span className="font-mono font-bold text-sm text-slate-900">{account.accountNumber}</span>
                  <button
                    onClick={() => handleCopy(account.accountNumber, 'acc-num')}
                    className="text-[#C5921E] hover:text-[#0B2548]"
                  >
                    {copiedField === 'acc-num' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-500 uppercase text-[10px] block">SWIFT / BIC</span>
                <div className="flex items-center justify-between mt-1">
                  <span className="font-mono font-bold text-sm text-slate-900">{account.swiftBic}</span>
                  <button
                    onClick={() => handleCopy(account.swiftBic, 'swift')}
                    className="text-[#C5921E] hover:text-[#0B2548]"
                  >
                    {copiedField === 'swift' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-500 uppercase text-[10px] block">Federal Routing Number</span>
                <div className="flex items-center justify-between mt-1">
                  <span className="font-mono font-bold text-sm text-slate-900">{account.routingNumber}</span>
                  <button
                    onClick={() => handleCopy(account.routingNumber, 'routing')}
                    className="text-[#C5921E] hover:text-[#0B2548]"
                  >
                    {copiedField === 'routing' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="sm:col-span-2 p-4 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-500 uppercase text-[10px] block">International IBAN</span>
                <div className="flex items-center justify-between mt-1">
                  <span className="font-mono font-bold text-sm text-slate-900">{account.iban}</span>
                  <button
                    onClick={() => handleCopy(account.iban, 'iban')}
                    className="text-[#C5921E] hover:text-[#0B2548]"
                  >
                    {copiedField === 'iban' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="sm:col-span-2 p-4 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-500 uppercase text-[10px] block">Stewardship Mandate</span>
                <p className="text-slate-700 leading-relaxed mt-1">{account.accountDescription}</p>
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 9: NOTIFICATIONS ================= */}
        {activeNav === 'notifications' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs max-w-3xl mx-auto space-y-6 animate-in fade-in">
            <div className="pb-4 border-b border-slate-100">
              <h2 className="font-serif-display font-bold text-2xl text-[#0B2548]">
                Fiduciary Notices & Regulatory Bulletins
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Official communications and audit disclosures issued by Litchfield Heritage Trust trustees.
              </p>
            </div>

            <div className="space-y-4">
              {notifications.map((n) => (
                <div key={n.id} className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-serif-display font-bold text-base text-slate-900">{n.title}</h3>
                    <span className="text-[10px] font-mono uppercase bg-[#0B2548] text-white px-2 py-0.5 rounded">
                      {n.priority}
                    </span>
                  </div>
                  <p className="text-slate-600 leading-relaxed text-sm">{n.message}</p>
                  <span className="text-[11px] text-slate-400 block pt-1">Date Published: {n.date}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================= TAB 10: SETTINGS ================= */}
        {activeNav === 'settings' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs max-w-2xl mx-auto space-y-6 animate-in fade-in">
            <div className="pb-4 border-b border-slate-100">
              <h2 className="font-serif-display font-bold text-2xl text-[#0B2548]">
                Preferences & Session Details
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Manage personal interface preferences and view your current fiduciary session.
              </p>
            </div>

            <div className="space-y-4 text-xs">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <span className="font-semibold text-slate-900 block text-sm">Account Privacy Mode</span>
                <p className="text-slate-600">
                  Toggle whether account balances are hidden or displayed by default when loading the portal.
                </p>
                <button
                  onClick={() => setShowBalance(!showBalance)}
                  className="py-2 px-4 rounded-lg bg-[#0B2548] text-white font-semibold mt-1"
                >
                  {showBalance ? 'Hide Balances' : 'Show Balances'}
                </button>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <span className="font-semibold text-slate-900 block text-sm">Authorized Session Identity</span>
                <p className="text-slate-600">
                  Logged in with business credentials: <code className="font-bold text-slate-900">aurelianhouse777@gmail.com</code>
                </p>
                <p className="text-[11px] text-slate-500">
                  Role: Authorized Client Delegate (Fiduciary Read-Only Access)
                </p>
              </div>
            </div>
          </div>
        )}

      </main>

      {/* Footer with Dark Architectural Background */}
      <footer className="mt-auto relative overflow-hidden bg-[#071933] border-t-2 border-[#C5921E] py-8 px-4 sm:px-6 lg:px-8 text-xs text-slate-300 font-sans-body">
        <div className="absolute inset-0 z-0 opacity-25">
          <img
            src={brandImages.footerNavyArchitectural}
            alt="Architectural Linework"
            className="w-full h-full object-cover object-center"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-white rounded-lg p-1.5 shadow-sm">
              <BrandLogo size="sm" showSubtitle={false} />
            </div>
            <span>© {new Date().getFullYear()} Litchfield Heritage Trust. Private Banking & Sovereign Fiduciary Services.</span>
          </div>
          <div className="text-[11px] text-slate-400 font-medium tracking-wide">
            Authorized Private Banking & Sovereign Fiduciary Services. All rights reserved.
          </div>
        </div>
      </footer>

      {/* Transaction Detail Modal */}
      {selectedTx && (
        <TransactionDetailModal
          transaction={selectedTx}
          currencySymbol={account.currencySymbol}
          onClose={() => setSelectedTx(null)}
        />
      )}

      {/* Demonstration Statement Modal */}
      {showStatementModal && (
        <DemonstrationStatementModal
          account={account}
          transactions={transactions}
          onClose={() => setShowStatementModal(false)}
        />
      )}

    </div>
  );
};
