import React, { useState } from 'react';
import { brandImages } from '../assets/images';
import { BrandLogo } from './BrandLogo';
import {
  ShieldCheck,
  Building2,
  Lock,
  ArrowRight,
  ChevronRight,
  Briefcase,
  TrendingUp,
  Compass,
  GraduationCap,
  Phone,
  Mail,
  MapPin,
  CheckCircle2,
  ExternalLink,
} from 'lucide-react';

interface InstitutionalShowcaseProps {
  onOpenLogin: () => void;
}

export const InstitutionalShowcase: React.FC<InstitutionalShowcaseProps> = ({ onOpenLogin }) => {
  const [activeService, setActiveService] = useState<'personal' | 'business' | 'wealth' | 'investment' | 'planning'>('wealth');
  const [inquirySent, setInquirySent] = useState(false);
  const [inquiryForm, setInquiryForm] = useState({ name: '', email: '', interest: 'Private Wealth Management', message: '' });

  const handleInquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setInquirySent(true);
    setTimeout(() => {
      setInquirySent(false);
      setInquiryForm({ name: '', email: '', interest: 'Private Wealth Management', message: '' });
    }, 4000);
  };

  const services = [
    {
      id: 'personal',
      title: 'Personal Banking',
      image: brandImages.servicePersonalBanking,
      subtitle: 'Discretionary Liquidity & Bespoke Cash Management',
      description:
        'Tailored depository accounts designed for high-net-worth individuals, family offices, and accredited trustees requiring continuous liquidity, priority international clearing, and personalized day-to-day stewardship.',
      features: [
        'Dedicated Private Client Relationship Manager',
        'Tier-1 Ring-Fenced Depository Custody',
        'Multi-Currency Liquidity Accounts (USD, EUR, GBP, CHF)',
        'Direct Access to Executive Fiduciary Desks',
      ],
    },
    {
      id: 'business',
      title: 'Business Banking',
      image: brandImages.serviceBusinessBanking,
      subtitle: 'Commercial Treasury & Syndicated Escrow Facilities',
      description:
        'Strategic financial infrastructure supporting corporate enterprises, institutional partnerships, and commercial treasuries with custom credit lines, escrow arrangements, and automated settlement protocols.',
      features: [
        'Institutional Treasury Sweeps & Money Market Placement',
        'Cross-Border SWIFT & ISO-20022 Clearing Protocols',
        'Commercial Escrow & Trust Custody Services',
        'Bespoke Syndicated Financing Facilities',
      ],
    },
    {
      id: 'wealth',
      title: 'Wealth Management',
      image: brandImages.serviceWealthManagement,
      subtitle: 'Generational Fiduciary Stewardship & Capital Preservation',
      description:
        'Discretionary asset management engineered to preserve capital purchasing power across generations, balancing sovereign fixed-income yields with curated private equity distributions.',
      features: [
        'Fiduciary Trust Charter & Ring-Fenced Asset Vaults',
        'Custom Tailored Discretionary Investment Mandates',
        'Tax-Efficient Multi-Jurisdictional Structuring',
        'Direct Sovereign Debt & Precious Metals Custody',
      ],
    },
    {
      id: 'investment',
      title: 'Investment Services',
      image: brandImages.serviceInvestmentPlanning,
      subtitle: 'Global Capital Markets & Quantitative Asset Allocation',
      description:
        'Institutional market access covering sovereign debt obligations, supranational bonds, green infrastructure securities, and private debt syndications with real-time risk oversight.',
      features: [
        'Sovereign Bond Rollovers & Treasury Yield Harvesting',
        'Alternative Investment & Private Equity Access',
        'Institutional Risk-Weighted Portfolio Modeling',
        'Audited Tier-1 Capital Adequacy Oversight',
      ],
    },
    {
      id: 'planning',
      title: 'Financial Planning',
      image: brandImages.serviceFinancialPlanning,
      subtitle: 'Comprehensive Wealth Architecture & Succession Advisory',
      description:
        'Holistic estate planning, philanthropic foundation endowment management, and cross-border succession strategies executed with strict fiduciary integrity and legal precision.',
      features: [
        'Generational Estate & Dynastic Trust Architecture',
        'Charitable Endowment & Philanthropic Structuring',
        'Liquidity Event Preparation & Executive Transitions',
        'Confidential Multi-Generational Family Assemblies',
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-slate-800 font-sans-body selection:bg-[#C5921E]/30 selection:text-[#0B2548]">
      
      {/* ================= 0. TOP BAR ================= */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
          <BrandLogo size="md" />

          {/* Desktop Nav Links */}
          <nav className="hidden md:flex items-center gap-7 text-xs font-semibold uppercase tracking-wider text-slate-600">
            <a href="#about" className="hover:text-[#0B2548] transition-colors">About Us</a>
            <a href="#services" className="hover:text-[#0B2548] transition-colors">Banking Services</a>
            <a href="#why-choose" className="hover:text-[#0B2548] transition-colors">Why Choose Us</a>
            <a href="#resources" className="hover:text-[#0B2548] transition-colors">Research & Insights</a>
            <a href="#contact" className="hover:text-[#0B2548] transition-colors">Contact</a>
          </nav>

          {/* Primary Action Button */}
          <div className="flex items-center gap-3">
            <button
              onClick={onOpenLogin}
              className="inline-flex items-center gap-2 py-2.5 px-4 sm:px-5 rounded-xl text-xs font-bold uppercase tracking-wider bg-[#0B2548] hover:bg-[#071933] text-white transition-all shadow-md shadow-[#0B2548]/15 active:scale-[0.99] cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5 text-[#C5921E]" />
              <span>Client Portal Login</span>
            </button>
          </div>
        </div>
      </header>

      {/* ================= 1. MAIN HOMEPAGE HERO SECTION ================= */}
      <section className="relative overflow-hidden bg-[#071933] text-white">
        <div className="relative min-h-[580px] lg:min-h-[680px] flex items-center">
          
          {/* Background Hero Image with Measured Gradient Scrim */}
          <div className="absolute inset-0 z-0">
            <img
              src={brandImages.heroBankingHeadquarters}
              alt="Litchfield Heritage Trust Headquarters"
              className="w-full h-full object-cover object-center lg:object-right"
              referrerPolicy="no-referrer"
            />
            {/* Deep navy left scrim for high-contrast headline reading */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#071933] via-[#071933]/85 lg:via-[#071933]/70 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#071933] via-transparent to-black/20" />
          </div>

          {/* Hero Content Container */}
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 w-full">
            <div className="max-w-2xl space-y-6">
              
              <div className="inline-flex items-center gap-2 py-1 px-3.5 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-xs text-[#F4E8CE]">
                <ShieldCheck className="w-4 h-4 text-[#C5921E]" />
                <span className="font-semibold uppercase tracking-wider text-[11px]">
                  Private Banking & Sovereign Fiduciary Depository
                </span>
              </div>

              <h1 className="font-serif-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white tracking-tight leading-[1.12] text-balance">
                Your Trust. <br />
                <span className="text-[#C5921E] font-normal italic">Our Timeless Heritage.</span>
              </h1>

              <p className="text-slate-200 text-base sm:text-lg leading-relaxed font-normal max-w-xl">
                Litchfield Heritage Trust provides bespoke private banking, institutional treasury management, and generational wealth stewardship for accredited entities, family trusts, and sovereign institutions.
              </p>

              <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                <button
                  onClick={onOpenLogin}
                  className="inline-flex items-center justify-center gap-2 py-3.5 px-6 rounded-xl text-sm font-semibold bg-[#C5921E] hover:bg-[#A67610] text-[#071933] transition-all shadow-lg shadow-black/30 font-sans-body cursor-pointer"
                >
                  <span>Access Secure Banking Portal</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <a
                  href="#services"
                  className="inline-flex items-center justify-center gap-2 py-3.5 px-6 rounded-xl text-sm font-semibold bg-white/10 hover:bg-white/20 text-white backdrop-blur-sm border border-white/20 transition-all font-sans-body"
                >
                  <span>Explore Fiduciary Services</span>
                </a>
              </div>

              {/* Trust Metrics Ribbon */}
              <div className="pt-8 grid grid-cols-3 gap-6 border-t border-white/15 text-xs">
                <div>
                  <span className="font-serif-display text-2xl lg:text-3xl font-bold text-white block tabular-nums">
                    $148M+
                  </span>
                  <span className="text-slate-300 text-[11px] block mt-0.5">Discretionary Custody</span>
                </div>
                <div>
                  <span className="font-serif-display text-2xl lg:text-3xl font-bold text-[#C5921E] block tabular-nums">
                    28.4%
                  </span>
                  <span className="text-slate-300 text-[11px] block mt-0.5">Tier-1 Capital Adequacy</span>
                </div>
                <div>
                  <span className="font-serif-display text-2xl lg:text-3xl font-bold text-white block">
                    100%
                  </span>
                  <span className="text-slate-300 text-[11px] block mt-0.5">Ring-Fenced Depository</span>
                </div>
              </div>

            </div>
          </div>
        </div>
      </section>

      {/* ================= 2. ABOUT US — INSTITUTIONAL HERITAGE ================= */}
      <section id="about" className="py-20 lg:py-28 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            
            {/* Visual Element: Stately Classical Heritage Architecture */}
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-slate-200 group">
              <img
                src={brandImages.aboutHeritageBuilding}
                alt="Institutional Heritage Estate"
                className="w-full h-[400px] lg:h-[520px] object-cover group-hover:scale-[1.02] transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
              <div className="absolute bottom-6 left-6 right-6 text-white">
                <span className="text-xs uppercase tracking-widest text-[#F4E8CE] font-semibold block mb-1">
                  Institutional Depository & Fiduciary Estate
                </span>
                <p className="font-serif-display text-lg font-bold">
                  Generations of Discretion, Governance & Absolute Stewardship
                </p>
              </div>
            </div>

            {/* Prose Content */}
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#C5921E]">
                <Building2 className="w-4 h-4" />
                <span>About Litchfield Heritage Trust</span>
              </div>

              <h2 className="font-serif-display text-3xl sm:text-4xl font-bold text-[#0B2548] tracking-tight leading-tight">
                An Established Tradition of Fiduciary Integrity & Financial Permanence
              </h2>

              <p className="text-slate-600 leading-relaxed text-sm sm:text-base">
                Founded upon the principles of conservative capital allocation and unwavering fiduciary duty, Litchfield Heritage Trust operates as a premier private banking institution. We combine the timeless permanence of traditional British and Swiss private banking with modern institutional-grade digital ledger architecture.
              </p>

              <p className="text-slate-600 leading-relaxed text-sm sm:text-base">
                Our institution accepts only accredited corporations, family offices, and designated trusts. Unlike retail commercial depositories, client assets are fully ring-fenced within sovereign custodial structures, ensuring that wealth remains insulated from fractional-reserve vulnerabilities.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                  <h4 className="font-serif-display font-bold text-base text-[#0B2548]">Private Discretion</h4>
                  <p className="text-xs text-slate-500 mt-1">
                    Strict institutional confidentiality protocols protecting client anonymity and generational holdings.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                  <h4 className="font-serif-display font-bold text-base text-[#0B2548]">Sovereign Custody</h4>
                  <p className="text-xs text-slate-500 mt-1">
                    Direct allocations in high-grade sovereign paper, gold bullion reserves, and prime liquidity instruments.
                  </p>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={onOpenLogin}
                  className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#0B2548] hover:text-[#C5921E] transition-colors"
                >
                  <span>Review Authorized Depository Credentials</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

            </div>

          </div>

        </div>
      </section>

      {/* ================= 3. PRIVATE BANKING SERVICES GALLERY ================= */}
      <section id="services" className="py-20 lg:py-28 bg-[#F8FAFC] border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <span className="text-xs font-bold uppercase tracking-widest text-[#C5921E]">
              Bespoke Banking Capabilities
            </span>
            <h2 className="font-serif-display text-3xl sm:text-4xl font-bold text-[#0B2548]">
              Comprehensive Private Banking & Fiduciary Services
            </h2>
            <p className="text-slate-600 text-sm leading-relaxed">
              Every service is structured around capital security, regulatory compliance, and generational growth tailored to sophisticated market participants.
            </p>
          </div>

          {/* Interactive Service Category Selector */}
          <div className="flex flex-wrap items-center justify-center gap-2 p-1.5 bg-slate-200/70 rounded-2xl max-w-3xl mx-auto">
            {services.map((svc) => (
              <button
                key={svc.id}
                onClick={() => setActiveService(svc.id as any)}
                className={`py-2 px-4 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                  activeService === svc.id
                    ? 'bg-[#0B2548] text-white shadow-sm'
                    : 'text-slate-700 hover:text-[#0B2548] hover:bg-white/60'
                }`}
              >
                {svc.title}
              </button>
            ))}
          </div>

          {/* Active Featured Service Card */}
          {(() => {
            const current = services.find((s) => s.id === activeService) || services[0];
            return (
              <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 transition-all">
                
                {/* Visual Editorial Image */}
                <div className="lg:col-span-7 relative min-h-[340px] lg:min-h-[460px] overflow-hidden">
                  <img
                    src={current.image}
                    alt={current.title}
                    className="w-full h-full object-cover object-center transition-all duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
                  <div className="absolute top-4 left-4 bg-[#0B2548]/90 text-[#F4E8CE] text-[11px] font-bold uppercase tracking-wider py-1 px-3 rounded-full backdrop-blur-sm border border-white/10">
                    LHT Fiduciary Standard
                  </div>
                </div>

                {/* Service Details & Features */}
                <div className="lg:col-span-5 p-8 sm:p-10 flex flex-col justify-between space-y-6">
                  <div className="space-y-4">
                    <span className="text-xs uppercase font-bold tracking-wider text-[#C5921E]">
                      {current.subtitle}
                    </span>
                    <h3 className="font-serif-display font-bold text-2xl sm:text-3xl text-[#0B2548]">
                      {current.title}
                    </h3>
                    <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
                      {current.description}
                    </p>

                    <div className="pt-2 space-y-2.5">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block">
                        Institutional Standards
                      </span>
                      {current.features.map((feat, idx) => (
                        <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-700">
                          <CheckCircle2 className="w-4 h-4 text-[#C5921E] shrink-0 mt-0.5" />
                          <span>{feat}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                    <button
                      onClick={onOpenLogin}
                      className="py-2.5 px-5 rounded-xl bg-[#0B2548] hover:bg-[#071933] text-white text-xs font-semibold transition-colors shadow-sm cursor-pointer"
                    >
                      Access Account Portal
                    </button>
                    <a
                      href="#contact"
                      className="text-xs text-[#0B2548] font-bold hover:text-[#C5921E] transition-colors"
                    >
                      Request Private Prospectus →
                    </a>
                  </div>
                </div>

              </div>
            );
          })()}

          {/* Service Cards Grid Overview */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 pt-6">
            {services.slice(0, 3).map((item) => (
              <div
                key={item.id}
                onClick={() => setActiveService(item.id as any)}
                className="bg-white rounded-2xl border border-slate-200 overflow-hidden hover:border-[#0B2548] hover:shadow-lg transition-all cursor-pointer group"
              >
                <div className="h-44 overflow-hidden relative">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                </div>
                <div className="p-5 space-y-2">
                  <h4 className="font-serif-display font-bold text-lg text-[#0B2548] group-hover:text-[#C5921E] transition-colors">
                    {item.title}
                  </h4>
                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                    {item.description}
                  </p>
                  <span className="text-xs text-[#0B2548] font-bold inline-flex items-center gap-1 pt-1">
                    Explore Details <ChevronRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* ================= 4. WHY CHOOSE LITCHFIELD HERITAGE TRUST ================= */}
      <section id="why-choose" className="py-20 lg:py-28 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            
            {/* Left Content */}
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#C5921E]">
                <ShieldCheck className="w-4 h-4" />
                <span>The Institutional Difference</span>
              </div>

              <h2 className="font-serif-display text-3xl sm:text-4xl font-bold text-[#0B2548] tracking-tight leading-tight">
                Architected for Stability, Independence, and Generational Governance
              </h2>

              <p className="text-slate-600 leading-relaxed text-sm sm:text-base">
                In an era of volatile financial ecosystems and institutional consolidation, Litchfield Heritage Trust maintains an uncompromised model: 100% fiduciary alignment with zero commercial trading liabilities.
              </p>

              <div className="space-y-4 pt-2">
                <div className="flex items-start gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-200">
                  <div className="w-10 h-10 rounded-xl bg-[#0B2548] text-[#C5921E] flex items-center justify-center shrink-0 font-serif-display font-bold text-sm">
                    01
                  </div>
                  <div>
                    <h4 className="font-serif-display font-bold text-base text-[#0B2548]">
                      Tier-1 Capital Fortress
                    </h4>
                    <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                      Maintaining a capital reserve ratio of 28.4%, far exceeding regulatory mandates to ensure uninterrupted liquidity during macroeconomic stress.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-200">
                  <div className="w-10 h-10 rounded-xl bg-[#C5921E] text-[#071933] flex items-center justify-center shrink-0 font-serif-display font-bold text-sm">
                    02
                  </div>
                  <div>
                    <h4 className="font-serif-display font-bold text-base text-[#0B2548]">
                      Direct Multi-Jurisdictional Depository
                    </h4>
                    <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                      Physical asset custody and accounts distributed across premier fiduciary centers including New York, London, and Geneva.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-200">
                  <div className="w-10 h-10 rounded-xl bg-slate-800 text-white flex items-center justify-center shrink-0 font-serif-display font-bold text-sm">
                    03
                  </div>
                  <div>
                    <h4 className="font-serif-display font-bold text-base text-[#0B2548]">
                      Confidential Discretion & Governance
                    </h4>
                    <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                      Single designated corporate trustee point of contact, eliminating administrative handoffs and preserving executive privacy.
                    </p>
                  </div>
                </div>
              </div>

            </div>

            {/* Right Visual: Grand Classical Banking Hall Interior */}
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-slate-200 group">
              <img
                src={brandImages.whyChooseHeritage}
                alt="Grand Banking Hall Interior"
                className="w-full h-[440px] lg:h-[580px] object-cover group-hover:scale-[1.02] transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent pointer-events-none" />
              <div className="absolute bottom-6 left-6 right-6 text-white space-y-1">
                <span className="text-[11px] font-bold uppercase tracking-widest text-[#F4E8CE]">
                  Classical Depository Hall
                </span>
                <p className="font-serif-display font-bold text-lg sm:text-xl">
                  Built Upon Principles That Outlast Economic Cycles
                </p>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* ================= 5. FINANCIAL EDUCATION AND RESEARCH RESOURCES ================= */}
      <section id="resources" className="py-20 lg:py-28 bg-[#F8FAFC] border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Visual Workspace Still Life */}
            <div className="lg:col-span-6 relative rounded-3xl overflow-hidden shadow-xl border border-slate-200">
              <img
                src={brandImages.educationResourceWorkspace}
                alt="Financial Research & Education Workspace"
                className="w-full h-[380px] lg:h-[480px] object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 text-white">
                <span className="text-xs uppercase tracking-widest text-[#F4E8CE] font-bold block mb-1">
                  Fiduciary Advisory Intelligence
                </span>
                <p className="font-serif-display text-lg font-bold">
                  Quarterly Institutional Depository Bulletins & Regulatory Insights
                </p>
              </div>
            </div>

            {/* Resources List */}
            <div className="lg:col-span-6 space-y-6">
              <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#C5921E]">
                <GraduationCap className="w-4 h-4" />
                <span>Executive Research & Fiduciary Briefs</span>
              </div>

              <h2 className="font-serif-display text-3xl sm:text-4xl font-bold text-[#0B2548]">
                Informed Capital Decision-Making for Trustees and Principals
              </h2>

              <p className="text-slate-600 text-sm leading-relaxed">
                We publish quarterly research treatises, capital adequacy disclosures, and global trust regulatory analyses for accredited trustees, attorneys, and family principals.
              </p>

              <div className="space-y-3 pt-2">
                {[
                  {
                    title: 'Q3 2026 Sovereign Bond & Inflation-Protected Securities Review',
                    date: 'Published October 2026',
                    tag: 'Fixed Income',
                  },
                  {
                    title: 'Cross-Border Wealth Preservation: Fiduciary Structuring in New York & Geneva',
                    date: 'Published September 2026',
                    tag: 'Fiduciary Charter',
                  },
                  {
                    title: 'Tier-1 Capital Adequacy & Depository Liquidity Stress-Testing Standards',
                    date: 'Published August 2026',
                    tag: 'Institutional Audit',
                  },
                ].map((item, i) => (
                  <div
                    key={i}
                    onClick={onOpenLogin}
                    className="p-4 bg-white rounded-2xl border border-slate-200 hover:border-[#0B2548] transition-all flex items-center justify-between gap-4 cursor-pointer group"
                  >
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-[#C5921E]">
                        {item.tag} · {item.date}
                      </span>
                      <h4 className="font-serif-display font-semibold text-sm text-[#0B2548] group-hover:text-[#C5921E] transition-colors mt-0.5">
                        {item.title}
                      </h4>
                    </div>
                    <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-[#0B2548] shrink-0" />
                  </div>
                ))}
              </div>

            </div>

          </div>

        </div>
      </section>

      {/* ================= 6. CONTACT US & PRIVATE CLIENT CONCIERGE ================= */}
      <section id="contact" className="py-20 lg:py-28 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            
            {/* Visual Reception Area & Office Coordinates */}
            <div className="lg:col-span-6 space-y-6">
              <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#C5921E]">
                <Phone className="w-4 h-4" />
                <span>Executive Concierge & Reception</span>
              </div>

              <h2 className="font-serif-display text-3xl sm:text-4xl font-bold text-[#0B2548]">
                Schedule a Confidential Fiduciary Consultation
              </h2>

              <p className="text-slate-600 text-sm leading-relaxed">
                Our Managing Trustees are available by appointment at our principal executive offices or through secure encrypted telepresence.
              </p>

              {/* Reception Photo */}
              <div className="rounded-3xl overflow-hidden shadow-xl border border-slate-200 relative">
                <img
                  src={brandImages.contactReceptionInterior}
                  alt="Client Reception and Concierge Lounge"
                  className="w-full h-[280px] object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
                <span className="absolute bottom-4 left-4 text-xs font-semibold text-white">
                  Executive Concierge Suite · Private Client Admissions
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs pt-2">
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
                  <div className="flex items-center gap-2 font-bold text-[#0B2548]">
                    <MapPin className="w-4 h-4 text-[#C5921E]" />
                    <span>New York Fiduciary District</span>
                  </div>
                  <p className="text-slate-600">45 Rockefeller Plaza, 28th Floor</p>
                  <p className="text-slate-600">New York, NY 10111</p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
                  <div className="flex items-center gap-2 font-bold text-[#0B2548]">
                    <Building2 className="w-4 h-4 text-[#C5921E]" />
                    <span>London Fiduciary Chambers</span>
                  </div>
                  <p className="text-slate-600">10 Berkeley Square, Mayfair</p>
                  <p className="text-slate-600">London W1J 6AA, United Kingdom</p>
                </div>
              </div>
            </div>

            {/* Inbound Fiduciary Inquiry Form */}
            <div className="lg:col-span-6 bg-slate-50 rounded-3xl p-8 sm:p-10 border border-slate-200 shadow-xl space-y-6">
              <div>
                <h3 className="font-serif-display font-bold text-2xl text-[#0B2548]">
                  Private Client Inquiry
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Please provide details regarding your prospective institutional account or fiduciary mandate.
                </p>
              </div>

              {inquirySent ? (
                <div className="p-6 bg-emerald-50 border border-emerald-200 rounded-2xl text-center space-y-2 text-emerald-900 animate-in fade-in">
                  <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                  <h4 className="font-serif-display font-bold text-lg">Inquiry Successfully Received</h4>
                  <p className="text-xs text-emerald-800 leading-relaxed">
                    A Senior Managing Trustee will contact you via your registered email within one business day under strict confidentiality.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleInquirySubmit} className="space-y-4 text-xs">
                  <div>
                    <label className="block font-semibold uppercase tracking-wider text-slate-700 mb-1">
                      Principal or Entity Legal Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={inquiryForm.name}
                      onChange={(e) => setInquiryForm({ ...inquiryForm, name: e.target.value })}
                      placeholder="e.g. Aurelian House Investment Holdings Ltd."
                      className="w-full p-3 text-sm bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0B2548]"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold uppercase tracking-wider text-slate-700 mb-1">
                      Authorized Contact Email *
                    </label>
                    <input
                      type="email"
                      required
                      value={inquiryForm.email}
                      onChange={(e) => setInquiryForm({ ...inquiryForm, email: e.target.value })}
                      placeholder="contact@institution.com"
                      className="w-full p-3 text-sm bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0B2548]"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold uppercase tracking-wider text-slate-700 mb-1">
                      Fiduciary Area of Interest
                    </label>
                    <select
                      value={inquiryForm.interest}
                      onChange={(e) => setInquiryForm({ ...inquiryForm, interest: e.target.value })}
                      className="w-full p-3 text-sm bg-white border border-slate-300 rounded-xl"
                    >
                      <option value="Private Wealth Management">Private Wealth Management</option>
                      <option value="Institutional Treasury Custody">Institutional Treasury Custody</option>
                      <option value="Discretionary Family Trust">Discretionary Family Trust</option>
                      <option value="Commercial Escrow Settlement">Commercial Escrow Settlement</option>
                      <option value="Sovereign Bond Custody">Sovereign Bond Custody</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold uppercase tracking-wider text-slate-700 mb-1">
                      Confidential Mandate Summary
                    </label>
                    <textarea
                      rows={3}
                      value={inquiryForm.message}
                      onChange={(e) => setInquiryForm({ ...inquiryForm, message: e.target.value })}
                      placeholder="Outline target portfolio scale, jurisdiction requirements, or custodial preferences..."
                      className="w-full p-3 text-sm bg-white border border-slate-300 rounded-xl"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 px-4 rounded-xl text-white font-semibold text-sm bg-[#0B2548] hover:bg-[#071933] transition-all shadow-md shadow-[#0B2548]/20 cursor-pointer"
                  >
                    Submit Confidential Inquiry
                  </button>

                  <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500 pt-1">
                    <Lock className="w-3.5 h-3.5 text-[#C5921E]" />
                    <span>Protected under strict fiduciary non-disclosure protocols</span>
                  </div>
                </form>
              )}
            </div>

          </div>

        </div>
      </section>

      {/* ================= 7. WEBSITE FOOTER WITH DARK ARCHITECTURAL BACKGROUND ================= */}
      <footer className="relative overflow-hidden bg-[#071933] text-white pt-16 pb-12 border-t-2 border-[#C5921E]">
        {/* Subtle Panoramic Architectural Navy Background Texture */}
        <div className="absolute inset-0 z-0">
          <img
            src={brandImages.footerNavyArchitectural}
            alt="Architectural Linework Texture"
            className="w-full h-full object-cover object-center opacity-40 mix-blend-screen"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-[#071933]/85 backdrop-blur-[2px]" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
            
            {/* Brand Column */}
            <div className="lg:col-span-2 space-y-4">
              <div className="bg-white rounded-xl p-3 inline-block shadow-md">
                <BrandLogo size="md" />
              </div>
              <p className="text-slate-300 text-xs leading-relaxed max-w-sm">
                Litchfield Heritage Trust is an exclusive private financial institution specializing in fiduciary wealth stewardship, sovereign depository reserves, and accredited family office services.
              </p>
              <div className="flex items-center gap-2 text-xs text-[#C5921E]">
                <ShieldCheck className="w-4 h-4" />
                <span className="font-semibold">Chartered Institutional Depository</span>
              </div>
            </div>

            {/* Fiduciary Services */}
            <div className="space-y-3 text-xs">
              <span className="font-serif-display font-bold text-sm text-[#F4E8CE] tracking-wider uppercase block">
                Banking Services
              </span>
              <ul className="space-y-2 text-slate-300">
                <li><a href="#services" className="hover:text-white transition-colors">Personal Banking</a></li>
                <li><a href="#services" className="hover:text-white transition-colors">Business Banking</a></li>
                <li><a href="#services" className="hover:text-white transition-colors">Wealth Management</a></li>
                <li><a href="#services" className="hover:text-white transition-colors">Investment Services</a></li>
                <li><a href="#services" className="hover:text-white transition-colors">Financial Planning</a></li>
              </ul>
            </div>

            {/* Institution */}
            <div className="space-y-3 text-xs">
              <span className="font-serif-display font-bold text-sm text-[#F4E8CE] tracking-wider uppercase block">
                Institution
              </span>
              <ul className="space-y-2 text-slate-300">
                <li><a href="#about" className="hover:text-white transition-colors">Institutional Heritage</a></li>
                <li><a href="#why-choose" className="hover:text-white transition-colors">Why Choose Us</a></li>
                <li><a href="#resources" className="hover:text-white transition-colors">Research & Insights</a></li>
                <li><a href="#contact" className="hover:text-white transition-colors">Executive Concierge</a></li>
              </ul>
            </div>

            {/* Secure Portal */}
            <div className="space-y-3 text-xs">
              <span className="font-serif-display font-bold text-sm text-[#F4E8CE] tracking-wider uppercase block">
                Client Access
              </span>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                Authorized institutional clients and trustees can access private accounts via our dual-tier encrypted portal.
              </p>
              <button
                onClick={onOpenLogin}
                className="w-full py-2.5 px-4 rounded-xl bg-[#C5921E] hover:bg-[#A67610] text-[#071933] font-bold text-xs transition-colors shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Launch Client Portal</span>
              </button>
            </div>

          </div>

          {/* Legal Disclaimers & Copyright */}
          <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-400">
            <p>
              © {new Date().getFullYear()} Litchfield Heritage Trust. All rights reserved. Private Banking, Treasury Custody & Fiduciary Services.
            </p>
            <p className="text-[10px] text-slate-400">
              Demonstration prototype platform. Live payment network settlement disabled pending formal charter licensing.
            </p>
          </div>

        </div>
      </footer>

    </div>
  );
};
