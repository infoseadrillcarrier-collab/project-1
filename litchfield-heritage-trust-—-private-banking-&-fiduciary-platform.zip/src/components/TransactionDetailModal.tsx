import React from 'react';
import { Transaction } from '../types';
import { X, ShieldCheck, ArrowDownLeft, ArrowUpRight, RefreshCw, AlertCircle, Building2, Calendar, FileText } from 'lucide-react';

interface TransactionDetailModalProps {
  transaction: Transaction | null;
  currencySymbol: string;
  onClose: () => void;
}

export const TransactionDetailModal: React.FC<TransactionDetailModalProps> = ({
  transaction,
  currencySymbol,
  onClose,
}) => {
  if (!transaction) return null;

  const isPositive = transaction.type === 'Deposit';

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 font-sans-body">
        
        {/* Header */}
        <div className="p-5 bg-[#0B2548] text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-[#C5921E]">
              {isPositive ? <ArrowDownLeft className="w-6 h-6" /> : <ArrowUpRight className="w-6 h-6" />}
            </div>
            <div>
              <div className="text-[11px] font-semibold uppercase tracking-wider text-[#C5921E]">
                Depository Transaction Record
              </div>
              <h3 className="font-serif-display font-bold text-lg leading-tight">
                {transaction.reference}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Amount Hero */}
          <div className="text-center p-4 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-xs uppercase tracking-wider text-slate-500 font-semibold block mb-1">
              Transaction Value
            </span>
            <div className={`font-serif-display text-3xl font-bold tabular-nums ${isPositive ? 'text-emerald-700' : 'text-slate-900'}`}>
              {isPositive ? '+' : '-'}{currencySymbol}{transaction.amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-xs text-slate-500 mt-1 flex items-center justify-center gap-2">
              <span className="inline-flex items-center gap-1 font-medium text-slate-700">
                <ShieldCheck className="w-3.5 h-3.5 text-[#C5921E]" />
                Status: {transaction.status}
              </span>
              <span>·</span>
              <span>Type: {transaction.type}</span>
            </div>
          </div>

          {/* Details Grid */}
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div className="space-y-1">
              <span className="text-slate-500 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" /> Date Executed
              </span>
              <p className="font-semibold text-slate-800 text-sm">{transaction.date}</p>
            </div>

            <div className="space-y-1">
              <span className="text-slate-500 flex items-center gap-1">
                <FileText className="w-3.5 h-3.5" /> Category
              </span>
              <p className="font-semibold text-slate-800 text-sm">{transaction.category}</p>
            </div>

            <div className="col-span-2 space-y-1 pt-1 border-t border-slate-100">
              <span className="text-slate-500 flex items-center gap-1">
                <Building2 className="w-3.5 h-3.5" /> Counterparty Entity
              </span>
              <p className="font-semibold text-slate-900 text-sm">{transaction.counterparty}</p>
              {transaction.counterpartyBank && (
                <p className="text-[11px] text-slate-500">{transaction.counterpartyBank}</p>
              )}
            </div>

            <div className="col-span-2 space-y-1 pt-1 border-t border-slate-100">
              <span className="text-slate-500">Transaction Purpose & Description</span>
              <p className="font-medium text-slate-800 text-sm leading-relaxed">{transaction.description}</p>
            </div>

            {transaction.balanceAfter !== undefined && (
              <div className="col-span-2 space-y-1 pt-1 border-t border-slate-100">
                <span className="text-slate-500">Running Fiduciary Balance After Settlement</span>
                <p className="font-semibold font-serif-display text-slate-900 text-sm tabular-nums">
                  {currencySymbol}{transaction.balanceAfter.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                </p>
              </div>
            )}
          </div>

          {/* Fiduciary Record Notice */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-start gap-2.5 text-xs text-slate-700">
            <ShieldCheck className="w-4 h-4 text-[#C5921E] shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <strong className="text-[#0B2548]">Verified Fiduciary Ledger Record:</strong> This entry is audited and archived within the Litchfield Heritage Trust institutional depository registry.
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="py-2 px-5 rounded-xl text-xs font-semibold bg-[#0B2548] text-white hover:bg-[#071933] transition-colors"
          >
            Close Details
          </button>
        </div>

      </div>
    </div>
  );
};
