import { AccountData, Transaction, AuditLogEntry, BankNotification, Beneficiary, UserRole } from './types';

let authToken: string | null = typeof sessionStorage !== 'undefined' ? sessionStorage.getItem('lht_auth_token') : null;

export function setToken(token: string | null) {
  authToken = token;
  if (typeof sessionStorage !== 'undefined') {
    if (token) {
      sessionStorage.setItem('lht_auth_token', token);
    } else {
      sessionStorage.removeItem('lht_auth_token');
    }
  }
}

export function getToken(): string | null {
  return authToken;
}

export const fallbackAccountData: AccountData = {
  accountHolderName: 'Aurelian House Investment Holdings Ltd.',
  accountNumber: 'LHT-9928-8472-1084',
  accountType: 'Private Heritage Trust & Sovereign Fiduciary Reserve',
  accountDescription:
    'Primary fiduciary depository account holding institutional treasury assets, ring-fenced sovereign liquidity, and discretionary trust reserves under Litchfield Heritage Trust stewardship.',
  accountStatus: 'Active & Verified',
  currency: 'USD',
  currencySymbol: '$',
  currentBalance: 148250420.5,
  availableBalance: 142100000,
  totalDeposits: 215450000,
  totalWithdrawals: 67199579.5,
  routingNumber: '021000089',
  swiftBic: 'LHTRUS33XXX',
  iban: 'US33LHTR021000089992884721',
  custodianBank: 'Litchfield Heritage Trust Fiduciary Depository',
  custodianJurisdiction: 'New York / London Fiduciary District',
  relationshipManager: 'Lord Alistair Sterling, Senior Managing Trustee',
  relationshipEmail: 'a.sterling@litchfieldheritagetrust.com',
  announcements:
    'Fiduciary Notice: Q3 2026 Capital Reserve Audit completed with Tier-1 Capital Adequacy ratio exceeding 28.4%. Depository balances remain fully ring-fenced.',
  fiduciaryRegistrationNumber: 'LHT-FID-88204-NYC',
  lastUpdated: new Date().toISOString(),
  lastAuditedBy: 'PricewaterhouseCoopers International Trust Advisory',
};

async function fetchWithAuth(url: string, options: RequestInit = {}, maxRetries = 3): Promise<Response> {
  const headers = new Headers(options.headers || {});
  if (authToken) {
    headers.set('Authorization', `Bearer ${authToken}`);
  }
  if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  let lastError: any = null;
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      const response = await fetch(url, {
        ...options,
        headers,
      });
      return response;
    } catch (err: any) {
      lastError = err;
      // Wait before retrying (exponential backoff)
      if (attempt < maxRetries - 1) {
        await new Promise((resolve) => setTimeout(resolve, 350 * (attempt + 1)));
      }
    }
  }

  throw lastError || new Error(`Network request to ${url} failed`);
}

export const api = {
  // Auth
  async validateEmail(email: string) {
    const res = await fetchWithAuth('/api/auth/validate-email', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Email validation failed');
    return data;
  },

  async verifyCode(email: string, code: string) {
    const res = await fetchWithAuth('/api/auth/verify-code', {
      method: 'POST',
      body: JSON.stringify({ email, code }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Code verification failed');
    if (data.token) {
      setToken(data.token);
    }
    return data as { success: boolean; token: string; role: UserRole; user: { email: string; name: string; role: UserRole } };
  },

  async getSession() {
    try {
      const res = await fetchWithAuth('/api/auth/session');
      if (!res.ok) return { authenticated: false };
      return res.json();
    } catch {
      return { authenticated: false };
    }
  },

  async logout() {
    try {
      await fetchWithAuth('/api/auth/logout', { method: 'POST' });
    } catch {
      // Ignore network errors during logout
    } finally {
      setToken(null);
    }
  },

  // Account
  async getAccount(): Promise<{ account: AccountData }> {
    try {
      const res = await fetchWithAuth('/api/account');
      if (!res.ok) throw new Error('Failed to fetch account information');
      return await res.json();
    } catch (err) {
      console.warn('Network issue fetching account, utilizing fallback record:', err);
      return { account: fallbackAccountData };
    }
  },

  async updateAccountProfile(updates: Partial<AccountData>, justification: string) {
    const res = await fetchWithAuth('/api/account/profile', {
      method: 'PUT',
      body: JSON.stringify({ updates, justification }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update account profile');
    return data;
  },

  async updateBalance(currentBalance: number, availableBalance: number, justification: string) {
    const res = await fetchWithAuth('/api/account/balance', {
      method: 'POST',
      body: JSON.stringify({ currentBalance, availableBalance, justification }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update balance');
    return data;
  },

  // Transactions
  async getTransactions(filters?: { search?: string; type?: string; status?: string; startDate?: string; endDate?: string }): Promise<{ transactions: Transaction[]; total: number }> {
    try {
      const params = new URLSearchParams();
      if (filters?.search) params.append('search', filters.search);
      if (filters?.type) params.append('type', filters.type);
      if (filters?.status) params.append('status', filters.status);
      if (filters?.startDate) params.append('startDate', filters.startDate);
      if (filters?.endDate) params.append('endDate', filters.endDate);

      const res = await fetchWithAuth(`/api/transactions?${params.toString()}`);
      if (!res.ok) throw new Error('Failed to fetch transactions');
      return await res.json();
    } catch (err) {
      console.warn('Network issue fetching transactions, utilizing empty fallback:', err);
      return { transactions: [], total: 0 };
    }
  },

  async addTransaction(tx: Partial<Transaction>) {
    const res = await fetchWithAuth('/api/transactions', {
      method: 'POST',
      body: JSON.stringify(tx),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to add transaction');
    return data;
  },

  async updateTransaction(id: string, updates: Partial<Transaction>) {
    const res = await fetchWithAuth(`/api/transactions/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update transaction');
    return data;
  },

  // Audit Logs
  async getAuditLogs(): Promise<{ auditLogs: AuditLogEntry[] }> {
    try {
      const res = await fetchWithAuth('/api/audit-logs');
      if (!res.ok) throw new Error('Failed to fetch audit logs');
      return await res.json();
    } catch (err) {
      console.warn('Network issue fetching audit logs, utilizing empty fallback:', err);
      return { auditLogs: [] };
    }
  },

  // Notifications
  async getNotifications(): Promise<{ notifications: BankNotification[] }> {
    try {
      const res = await fetchWithAuth('/api/notifications');
      if (!res.ok) throw new Error('Failed to fetch notifications');
      return await res.json();
    } catch (err) {
      console.warn('Network issue fetching notifications, utilizing empty fallback:', err);
      return {
        notifications: [
          {
            id: 'notif-1',
            timestamp: new Date().toISOString(),
            date: '2026-10-28',
            title: 'Tier-1 Capital Adequacy Report Published',
            message: 'The Q3 2026 independent fiduciary audit has been confirmed. Capital reserves remain backed by physical custody allocations and high-grade sovereign paper.',
            priority: 'regulatory',
            isRead: false,
          },
        ],
      };
    }
  },

  async addNotification(title: string, message: string, priority: string = 'routine') {
    const res = await fetchWithAuth('/api/notifications', {
      method: 'POST',
      body: JSON.stringify({ title, message, priority }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to add notification');
    return data;
  },

  // Beneficiaries
  async getBeneficiaries(): Promise<{ beneficiaries: Beneficiary[] }> {
    try {
      const res = await fetchWithAuth('/api/beneficiaries');
      if (!res.ok) throw new Error('Failed to fetch beneficiaries');
      return await res.json();
    } catch (err) {
      console.warn('Network issue fetching beneficiaries, utilizing fallback:', err);
      return {
        beneficiaries: [
          {
            id: 'ben-1',
            name: 'Rothschild & Co Fiduciary Escrow',
            bank: 'Rothschild Fiduciary Bankers AG',
            accountNumber: 'CH93-0024-0000-8812-4019-2',
            swiftBic: 'ROTCCHZZ',
            country: 'Switzerland',
            currency: 'USD',
            category: 'Institutional Escrow',
            lastTransferDate: '2026-09-18',
          },
          {
            id: 'ben-2',
            name: 'Pictet Sovereign Liquidity Custody',
            bank: 'Banque Pictet & Cie SA',
            accountNumber: 'CH18-0078-4000-2910-1102-8',
            swiftBic: 'PICTCHGG',
            country: 'Switzerland',
            currency: 'EUR',
            category: 'Private Vault Custody',
            lastTransferDate: '2026-08-11',
          },
        ],
      };
    }
  },

  // Transfers
  async submitDomesticTransfer(payload: {
    recipientName: string;
    recipientAccount: string;
    receivingInstitution: string;
    amount: number;
    currency: string;
    description: string;
    reference?: string;
  }) {
    const res = await fetchWithAuth('/api/transfers/domestic', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  async submitWireTransfer(payload: {
    beneficiaryName: string;
    beneficiaryBank: string;
    bankAddress: string;
    accountOrIban: string;
    swiftBic: string;
    destinationCountry: string;
    transferCurrency: string;
    transferAmount: number;
    paymentPurpose: string;
    remarks?: string;
  }) {
    const res = await fetchWithAuth('/api/transfers/wire', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  // Reset
  async resetDatabase() {
    const res = await fetchWithAuth('/api/admin/reset', { method: 'POST' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Reset failed');
    return data;
  },
};
