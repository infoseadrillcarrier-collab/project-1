import React, { useState, useEffect, useCallback } from 'react';
import { api, getToken, fallbackAccountData } from './api';
import { AccountData, Transaction, AuditLogEntry, BankNotification, Beneficiary, UserRole } from './types';
import { LoginFlow } from './components/LoginFlow';
import { AuthLoadingScreen } from './components/AuthLoadingScreen';
import { AdminDashboard } from './components/AdminDashboard';
import { VisitorDashboard } from './components/VisitorDashboard';
import { InstitutionalShowcase } from './components/InstitutionalShowcase';

export default function App() {
  const [unauthView, setUnauthView] = useState<'website' | 'portal'>('website');
  const [authPhase, setAuthPhase] = useState<'login' | 'authenticating' | 'authenticated' | 'logging_out'>('login');
  const [pendingRole, setPendingRole] = useState<UserRole | null>(null);
  const [userRole, setUserRole] = useState<UserRole | null>(null);
  const [userEmail, setUserEmail] = useState('aurelianhouse777@gmail.com');

  const [account, setAccount] = useState<AccountData | null>(fallbackAccountData);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [notifications, setNotifications] = useState<BankNotification[]>([]);
  const [beneficiaries, setBeneficiaries] = useState<Beneficiary[]>([]);
  const [isDataLoaded, setIsDataLoaded] = useState(false);

  // Fetch shared database records
  const loadBankData = useCallback(async (isRetry = false) => {
    try {
      const [accRes, txRes, notifRes, benRes] = await Promise.all([
        api.getAccount(),
        api.getTransactions(),
        api.getNotifications(),
        api.getBeneficiaries(),
      ]);

      if (accRes?.account) setAccount(accRes.account);
      if (txRes?.transactions) setTransactions(txRes.transactions);
      if (notifRes?.notifications) setNotifications(notifRes.notifications);
      if (benRes?.beneficiaries) setBeneficiaries(benRes.beneficiaries);

      // Fetch audit logs if admin
      if (userRole === 'admin') {
        try {
          const auditRes = await api.getAuditLogs();
          setAuditLogs(auditRes.auditLogs);
        } catch {
          // Ignore if not permitted
        }
      }

      setIsDataLoaded(true);
    } catch (err) {
      console.warn('Network issue loading bank data, retrying...', err);
      if (!isRetry) {
        setTimeout(() => loadBankData(true), 1200);
      }
    }
  }, [userRole]);

  // Initial session check
  useEffect(() => {
    async function checkExistingSession() {
      const token = getToken();
      if (token) {
        try {
          const session = await api.getSession();
          if (session.authenticated && session.role) {
            setUserRole(session.role);
            if (session.user?.email) setUserEmail(session.user.email);
            setAuthPhase('authenticated');
          } else {
            setAuthPhase('login');
          }
        } catch {
          setAuthPhase('login');
        }
      }
      loadBankData();
    }
    checkExistingSession();
  }, [loadBankData]);

  // Periodic background synchronization so admin changes appear live for visitors
  useEffect(() => {
    if (authPhase === 'authenticated') {
      const interval = setInterval(() => {
        loadBankData();
      }, 3500);
      return () => clearInterval(interval);
    }
  }, [authPhase, loadBankData]);

  // Step A: Triggered when user enters valid passcode
  const handleAuthSuccess = (role: UserRole) => {
    setPendingRole(role);
    setAuthPhase('authenticating');
  };

  // Step B: Triggered when 60s loading animation finishes (or is fast-tracked)
  const handleAuthLoadingComplete = () => {
    setUserRole(pendingRole);
    setAuthPhase('authenticated');
    loadBankData();
  };

  // Step C: Triggered when user clicks logout
  const handleLogout = async () => {
    setAuthPhase('logging_out');
  };

  // Step D: Triggered when logout animation finishes
  const handleLogoutComplete = async () => {
    await api.logout();
    setUserRole(null);
    setPendingRole(null);
    setAuthPhase('login');
    loadBankData();
  };

  // 1. Authenticating Screen (60 seconds branded transition)
  if (authPhase === 'authenticating') {
    return (
      <AuthLoadingScreen
        type="login"
        targetRole={pendingRole || undefined}
        onComplete={handleAuthLoadingComplete}
      />
    );
  }

  // 2. Logging out Screen (2.5 seconds transition)
  if (authPhase === 'logging_out') {
    return (
      <AuthLoadingScreen
        type="logout"
        onComplete={handleLogoutComplete}
      />
    );
  }

  // 3. Authenticated State: Admin Mode or Visitor Mode
  if (authPhase === 'authenticated' && account) {
    if (userRole === 'admin') {
      return (
        <AdminDashboard
          account={account}
          transactions={transactions}
          auditLogs={auditLogs}
          notifications={notifications}
          adminEmail={userEmail}
          onRefreshData={loadBankData}
          onLogout={handleLogout}
        />
      );
    }

    return (
      <VisitorDashboard
        account={account}
        transactions={transactions}
        notifications={notifications}
        beneficiaries={beneficiaries}
        onRefreshData={loadBankData}
        onLogout={handleLogout}
      />
    );
  }

  // 4. Default: Show Institutional Website Showcase or Two-Stage Login Portal
  if (unauthView === 'website') {
    return <InstitutionalShowcase onOpenLogin={() => setUnauthView('portal')} />;
  }

  return (
    <LoginFlow
      onAuthSuccess={handleAuthSuccess}
      onViewWebsite={() => setUnauthView('website')}
    />
  );
}
